import { createContext, useContext, useState, type ReactNode } from 'react';

interface Account {
  name: string;
  passcode: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  userName: string;
  login: (name: string, passcode: string) => { success: boolean; error?: string };
  createAccount: (name: string, passcode: string, confirmPasscode: string) => { success: boolean; error?: string };
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ACCOUNTS_KEY = 'digitally-fortified-accounts';

function getAccounts(): Account[] {
  const stored = localStorage.getItem(ACCOUNTS_KEY);
  return stored ? JSON.parse(stored) : [];
}

function saveAccounts(accounts: Account[]): void {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return !!sessionStorage.getItem('current-user');
  });
  const [userName, setUserName] = useState(() => sessionStorage.getItem('current-user') || '');

  const createAccount = (name: string, passcode: string, confirmPasscode: string): { success: boolean; error?: string } => {
    if (!name.trim()) {
      return { success: false, error: 'Name is required' };
    }

    if (!passcode.trim()) {
      return { success: false, error: 'Passcode is required' };
    }

    if (passcode !== confirmPasscode) {
      return { success: false, error: 'Passcodes do not match' };
    }

    const accounts = getAccounts();
    
    // Check for duplicate username
    if (accounts.some(acc => acc.name === name)) {
      return { success: false, error: 'An account with this name already exists' };
    }

    // Create new account
    accounts.push({ name, passcode });
    saveAccounts(accounts);

    // Auto-login
    sessionStorage.setItem('current-user', name);
    setUserName(name);
    setIsAuthenticated(true);

    return { success: true };
  };

  const login = (name: string, passcode: string): { success: boolean; error?: string } => {
    if (!name.trim()) {
      return { success: false, error: 'Name is required' };
    }

    if (!passcode.trim()) {
      return { success: false, error: 'Passcode is required' };
    }

    const accounts = getAccounts();
    const account = accounts.find(acc => acc.name === name && acc.passcode === passcode);

    if (account) {
      sessionStorage.setItem('current-user', name);
      setUserName(name);
      setIsAuthenticated(true);
      return { success: true };
    }

    return { success: false, error: 'Invalid name or passcode' };
  };

  const logout = () => {
    sessionStorage.removeItem('current-user');
    setIsAuthenticated(false);
    setUserName('');
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, userName, login, createAccount, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
