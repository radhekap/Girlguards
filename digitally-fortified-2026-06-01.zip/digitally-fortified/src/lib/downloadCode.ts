/**
 * downloadCode.ts
 *
 * Packages the COMPLETE project source + GitHub Pages deployment files
 * into a ready-to-push ZIP using JSZip.
 *
 * srcBundle.generated.ts is written by src-bundle-plugin in configResolved,
 * guaranteeing the import resolves in both dev and production builds.
 */

import JSZip from 'jszip';
import allSourceFiles from './srcBundle.generated';

// ─── GitHub Pages: 404.html SPA redirect ────────────────────────────────────
// When GitHub Pages serves a 404 (any deep link on a SPA), this page encodes
// the path as a query string and redirects to index.html which restores it.
// https://github.com/rafgraph/spa-github-pages
const PAGE_404 = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Digitally Fortified</title>
    <script>
      // Encodes the path into a query string so index.html can restore it.
      // pathSegmentsToKeep = 1 for GitHub Pages project sites (/<repo-name>/).
      // Set to 0 for user/org sites (username.github.io).
      var pathSegmentsToKeep = 1;
      var l = window.location;
      l.replace(
        l.protocol + '//' + l.hostname + (l.port ? ':' + l.port : '') +
        l.pathname.split('/').slice(0, 1 + pathSegmentsToKeep).join('/') + '/?/' +
        l.pathname.slice(1).split('/').join('/').replace(/&/g, '~and~') +
        (l.search ? '&' + l.search.slice(1).replace(/&/g, '~and~') : '') +
        l.hash
      );
    <\/script>
  </head>
  <body></body>
</html>
`;

// ─── GitHub Actions: automatic build + deploy to GitHub Pages ────────────────
const GITHUB_WORKFLOW = `name: Deploy to GitHub Pages

on:
  push:
    branches: [main, master]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: \${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up Node
        uses: actions/setup-node@v4
        with:
          node-version: '22'
          cache: 'npm'

      - name: Install dependencies
        run: npm install

      - name: Build
        run: npm run build
        env:
          # Repository secrets — add these in Settings > Secrets > Actions
          VITE_SUPABASE_URL: \${{ secrets.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: \${{ secrets.VITE_SUPABASE_ANON_KEY }}
          # Sets the asset base path to /<repo-name>/ for GitHub Pages
          VITE_BASE_PATH: /\${{ github.event.repository.name }}

      - name: Configure Pages
        uses: actions/configure-pages@v5

      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: dist

      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
`;

// ─── .env.example ────────────────────────────────────────────────────────────
const ENV_EXAMPLE = `# Digitally Fortified — environment variables
# Rename this file to .env and fill in your Supabase credentials.

VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here

# Optional: override the asset base path (defaults to /)
# VITE_BASE_PATH=/my-repo-name
`;

// ─── README.md ───────────────────────────────────────────────────────────────
const README = `# Digitally Fortified

A full-stack parental-control & kids-safety web platform built with
React 18 · TypeScript · Vite · Tailwind CSS · shadcn/ui · Supabase.

---

## Quick start (local dev)

\`\`\`bash
# 1. Install dependencies
npm install

# 2. Copy environment variables
cp .env.example .env
# → fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY

# 3. Start the dev server
npm run dev
\`\`\`

---

## Deploy to GitHub Pages (automatic)

The repository ships with a GitHub Actions workflow that builds and
deploys automatically on every push to **main** or **master**.

### One-time setup

1. **Push** this folder to a new GitHub repository.

2. **Add secrets** (Settings → Secrets and variables → Actions):
   | Secret name | Value |
   |---|---|
   | \`VITE_SUPABASE_URL\` | your Supabase project URL |
   | \`VITE_SUPABASE_ANON_KEY\` | your Supabase anon key |

3. **Enable Pages** (Settings → Pages):
   - Source: **GitHub Actions**

4. Push any commit — the workflow runs automatically and your site
   will be live at \`https://<username>.github.io/<repo-name>/\`.

### How routing works on GitHub Pages

GitHub Pages returns a \`404.html\` for unknown paths.  The included
\`public/404.html\` encodes the path into a query string and redirects
to \`index.html\`, which restores it so React Router sees the correct URL.
This means every deep link (e.g. \`/dashboard\`, \`/safety\`) works on
direct access and on page refresh.

---

## Deploy to Netlify / Vercel

Both hosts support React SPA routing natively.

- **Netlify**: \`netlify.toml\` is already configured.  Connect the repo
  in the Netlify dashboard — no further config needed.
- **Vercel**: Import the repo; Vercel auto-detects Vite.  Add the two
  environment variables in the project settings.

---

## Project structure

\`\`\`
src/
  components/   shadcn/ui + custom components
  pages/        One file per route
  contexts/     Auth & Theme providers
  hooks/        Reusable React hooks
  lib/          Utilities (Supabase client, helpers)
  services/     API / data-access layer
  types/        Shared TypeScript types
supabase/
  functions/    Edge Functions
  migrations/   Database migrations
\`\`\`

---

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript, Vite |
| Styling | Tailwind CSS, shadcn/ui |
| Backend | Supabase (Postgres + Auth + Storage + Edge Functions) |
| Deploy | GitHub Pages / Netlify / Vercel |
`;

// ─── helpers ─────────────────────────────────────────────────────────────────

function addToZip(
  folder: JSZip,
  filePath: string,
  content: string,
): void {
  const parts = filePath.split('/');
  if (parts.length === 1) {
    folder.file(filePath, content);
    return;
  }
  let dir = folder;
  for (let i = 0; i < parts.length - 1; i++) {
    dir = dir.folder(parts[i])!;
  }
  dir.file(parts[parts.length - 1], content);
}

// ─── main export ─────────────────────────────────────────────────────────────

export async function downloadAllCode(): Promise<void> {
  const zip    = new JSZip();
  const root   = zip.folder('digitally-fortified')!;

  // 1. All source files captured at dev/build start
  for (const [filePath, content] of Object.entries(allSourceFiles)) {
    addToZip(root, filePath, content);
  }

  // 2. GitHub Pages deployment files (not in source tree)
  addToZip(root, '.github/workflows/deploy.yml', GITHUB_WORKFLOW);
  addToZip(root, 'public/404.html',               PAGE_404);

  // 3. Helpers / docs
  root.file('.env.example', ENV_EXAMPLE);
  root.file('README.md',    README);   // overrides any existing README

  // Generate and trigger browser download
  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const url  = URL.createObjectURL(blob);
  const ts   = new Date().toISOString().slice(0, 10);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `digitally-fortified-${ts}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
