import DigitalThreatsPage from './pages/DigitalThreatsPage';
import LoginPage from './pages/LoginPage';
import GuidePage from './pages/GuidePage';
import PreventionStatsPage from './pages/PreventionStatsPage';
import DocumentationPage from './pages/DocumentationPage';
import SocialEmotionalPage from './pages/SocialEmotionalPage';
import ActionHealingPage from './pages/ActionHealingPage';
import CybersecurityLawsPage from './pages/CybersecurityLawsPage';
import PublicInfoPage from './pages/PublicInfoPage';
import PublicDocumentationInfoPage from './pages/PublicDocumentationInfoPage';
import StatisticsPage from './pages/StatisticsPage';
import OnlineBullyingPage from './pages/OnlineBullyingPage';
import OnlineComparisonPage from './pages/OnlineComparisonPage';
import ResourcesPage from './pages/ResourcesPage';
import AboutPage from './pages/AboutPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import KidsHomePage from './pages/kids/KidsHomePage';
import KidsSafeOnlinePage from './pages/kids/KidsSafeOnlinePage';
import KidsBullyingPage from './pages/kids/KidsBullyingPage';
import KidsFeelingsPage from './pages/kids/KidsFeelingsPage';
import KidsHelpPage from './pages/kids/KidsHelpPage';
import KidsResourcesPage from './pages/kids/KidsResourcesPage';
import KidsGamesPage from './pages/kids/KidsGamesPage';
import SourcesPage from './pages/SourcesPage';
import PublicGamesPage from './pages/PublicGamesPage';
import PublicLayout from './components/layouts/PublicLayout';
import AppLayout from './components/layouts/AppLayout';
import KidsLayout from './components/layouts/KidsLayout';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** Accessible without login. Routes without this flag require authentication. Has no effect when RouteGuard is not in use. */
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <PublicInfoPage />,
    public: true,
  },
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />,
    public: true,
  },
  // Public routes (no login required)
  {
    name: 'Public Info',
    path: '/public/info',
    element: <PublicInfoPage />,
    public: true,
  },
  {
    name: 'Statistics',
    path: '/public/statistics',
    element: <StatisticsPage />,
    public: true,
  },
  {
    name: 'Public Prevention',
    path: '/public/prevention',
    element: <PublicLayout><PreventionStatsPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Public Social & Emotional',
    path: '/public/social-emotional',
    element: <PublicLayout><SocialEmotionalPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Public Action',
    path: '/public/action',
    element: <PublicLayout><ActionHealingPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Public Documentation',
    path: '/public/documentation',
    element: <PublicDocumentationInfoPage />,
    public: true,
  },
  {
    name: 'Public Laws',
    path: '/public/laws',
    element: <PublicLayout><CybersecurityLawsPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Public Bullying',
    path: '/public/bullying',
    element: <PublicLayout><OnlineBullyingPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Digital Threats',
    path: '/public/digital-threats',
    element: <PublicLayout><DigitalThreatsPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Public Comparison',
    path: '/public/comparison',
    element: <PublicLayout><OnlineComparisonPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Public Resources',
    path: '/public/resources',
    element: <PublicLayout><ResourcesPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Public Games',
    path: '/public/games',
    element: <PublicGamesPage />,
    public: true,
  },
  {
    name: 'About',
    path: '/public/about',
    element: <PublicLayout><AboutPage /></PublicLayout>,
    public: true,
  },
  {
    name: 'Sources',
    path: '/public/sources',
    element: <SourcesPage />,
    public: true,
  },
  {
    name: 'Terms of Use',
    path: '/terms',
    element: <TermsPage />,
    public: true,
    visible: false,
  },
  {
    name: 'Privacy Policy',
    path: '/privacy',
    element: <PrivacyPage />,
    public: true,
    visible: false,
  },
  // Kids routes
  {
    name: 'Kids Home',
    path: '/kids',
    element: <KidsLayout><KidsHomePage /></KidsLayout>,
    public: true,
  },
  {
    name: 'Kids Stay Safe Online',
    path: '/kids/safe-online',
    element: <KidsLayout><KidsSafeOnlinePage /></KidsLayout>,
    public: true,
  },
  {
    name: 'Kids Bullying',
    path: '/kids/bullying',
    element: <KidsLayout><KidsBullyingPage /></KidsLayout>,
    public: true,
  },
  {
    name: 'Kids Feelings',
    path: '/kids/feelings',
    element: <KidsLayout><KidsFeelingsPage /></KidsLayout>,
    public: true,
  },
  {
    name: 'Kids Ask for Help',
    path: '/kids/help',
    element: <KidsLayout><KidsHelpPage /></KidsLayout>,
    public: true,
  },
  {
    name: 'Kids Resources',
    path: '/kids/resources',
    element: <KidsLayout><KidsResourcesPage /></KidsLayout>,
    public: true,
  },
  {
    name: 'Kids Games',
    path: '/kids/games',
    element: <KidsLayout><KidsGamesPage /></KidsLayout>,
    public: true,
  },
  // Authenticated routes
  {
    name: 'Guide',
    path: '/guide',
    element: <GuidePage />,
  },
  {
    name: 'Prevention & Stats',
    path: '/prevention',
    element: <AppLayout><PreventionStatsPage /></AppLayout>,
  },
  {
    name: 'Documentation',
    path: '/documentation',
    element: <DocumentationPage />,
  },
  {
    name: 'Social & Emotional Impact',
    path: '/social-emotional',
    element: <AppLayout><SocialEmotionalPage /></AppLayout>,
  },
  {
    name: 'Action & Healing',
    path: '/action',
    element: <AppLayout><ActionHealingPage /></AppLayout>,
  },
  {
    name: 'Cybersecurity Laws',
    path: '/laws',
    element: <AppLayout><CybersecurityLawsPage /></AppLayout>,
  },
  {
    name: 'Online Bullying',
    path: '/bullying',
    element: <AppLayout><OnlineBullyingPage /></AppLayout>,
  },
  {
    name: 'Digital Threats',
    path: '/digital-threats',
    element: <AppLayout><DigitalThreatsPage /></AppLayout>,
  },
  {
    name: 'Online Comparison',
    path: '/comparison',
    element: <AppLayout><OnlineComparisonPage /></AppLayout>,
  },
];
