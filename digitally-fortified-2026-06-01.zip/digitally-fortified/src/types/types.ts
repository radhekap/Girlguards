// Type definitions for Digitally Fortified application

export interface IdentityInfo {
  usernames: string;
  realName: string;
  otherDetails: string;
}

export interface EvidenceFile {
  id: string;
  fileName: string;
  fileData: string;
  hash: string;
  uploadedAt: string;
}

export interface TimelineEntry {
  id: string;
  date: string;
  time: string;
  platform: string;
  description: string;
  createdAt: string;
}

export interface ImpactData {
  reportsFiled: string;
  impactJournal: string;
}

export interface ReportData {
  identity: IdentityInfo;
  timeline: TimelineEntry[];
  impact: ImpactData;
  evidence: EvidenceFile[];
  generatedAt: string;
}
