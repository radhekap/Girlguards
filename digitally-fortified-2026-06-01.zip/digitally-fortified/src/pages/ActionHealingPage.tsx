import { useState } from 'react';
import { AlertCircle, Lock, Ban, Shield, Flag, Phone, BookOpen, Users, Heart, CheckSquare, Square, Copy, Check } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
  grad: 'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

const situationGuides: Record<string, { label: string; urgency: 'immediate' | 'soon' | 'ongoing'; summary: string; prioritySteps: string[]; who: string }> = {
  threats: {
    label: 'I received threats or am being blackmailed',
    urgency: 'immediate',
    summary: "Threats and blackmail (including sextortion) are crimes — not just platform violations. Your safety comes first.",
    prioritySteps: [
      "Do NOT comply with demands or send money. It never stops the abuse.",
      "Screenshot every threat with timestamps before blocking the person.",
      "Tell a parent or trusted adult immediately, today — you should not handle this alone.",
      "Call 988 if you're in emotional distress. File a police report with your screenshots.",
    ],
    who: "Report to: Police (call non-emergency line or 911 if immediate danger), FBI IC3 (ic3.gov), and the platform.",
  },
  images: {
    label: 'Intimate images were shared without my consent',
    urgency: 'immediate',
    summary: "This is image-based abuse — it is a crime in most countries. You are a victim. You did nothing wrong.",
    prioritySteps: [
      "Go to StopNCII.org immediately — they can prevent the image spreading further across platforms.",
      "Report to the platform using their image removal tool (most have a priority process).",
      "Tell a trusted adult or call RAINN at 1-800-656-4673.",
      "Do NOT delete any evidence. Screenshot what you can before reporting.",
    ],
    who: "Report to: Platform image removal team, NCMEC (cybertip.org if you're under 18), local police, RAINN (1-800-656-4673).",
  },
  harassment: {
    label: "I'm being harassed repeatedly online",
    urgency: 'soon',
    summary: "Repeated harassment is cyberbullying and often crosses into criminal territory. You have every right to act.",
    prioritySteps: [
      "Stop responding to the harasser entirely — any response signals you're still engaged.",
      "Screenshot every message or post with date and username visible.",
      "Block on every platform, but do it after screenshotting — blocking deletes your view of messages.",
      "Report to the platform and tell a trusted adult. If it's a classmate, report to school too.",
    ],
    who: "Report to: The platform, your school (if it involves classmates), local police if it escalates to threats.",
  },
  accounts: {
    label: 'My accounts were hacked or someone is impersonating me',
    urgency: 'soon',
    summary: "Account takeovers and impersonation are forms of identity fraud. Act quickly before more damage is done.",
    prioritySteps: [
      "Change passwords on ALL accounts immediately, starting with your email (everything connects to email).",
      "Enable two-factor authentication on every account that offers it.",
      "For impersonation accounts: report them directly to the platform as 'fake account pretending to be me'.",
      "Tell your close friends and followers so they know not to interact with the fake account.",
    ],
    who: "Report to: The platform's fake account / impersonation report form, and local police if it's causing active harm.",
  },
  rumors: {
    label: 'False rumours or fake content are being spread about me',
    urgency: 'ongoing',
    summary: "Spreading false information designed to damage your reputation is defamation — legally actionable in many cases.",
    prioritySteps: [
      "Document everything: screenshot all posts, comments, and accounts spreading false information.",
      "Report each post to the platform for harassment, defamation, or misinformation.",
      "Don't argue publicly with every post — it amplifies the rumour. Silence is often more powerful.",
      "Talk to a trusted adult. If it's affecting school, report to staff. If it's severe, consult a lawyer.",
    ],
    who: "Report to: The platform, your school (if classmates are involved). Keep evidence for potential legal action.",
  },
};


function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <button onClick={handleCopy}
      className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-primary transition-colors shrink-0 ml-auto pl-2">
      {copied
        ? <><Check className="h-3 w-3 text-primary" strokeWidth={2} /><span className="text-primary">Copied</span></>
        : <><Copy className="h-3 w-3" strokeWidth={1.75} /><span>Copy</span></>}
    </button>
  );
}

export default function ActionHealingPage() {
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [situation, setSituation] = useState<string>('');

  const toggleStep = (n: number) =>
    setCompletedSteps(prev => { const s = new Set(prev); s.has(n) ? s.delete(n) : s.add(n); return s; });
  const steps = [
    {
      number: 1, icon: AlertCircle,
      title: "Don't Delete Evidence",
      content: [
        "Keep all messages, screenshots, and posts — even if they're upsetting to look at",
        'Take screenshots before content disappears (Snapchat, Instagram stories, etc.)',
        "Don't edit or crop screenshots — keep them exactly as they are",
        'Save everything to multiple places if possible (your device, a USB drive, cloud storage)',
        'Write down usernames, dates, and times while you remember them',
      ],
      why: "Evidence is crucial for reporting to authorities, schools, or platforms. Without it, it's much harder to take action or prove what happened.",
    },
    {
      number: 2, icon: Ban,
      title: "Don't Pay or Comply with Demands",
      content: [
        'Never send money, gift cards, or cryptocurrency in response to threats',
        "Don't send more images or information if someone is blackmailing you",
        "Don't comply with demands — paying or complying usually makes things worse",
        'Sextortion (threatening to share images unless you pay) is a crime — you are the victim',
        "Contact authorities immediately if you're being threatened or extorted",
      ],
      why: "Paying or complying rarely stops the abuse. Abusers often demand more, and you'll have less leverage once you've given in.",
    },
    {
      number: 3, icon: Lock,
      title: 'Secure Your Accounts Immediately',
      content: [
        'Change passwords on ALL your accounts right now (use strong, unique passwords)',
        'Enable two-factor authentication (2FA) on every platform that offers it',
        "Check \"Login Activity\" or \"Where You're Logged In\" and log out of unfamiliar devices",
        "Review connected apps and revoke access to anything you don't recognize",
        'Make all social media accounts private and review who can contact you',
        'Consider creating new accounts if someone has access to your current ones',
      ],
      why: "If someone has your password or access to your accounts, they can impersonate you or continue to harass you. Securing your accounts gives you back control.",
    },
    {
      number: 4, icon: Flag,
      title: 'Report to Multiple Places',
      content: [
        'Platform reporting: Use the report feature on Instagram, Snapchat, TikTok, Discord, etc.',
        "NCMEC CyberTipline: Report to cybertip.org if you're under 18 and it involves explicit content",
        'Local police: File a report for serious threats, extortion, stalking, or explicit images',
        'School: Tell a counselor, principal, or trusted teacher if it involves classmates',
        'FBI IC3: Report to ic3.gov for serious cybercrimes, especially if it crosses state lines',
        'Tell a trusted adult: Parent, guardian, older sibling, teacher, or counselor',
      ],
      why: "Different organizations can help in different ways. Platforms can remove content and ban users. Police can investigate crimes. Schools can take disciplinary action.",
    },
  ];

  const supportGroups = [
    {
      icon: Phone,
      title: 'Crisis & Immediate Help',
      items: [
        { label: 'Crisis Text Line', detail: 'Text HOME to 741741 (24/7, free, confidential support for any crisis)' },
        { label: 'National Suicide Prevention Lifeline', detail: 'Call or text 988 (24/7 crisis support)' },
        { label: 'RAINN Sexual Assault Hotline', detail: '1-800-656-4673 (24/7 support for sexual assault survivors)' },
        { label: 'National Domestic Violence Hotline', detail: '1-800-799-7233 or text START to 88788' },
      ],
    },
    {
      icon: Flag,
      title: 'Reporting & Legal Help',
      items: [
        { label: 'NCMEC CyberTipline', detail: 'cybertip.org — report child exploitation' },
        { label: 'FBI Internet Crime Complaint Center', detail: 'ic3.gov — report serious cybercrimes' },
        { label: 'Cyber Civil Rights Initiative', detail: 'cybercivilrights.org — help with image-based abuse' },
        { label: 'Take It Down', detail: 'takeitdown.ncmec.org — remove explicit images of minors from the internet' },
      ],
    },
    {
      icon: BookOpen,
      title: 'Mental Health & Counseling',
      items: [
        { label: 'School counselor', detail: 'Free, confidential, and they can help you talk to your parents if needed' },
        { label: 'Teen Line', detail: 'Call 310-855-4673 or text TEEN to 839863 (teens helping teens, 6pm-10pm PT)' },
        { label: '7 Cups', detail: '7cups.com — free online therapy and emotional support' },
        { label: 'BetterHelp for Teens', detail: 'Online therapy (requires parent permission if under 18)' },
      ],
    },
    {
      icon: Users,
      title: 'Talking to Parents or Guardians',
      items: [
        { label: 'Choose a calm time', detail: "When they're not busy or stressed" },
        { label: 'Opening words', detail: '"Something happened online and I need help. I need your support."' },
        { label: 'Show documentation', detail: 'Show them the documentation you\'ve created in this tool' },
        { label: 'Other trusted adults', detail: 'Aunt/uncle, older sibling, teacher, coach, or friend\'s parent' },
      ],
    },
  ];

  const reportingExpectations = [
    { title: 'Reporting to Platforms (Instagram, Snapchat, etc.)', desc: "They'll review your report (usually within 24-48 hours), may remove content, and might ban the user. You'll get a notification about their decision. If they don't take action, you can appeal or report to other authorities." },
    { title: 'Reporting to Police', desc: "You'll give a statement describing what happened. Bring all your evidence (screenshots, usernames, dates). They'll create a report with a case number. Investigation can take time. You might be assigned a detective or victim advocate." },
    { title: 'Reporting to School', desc: "Schools are required to investigate harassment and bullying. They can take disciplinary action against students, provide counseling support, and create safety plans." },
    { title: 'Your Rights', desc: "You have the right to be believed, to have your privacy protected, to have a support person with you, to ask questions, and to get updates on your case." },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">

      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Recovery Guide</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight">Action & Healing</h1>
        <p className="text-base text-muted-foreground">
          Practical steps to take right now and resources for recovery.
        </p>
      </div>

      {/* Situation selector */}
      <section className="space-y-4 animate-fade-in">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Heart className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">What's your situation?</h2>
            <p className="text-sm text-muted-foreground">Get the most relevant steps for what you're going through</p>
          </div>
        </div>
        <Select value={situation} onValueChange={setSituation}>
          <SelectTrigger className="w-full max-w-sm h-11 text-sm">
            <SelectValue placeholder="Select what happened…" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(situationGuides).map(([key, val]) => (
              <SelectItem key={key} value={key}>{val.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {situation && situationGuides[situation] && (() => {
          const guide = situationGuides[situation];
          const urgencyStyle = guide.urgency === 'immediate'
            ? { badge: 'Act right now', badgeCls: 'bg-destructive/10 text-destructive border-destructive/30', border: 'border-destructive/30' }
            : guide.urgency === 'soon'
            ? { badge: 'Act soon', badgeCls: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30', border: 'border-amber-500/25' }
            : { badge: 'Ongoing support', badgeCls: 'bg-primary/10 text-primary border-primary/30', border: 'border-primary/25' };
          return (
            <div className={['rounded-xl border p-5 space-y-4 animate-fade-in', urgencyStyle.border].join(' ')}>
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <p className="text-sm text-muted-foreground text-pretty flex-1">{guide.summary}</p>
                <span className={['text-xs font-semibold px-2.5 py-1 rounded-full border shrink-0', urgencyStyle.badgeCls].join(' ')}>
                  {urgencyStyle.badge}
                </span>
              </div>
              <div className="space-y-2.5 border-t pt-4">
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Priority steps</p>
                {guide.prioritySteps.map((step, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0 mt-0.5"
                      style={{ background: G.grad }}>{i + 1}</div>
                    <p className="text-sm text-muted-foreground text-pretty">{step}</p>
                  </div>
                ))}
              </div>
              <div className="flex items-start gap-2.5 rounded-lg border border-border bg-muted/40 px-4 py-3">
                <Shield className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.75} />
                <p className="text-sm text-muted-foreground text-pretty">
                  <strong className="text-foreground">Who to tell: </strong>{guide.who}
                </p>
              </div>
            </div>
          );
        })()}
      </section>

      {/* Disclaimer */}
      <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3">
        <AlertCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
        <div className="space-y-0.5">
          <p className="text-sm font-medium text-foreground">Educational Information Only</p>
          <p className="text-sm text-muted-foreground text-pretty">
            This page provides general guidance for educational purposes and does not constitute
            legal, medical, or mental health advice. If you are in immediate danger, call emergency
            services (911 or your local equivalent). For mental health support, please reach out
            to a qualified counsellor, therapist, or crisis line.
          </p>
        </div>
      </div>

      {/* Numbered action steps — progress tracker */}
      <section className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
        {/* Progress bar */}
        {completedSteps.size > 0 && (
          <div className="space-y-1.5 animate-fade-in">
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">Progress</p>
              <p className="text-xs font-medium text-primary">{completedSteps.size} of {steps.length} steps done</p>
            </div>
            <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
              <div className="h-full rounded-full transition-all duration-500 ease-out"
                style={{ width: `${(completedSteps.size / steps.length) * 100}%`, background: G.grad }} />
            </div>
          </div>
        )}
        {completedSteps.size === steps.length && (
          <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3 animate-fade-in">
            <Heart className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
            <p className="text-sm text-muted-foreground text-pretty">
              <strong className="text-foreground">You've gone through every step.</strong> That took courage. Please reach out to a trusted adult or crisis line if you need more support.
            </p>
          </div>
        )}
        {steps.map((step) => {
          const Icon = step.icon;
          const done = completedSteps.has(step.number);
          return (
            <div key={step.number} className={['rounded-xl border overflow-hidden transition-all duration-200',
              done ? 'border-primary/30 bg-primary/5' : 'border-border'].join(' ')}>
              <div className="flex items-center gap-3 px-5 py-3 border-b border-border/60">
                <div className="h-7 w-7 rounded-full flex items-center justify-center text-sm font-semibold text-white shrink-0"
                  style={{ background: G.grad }}>{step.number}</div>
                <div className="h-7 w-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                  <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
                </div>
                <h2 className="text-base font-medium text-foreground flex-1">{step.title}</h2>
                <button onClick={() => toggleStep(step.number)}
                  className="shrink-0 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors">
                  {done
                    ? <><CheckSquare className="h-4 w-4 text-primary" strokeWidth={1.75} /><span className="text-primary text-xs hidden sm:inline">Done</span></>
                    : <><Square className="h-4 w-4" strokeWidth={1.5} /><span className="text-xs hidden sm:inline">Mark done</span></>}
                </button>
              </div>
              <div className={['px-5 py-4 space-y-3 transition-opacity', done ? 'opacity-50' : 'opacity-100'].join(' ')}>
                <div className="space-y-2">
                  {step.content.map((item) => (
                    <div key={item} className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary shrink-0 mt-2" />
                      <p className="text-sm text-muted-foreground text-pretty">{item}</p>
                    </div>
                  ))}
                </div>
                <div className="pt-3 border-t border-border flex items-start gap-2">
                  <Shield className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
                  <p className="text-xs text-muted-foreground text-pretty"><strong className="text-foreground">Why this matters:</strong> {step.why}</p>
                </div>
              </div>
            </div>
          );
        })}
      </section>

      {/* Support & Resources */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0 border border-primary/30">
            <Shield className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Get Support & Help</h2>
            <p className="text-sm text-muted-foreground">You don't have to go through this alone</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {supportGroups.map(({ icon: Icon, title, items }) => (
            <div key={title} className="rounded-xl border border-border p-4 space-y-3 h-full flex flex-col">
              <div className="flex items-center gap-2">
                <div className="h-7 w-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                  <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
                </div>
                <p className="text-sm font-medium text-foreground">{title}</p>
              </div>
              <div className="space-y-2 flex-1">
                {items.map(({ label, detail }) => {
                  // Extract copyable number/contact from detail
                  const copyMatch = detail.match(/[\d\-]{7,}|text [A-Z]+ to \d+|online\.[a-z.]+/i);
                  const copyText = copyMatch ? copyMatch[0] : '';
                  return (
                    <div key={label} className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary shrink-0 mt-1.5" />
                      <div className="min-w-0 flex-1">
                        <p className="text-xs text-muted-foreground text-pretty">
                          <strong className="text-foreground">{label}:</strong> {detail}
                        </p>
                      </div>
                      {copyText && <CopyButton text={copyText} />}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-primary/20 p-4 flex items-start gap-3">
          <Heart className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
          <p className="text-sm text-muted-foreground text-pretty">
            <strong className="text-foreground">You are not alone:</strong> Millions of teen girls experience online abuse. What happened is not your fault. You deserve support, safety, and healing. Taking action is brave, and there are people who want to help you.
          </p>
        </div>
      </section>

      {/* What to Expect */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <BookOpen className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">What to Expect When You Report</h2>
            <p className="text-sm text-muted-foreground">Understanding the process can make it less scary</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {reportingExpectations.map(({ title, desc }) => (
            <div key={title} className="rounded-xl border border-border p-4 space-y-1.5 h-full">
              <p className="text-sm font-medium text-foreground">{title}</p>
              <p className="text-xs text-muted-foreground text-pretty">{desc}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}


