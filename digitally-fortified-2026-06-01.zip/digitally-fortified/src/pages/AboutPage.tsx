import { Card, CardContent, CardHeader, CardTitle } from'@/components/ui/card';
import { Heart, Shield, Sparkles, Target } from'lucide-react';

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">
      <div className="space-y-4">
        <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">About girlGuard</h1>
        <p className="text-lg text-muted-foreground text-pretty">
          Created by a teen, for teens — because we deserve to feel safe online
        </p>
      </div>

      {/* Creator Story */}
      <Card className="border-2 border-primary/30">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl flex items-center justify-center shrink-0" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
              <Heart className="h-6 w-6 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <CardTitle className="text-2xl font-light">From the Creator</CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4 text-muted-foreground text-pretty">
            <p className="text-base leading-relaxed">
              Hi, I'm a 17-year-old girl who created girlGuard because I saw firsthand the problems that girls face online every single day.
            </p>
            <p className="text-base leading-relaxed">
              I watched friends deal with harassment, comparison, and feeling unsafe in spaces that should be fun and connecting. I saw how confusing it was to know what to do when something bad happened, or where to turn for help that actually understood what we're going through.
            </p>
            <p className="text-base leading-relaxed">
              I realized that we needed a place that wasn't just another lecture from adults who don't get it. We needed real resources, practical tools, and honest information — all in one place that actually speaks our language and understands our reality.
            </p>
            <p className="text-base leading-relaxed">
              So I built girlGuard: a safe space where girls have everything they need to stay safe online, understand their rights, report what's happening to them, and navigate the internet with confidence instead of fear.
            </p>
            <p className="text-base leading-relaxed">
              This isn't about scaring you away from the internet or telling you what to do. It's about empowering you with knowledge, giving you tools that actually work, and making sure you know you're not alone in whatever you're facing.
            </p>
            <p className="text-base leading-relaxed font-medium text-foreground">
              You deserve to feel safe online. You deserve to know your rights. And you deserve resources that actually help.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Mission */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl flex items-center justify-center shrink-0" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
              <Target className="h-6 w-6 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <CardTitle className="text-2xl font-light">Our Mission</CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="p-4 rounded-lg bg-muted/50 space-y-2">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" strokeWidth={2.5} />
                <p className="font-medium">Provide Resources</p>
              </div>
              <p className="text-sm text-muted-foreground text-pretty">
                Give girls access to practical tools, information, and support they can actually use when they need it most
              </p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50 space-y-2">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" strokeWidth={2.5} />
                <p className="font-medium">Empower Action</p>
              </div>
              <p className="text-sm text-muted-foreground text-pretty">
                Help girls understand their rights, know how to report abuse, and take action to protect themselves
              </p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50 space-y-2">
              <div className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-primary" strokeWidth={2.5} />
                <p className="font-medium">Create Safety</p>
              </div>
              <p className="text-sm text-muted-foreground text-pretty">
                Build a safe space where girls can find support, learn, and feel less alone in what they're experiencing
              </p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50 space-y-2">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" strokeWidth={2.5} />
                <p className="font-medium">Reduce Uncertainty</p>
              </div>
              <p className="text-sm text-muted-foreground text-pretty">
                Give girls the knowledge and confidence to use the internet without constant fear or confusion about what to do
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* What Makes Us Different */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-light">What Makes girlGuard Different</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-3">
              <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
              <span className="text-muted-foreground">
                <strong className="text-foreground">Created by a teen:</strong> Built by someone who actually understands what you're going through, not adults guessing
              </span>
            </li>
            <li className="flex items-start gap-3">
              <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
              <span className="text-muted-foreground">
                <strong className="text-foreground">Real, practical advice:</strong> No lectures or scare tactics — just honest information and actionable steps
              </span>
            </li>
            <li className="flex items-start gap-3">
              <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
              <span className="text-muted-foreground">
                <strong className="text-foreground">Everything in one place:</strong> Resources, tools, documentation, support — all organized and easy to find
              </span>
            </li>
            <li className="flex items-start gap-3">
              <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
              <span className="text-muted-foreground">
                <strong className="text-foreground">Speaks your language:</strong> Written the way we actually talk, not in formal adult-speak
              </span>
            </li>
            <li className="flex items-start gap-3">
              <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
              <span className="text-muted-foreground">
                <strong className="text-foreground">Empowerment-focused:</strong> About giving you power and knowledge, not making you feel helpless or scared
              </span>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Closing Message */}
      <Card className="border-2 border-primary/20">
        <CardContent className="p-6 space-y-3">
          <p className="text-base text-muted-foreground text-pretty">
            girlGuard is a passion project built with care, research, and a genuine desire to help. It's not perfect, and it's always evolving based on what girls actually need.
          </p>
          <p className="text-base text-muted-foreground text-pretty">
            If you have feedback, suggestions, or just want to share your story, I'm listening. This platform exists for you, and your voice matters in making it better.
          </p>
          <p className="text-base font-medium text-foreground text-pretty">
            Stay safe, stay strong, and remember — you're never alone in this. 
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
