import { useState, useEffect } from 'react';
import AppLayout from '@/components/layouts/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { storage } from '@/lib/storage';
import type { TimelineEntry } from '@/types/types';
import { Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function TimelinePage() {
  const [timeline, setTimeline] = useState<TimelineEntry[]>(() => storage.getTimeline());
  const [formData, setFormData] = useState({
    date: '',
    time: '',
    platform: '',
    description: '',
  });
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    storage.setTimeline(timeline);
  }, [timeline]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.date || !formData.time || !formData.platform || !formData.description) {
      toast.error('All fields are required');
      return;
    }

    const newEntry: TimelineEntry = {
      id: crypto.randomUUID(),
      date: formData.date,
      time: formData.time,
      platform: formData.platform,
      description: formData.description,
      createdAt: new Date().toISOString(),
    };

    const updatedTimeline = [...timeline, newEntry].sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`);
      const dateB = new Date(`${b.date}T${b.time}`);
      return dateB.getTime() - dateA.getTime();
    });

    setTimeline(updatedTimeline);
    setFormData({ date: '', time: '', platform: '', description: '' });
    toast.success('Incident added to timeline');
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const updatedTimeline = timeline.filter(entry => entry.id !== deleteId);
    setTimeline(updatedTimeline);
    setDeleteId(null);
    toast.success('Incident deleted');
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-light tracking-tight">Timeline</h1>
          <p className="text-lg text-muted-foreground">
            Log every interaction to build a pattern of behavior over time.
          </p>
        </div>

        {/* Add Incident Form */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-light">Add Incident</CardTitle>
            <CardDescription>
              Record details about each incident as it happens.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Time</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.time}
                    onChange={(e) => handleInputChange('time', e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="platform">Platform</Label>
                <Input
                  id="platform"
                  placeholder="e.g., Snapchat, Instagram, Discord, Text Message"
                  value={formData.platform}
                  onChange={(e) => handleInputChange('platform', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what happened in detail"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  rows={6}
                />
              </div>

              <Button type="submit" className="w-full md:w-auto">
                Save to Timeline
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Timeline List */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-light">Timeline</CardTitle>
            <CardDescription>
              {timeline.length === 0 
                ? 'No incidents recorded yet' 
                : `${timeline.length} incident${timeline.length === 1 ? '' : 's'} recorded`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {timeline.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                Start documenting incidents using the form above.
              </p>
            ) : (
              <div className="space-y-4">
                {timeline.map((entry) => (
                  <Card key={entry.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-4 text-sm">
                            <span className="font-medium">
                              {new Date(entry.date).toLocaleDateString()}
                            </span>
                            <span className="text-muted-foreground">{entry.time}</span>
                            <span className="px-2 py-1 bg-muted rounded text-xs">
                              {entry.platform}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                            {entry.description}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDeleteId(entry.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Incident?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This incident will be permanently removed from your timeline.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
