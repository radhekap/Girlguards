import { useState, useRef } from'react';
import { useNavigate } from'react-router-dom';
import { useAuth } from'@/contexts/AuthContext';
import { Input } from'@/components/ui/input';
import { Label } from'@/components/ui/label';
import {
  Shield, Lock, ArrowRight, Eye, EyeOff,
  FileText, Hash, Clock, Activity, Download, HeartHandshake,
  CheckCircle2, TrendingUp, Scale, BookOpen,
  LifeBuoy, ExternalLink,
} from'lucide-react';
import AnimatedCounter from'@/components/AnimatedCounter';

// ─── DATA ─────────────────────────────────────────────────────────────────────

const proofPoints = [
  { label:'Completely free' },
  { label:'No email required' },
  { label:'Stored on your device only' },
  { label:'Works offline' },
  { label:'No tech skills needed' },
];

const animatedStats = [
  { end: 72,  suffix:'%', label:'of online harassment victims are women',          path:'/public/statistics' },
  { end: 90,  suffix:'%', label:'of image-based abuse targets are female',         path:'/public/statistics' },
  { end: 68,  suffix:'%', label:'of online abuse happens on social media',         path:'/public/prevention' },
  { end: 26,  suffix:'%', label:'of young women report being cyberstalked',        path:'/public/statistics' },
];

const features = [
  {
    icon: FileText,
    title:'Build a solid case',
    desc:'Organise screenshots, messages, and dates into a clear incident record.',
    path:'/public/documentation',
  },
  {
    icon: Hash,
    title:'Prove nothing was altered',
    desc:'Cryptographic hashes confirm your evidence is original and untampered.',
    path:'/public/documentation',
  },
  {
    icon: Clock,
    title:'Track a pattern over time',
    desc:'Every log entry is timestamped so you can show escalation clearly.',
    path:'/public/statistics',
  },
  {
    icon: Activity,
    title:'Record the real impact',
    desc:'Capture the emotional, social, and academic effects that courts consider.',
    path:'/public/social-emotional',
  },
  {
    icon: Download,
    title:'Generate a report instantly',
    desc:'Export a professional summary ready to hand to school, police, or a lawyer.',
    path:'/public/documentation',
  },
  {
    icon: HeartHandshake,
    title:'Find help and next steps',
    desc:'Access crisis lines, legal guides, and counselling resources in one place.',
    path:'/public/action',
  },
];

const exploreSections = [
  {
    icon: TrendingUp,
    title:'Statistics & Research',
    desc:'See the real numbers behind online harassment',
    path:'/public/statistics',
  },
  {
    icon: Shield,
    title:'Prevention & Awareness',
    desc:'Practical tips to protect yourself',
    path:'/public/prevention',
  },
  {
    icon: HeartHandshake,
    title:'Social & Emotional Wellbeing',
    desc:'How online harassment affects you mentally',
    path:'/public/social-emotional',
  },
  {
    icon: LifeBuoy,
    title:'Response & Support',
    desc:'What to do right now if something is happening',
    path:'/public/action',
  },
  {
    icon: Scale,
    title:'Legal Information',
    desc:'Know your rights and what the law says',
    path:'/public/laws',
  },
  {
    icon: BookOpen,
    title:'Online Bullying Guide',
    desc: "Recognise patterns and understand what's happening",
    path:'/public/bullying',
  },
  {
    icon: ExternalLink,
    title:'External Resources',
    desc:'Trusted organisations and helplines ready to assist',
    path:'/public/resources',
  },
];

const quickHelp = [
  { label:'Someone is harassing me online',     sub:'Mean messages, rumors, or exclusion',          path:'/public/bullying' },
  { label:'Social media is making me feel bad', sub:'Comparison, FOMO, or self-esteem issues',       path:'/public/comparison' },
  { label:'I need help right now',              sub:'Immediate steps and crisis resources',           path:'/public/action' },
  { label:'I want to prevent this happening',   sub:'Prevention tips and privacy settings',          path:'/public/prevention' },
  { label:'I need to document something',       sub:'Save evidence and build a proper record',       path:'/public/documentation' },
  { label:'I want to understand the law',       sub: "What's legal, what's not, and your rights",     path:'/public/laws' },
];

const trustPoints = [
'Your data never leaves your device',
'No account required to read our guides',
'Open source evidence-hashing — verifiable by anyone',
'No ads, no tracking, no data sharing — ever',
];

const steps = [
  {
    num:'01',
    title:'Read without signing up',
    desc:'Every safety guide, law explainer, and resource is free with no account.',
  },
  {
    num:'02',
    title:'Create your private space',
    desc:'Choose a name and passcode. Nothing is sent anywhere — setup takes 20 seconds.',
  },
  {
    num:'03',
    title:'Document, report, and heal',
    desc:'Log incidents, lock in evidence, generate a report, and access support.',
  },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function SectionRule() {
  return <div className="max-w-5xl mx-auto px-6 md:px-12"><div className="border-t border-border" /></div>;
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

export default function LoginPage() {
  const [mode, setMode] = useState<'signin' |'create'>('signin');
  const [name, setName] = useState('');
  const [passcode, setPasscode] = useState('');
  const [confirmPasscode, setConfirmPasscode] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const { login, createAccount } = useAuth();
  const navigate = useNavigate();
  const authRef = useRef<HTMLDivElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (mode ==='create') {
      const result = createAccount(name, passcode, confirmPasscode);
      if (result.success) navigate('/guide');
      else setError(result.error ||'Account creation failed');
    } else {
      const result = login(name, passcode);
      if (result.success) navigate('/guide');
      else setError(result.error ||'Login failed');
    }
  };

  const toggleMode = () => {
    setMode(m => (m ==='signin' ?'create' :'signin'));
    setError(''); setName(''); setPasscode(''); setConfirmPasscode('');
  };

  const scrollToAuth = (startMode:'create' |'signin' ='create') => {
    setMode(startMode);
    authRef.current?.scrollIntoView({ behavior:'smooth', block:'center' });
  };

  return (
    <div className="min-h-screen w-full bg-background flex flex-col overflow-x-hidden">

      {/* ── TOP NAV ───────────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-20 bg-background border-b border-border">
        <div className="max-w-5xl mx-auto px-6 md:px-12 h-14 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="h-7 w-7 rounded-lg flex items-center justify-center shrink-0"
              style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
              <Shield className="h-4 w-4 text-white" strokeWidth={2.5} />
            </div>
            <span className="font-semibold text-sm tracking-tight text-foreground">girlGuard</span>
          </div>
          {/* Right: nav links + CTA */}
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/public/info')}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors hidden sm:block">
              Explore freely
            </button>
            <button onClick={() => navigate('/kids')}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors hidden sm:block">
              kidsGuard
            </button>
            <button onClick={() => scrollToAuth('create')}
              className="h-8 px-4 rounded-lg text-xs font-semibold text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
              Get started
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full relative">

        {/* ambient blobs rendered by outer fixed layer */}

        {/* ── HERO ──────────────────────────────────────────────────────── */}
        <section className="max-w-5xl mx-auto px-6 md:px-12 pt-12 pb-10 md:pt-16 md:pb-14
                             grid md:grid-cols-[1fr_360px] gap-10 md:gap-14 items-start">

          {/* LEFT: value proposition */}
          <div className="space-y-7 animate-slide-up">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground animate-fade-in"
              style={{ animationDelay:'0.1s', animationFillMode:'backwards' }}>
              Free · Private · For girls 13+
            </p>
            <h1 className="text-4xl md:text-5xl font-light leading-[1.15] tracking-tight text-balance text-foreground
                            animate-fade-in" style={{ animationDelay:'0.2s', animationFillMode:'backwards' }}>
              You deserve to feel safe online.{''}
              <span className="gradient-text font-medium">Welcome to girlGuard.</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed text-pretty max-w-lg animate-fade-in"
              style={{ animationDelay:'0.35s', animationFillMode:'backwards' }}>
              girlGuard gives you a private space to log incidents, preserve evidence,
              and generate reports — without sharing a single byte with anyone.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-2 animate-fade-in"
              style={{ animationDelay:'0.5s', animationFillMode:'backwards' }}>
              <button onClick={() => scrollToAuth('create')}
              className="inline-flex items-center gap-2.5 h-14 px-9 rounded-xl font-semibold text-base text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
              Start documenting — it&apos;s free
              <ArrowRight className="h-5 w-5" />
            </button>
              <button onClick={() => navigate('/public/info')}
                className="h-14 px-7 rounded-xl border border-border text-base font-medium text-foreground hover:bg-muted transition-colors">
                Read guides without signing up
              </button>
            </div>
            <p className="text-sm text-muted-foreground animate-fade-in"
              style={{ animationDelay:'0.65s', animationFillMode:'backwards' }}>
              No email · No cloud storage · Your passcode never leaves this browser
            </p>

            {/* kidsGuard link */}
            <button onClick={() => navigate('/kids')}
              className="flex items-center gap-3 text-base text-muted-foreground
                         hover:text-foreground transition-colors group w-fit pt-1 animate-fade-in"
              style={{ animationDelay:'0.75s', animationFillMode:'backwards' }}>
              <div className="h-6 w-6 rounded-full flex items-center justify-center shrink-0 transition-transform group-hover:scale-110"
                style={{ background:'linear-gradient(135deg, #4A7FC1 0%, #5BC8C4 100%)' }}>
                <Shield className="h-3 w-3 text-white" strokeWidth={2.5} />
              </div>
              <span>kidsGuard for ages 8–12</span>
              <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all" />
            </button>
          </div>

          {/* RIGHT: Auth card */}
          <div id="auth-card" ref={authRef}
            className="w-full rounded-2xl border border-border bg-card p-7 space-y-5
                        opacity-0 intersect:opacity-100 transition duration-700 delay-150">
            <div className="space-y-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="h-8 w-8 rounded-lg flex items-center justify-center shrink-0" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                  <Lock className="h-3.5 w-3.5 text-white" strokeWidth={2.5} />
                </div>
                <span className="font-medium text-sm text-foreground">Your safe space</span>
              </div>
              <h2 className="text-lg font-medium text-foreground leading-snug">
                {mode ==='signin' ?'Sign in to continue' :'Create your account'}
              </h2>
              <p className="text-xs text-muted-foreground">
                {mode ==='signin'
                  ?'Enter your name and passcode to unlock.'
                  :'No email needed — just a name and passcode.'}
              </p>
            </div>
            <hr className="border-border" />
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="name" className="text-xs font-normal text-muted-foreground">Name</Label>
                <Input id="name" type="text" placeholder="Your name" value={name}
                  onChange={e => setName(e.target.value)} className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="passcode" className="text-xs font-normal text-muted-foreground">Passcode</Label>
                <div className="relative">
                  <Input id="passcode" type={showPass ?'text' :'password'} placeholder="Your passcode"
                    value={passcode} onChange={e => setPasscode(e.target.value)} className="h-9 text-sm pr-10" />
                  <button type="button" onClick={() => setShowPass(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                    {showPass ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                  </button>
                </div>
              </div>
              {mode ==='create' && (
                <div className="space-y-1.5">
                  <Label htmlFor="confirmPasscode" className="text-xs font-normal text-muted-foreground">Confirm passcode</Label>
                  <Input id="confirmPasscode" type="password" placeholder="Repeat passcode"
                    value={confirmPasscode} onChange={e => setConfirmPasscode(e.target.value)} className="h-9 text-sm" />
                </div>
              )}
              {error && (
                <p className="text-xs text-destructive bg-destructive/8 border border-destructive/20 rounded-lg px-3 py-2">
                  {error}
                </p>
              )}
              <button type="submit"
                className="w-full h-10 rounded-xl text-sm font-semibold text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
                {mode === 'signin' ? 'Unlock my space' : 'Create account'}
              </button>
            </form>
            <p className="text-center text-xs text-muted-foreground">
              {mode ==='signin' ? "Don't have an account? " :'Already have an account?'}
              <button onClick={toggleMode}
                className="text-foreground underline underline-offset-4 hover:text-primary transition-colors">
                {mode ==='signin' ?'Create account' :'Sign in'}
              </button>
            </p>
            <div className="pt-1 border-t border-border space-y-1.5">
              <p className="text-xs font-medium text-muted-foreground">Important to know</p>
              <ul className="space-y-1 text-xs text-muted-foreground list-none">
                {['Data lives on this device only','Nothing is uploaded externally','Keep your passcode safe — no recovery option'].map(t => (
                  <li key={t} className="flex items-start gap-1.5">
                    <span className="mt-0.5 text-muted-foreground/50" aria-hidden>—</span>{t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ── VALUE STRIP ───────────────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-10
                             opacity-0 intersect:opacity-100 transition duration-700">
          <div className="flex flex-wrap gap-x-8 gap-y-3">
            {proofPoints.map(({ label }) => (
              <div key={label} className="flex items-center gap-2">
                <CheckCircle2 className="h-3.5 w-3.5 text-primary shrink-0" strokeWidth={2} />
                <span className="text-sm text-muted-foreground">{label}</span>
              </div>
            ))}
          </div>
        </section>

        {/* ── ANIMATED STATS ────────────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-10 md:py-12 space-y-8">
          <div className="space-y-2 opacity-0 intersect:opacity-100 transition duration-700">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
              The reality
            </p>
            <h2 className="text-2xl md:text-3xl font-light tracking-tight text-balance">
              The numbers that make this necessary
            </h2>
            <p className="text-sm text-muted-foreground text-pretty max-w-xl">
              If you've ever felt like online harassment happens more to girls — you're right.
              Here's what the research shows.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {animatedStats.map(({ end, suffix, label, path }, i) => (
              <button
                key={label}
                onClick={() => navigate(path)}
                className="text-left space-y-2 p-5 rounded-xl border border-border bg-card
                           hover:border-primary/40 hover:scale-105
                           transition-all duration-300 cursor-pointer group
                           opacity-0 intersect:opacity-100"
                style={{ transitionDelay: `${i * 80}ms` }}>
                <p className="text-3xl md:text-4xl font-light tracking-tight gradient-text">
                  <AnimatedCounter end={end} suffix={suffix} className="inline-block" />
                </p>
                <p className="text-xs text-muted-foreground leading-snug text-pretty group-hover:text-foreground/70 transition-colors">{label}</p>
                <p className="text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                  Learn more <ArrowRight className="h-3 w-3" />
                </p>
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground italic">
            This isn&apos;t about fear — it&apos;s about being informed and prepared.{''}
            <button onClick={() => navigate('/public/statistics')}
              className="underline underline-offset-4 hover:text-foreground transition-colors">
              See all the data →
            </button>
          </p>
        </section>

        {/* ── EXPLORE SECTIONS GRID ─────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-10 md:py-12 space-y-8">
          <div className="space-y-2 opacity-0 intersect:opacity-100 transition duration-700">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
              What you can do here
            </p>
            <h2 className="text-2xl md:text-3xl font-light tracking-tight text-balance">
              Everything you need — whether you&apos;re just learning or dealing with something serious
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {exploreSections.map(({ icon: Icon, title, desc, path }, i) => (
              <button
                key={path}
                onClick={() => navigate(path)}
                className="text-left p-5 rounded-xl border border-border bg-card
                           hover:border-primary/40
                           transition-colors duration-150 cursor-pointer group
                           opacity-0 intersect:opacity-100 flex flex-col gap-3 h-full"
                style={{ transitionDelay: `${i * 50}ms` }}>
                <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 bg-primary/10
                                group-hover:bg-primary/15 transition-colors">
                  <Icon className="h-5 w-5 text-primary" strokeWidth={2} />
                </div>
                <div className="space-y-1 flex-1">
                  <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
                </div>
                <p className="text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 mt-auto">
                  Explore <ArrowRight className="h-3 w-3" />
                </p>
              </button>
            ))}
          </div>
        </section>

        {/* ── QUICK HELP ────────────────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-10 md:py-12 space-y-6
                             opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-2">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
              Quick help
            </p>
            <h2 className="text-2xl md:text-3xl font-light tracking-tight text-balance">
              Find what you need right now
            </h2>
            <p className="text-sm text-muted-foreground text-pretty">Click what matches your situation</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {quickHelp.map(({ label, sub, path }) => (
              <button
                key={path + label}
                onClick={() => navigate(path)}
                className="text-left flex items-start justify-between gap-4 p-4 rounded-xl
                           border border-border bg-card hover:border-primary/40
                           hover:scale-[1.02] transition-all duration-200 group">
                <div className="space-y-0.5 min-w-0">
                  <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{label}</p>
                  <p className="text-xs text-muted-foreground">{sub}</p>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5
                                       group-hover:text-primary group-hover:translate-x-1 transition-all" />
              </button>
            ))}
          </div>
        </section>

        {/* ── FEATURES AS BENEFITS ──────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-10 md:py-12 space-y-8">
          <div className="space-y-2 opacity-0 intersect:opacity-100 transition duration-700">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
              Documentation tools
            </p>
            <h2 className="text-2xl md:text-3xl font-light tracking-tight text-balance">
              Every tool you need, nothing you don&apos;t
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map(({ icon: Icon, title, desc, path }, i) => (
              <button
                key={title}
                onClick={() => navigate(path)}
                className="text-left flex gap-4 p-5 rounded-xl border border-border bg-card
                           hover:border-primary/40 hover:scale-[1.02]
                           transition-all duration-200 group
                           opacity-0 intersect:opacity-100"
                style={{ transitionDelay: `${i * 60}ms` }}>
                <div className="shrink-0 mt-0.5 h-9 w-9 rounded-lg border border-border
                                flex items-center justify-center group-hover:border-primary/40
                                group-hover:scale-110 group-hover:rotate-3
                                transition-all duration-300">
                  <Icon className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" strokeWidth={1.5} />
                </div>
                <div className="space-y-1 min-w-0">
                  <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{title}</p>
                  <p className="text-sm text-muted-foreground leading-relaxed text-pretty">{desc}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* ── HOW IT WORKS ──────────────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-10 md:py-12 space-y-8">
          <div className="space-y-2 opacity-0 intersect:opacity-100 transition duration-700">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
              How it works
            </p>
            <h2 className="text-2xl md:text-3xl font-light tracking-tight text-balance">
              Three steps to take back control
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            {steps.map(({ num, title, desc }, i) => (
              <div
                key={num}
                className="space-y-3 opacity-0 intersect:opacity-100 transition duration-700 group"
                style={{ transitionDelay: `${i * 100}ms` }}>
                <p className="text-4xl font-extralight text-border tracking-tight group-hover:text-primary/30 transition-colors">{num}</p>
                <p className="text-sm font-medium text-foreground">{title}</p>
                <p className="text-sm text-muted-foreground leading-relaxed text-pretty">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── TRUST / PRIVACY ───────────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-10 md:py-12 space-y-6
                             opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-2">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
              Privacy by design
            </p>
            <h2 className="text-2xl md:text-3xl font-light tracking-tight text-balance">
              Your privacy is not a feature — it&apos;s the foundation
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {trustPoints.map(item => (
              <div key={item} className="flex items-start gap-3 py-3 border-b border-border last:border-0 md:[&:nth-child(even)]:border-0">
                <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
                <span className="text-sm text-muted-foreground">{item}</span>
              </div>
            ))}
          </div>
        </section>

        {/* ── MID-PAGE CTA ──────────────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-8
                             flex flex-col md:flex-row md:items-center justify-between gap-5
                             opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-1 max-w-lg">
            <p className="text-sm font-medium text-foreground">Not ready to create an account?</p>
            <p className="text-sm text-muted-foreground text-pretty">
              Every guide, law explainer, and resource is open — no sign-up, no barriers.
            </p>
          </div>
          <button onClick={() => navigate('/public/info')}
            className="inline-flex items-center gap-2 h-10 px-5 rounded-xl border border-border text-sm font-medium text-foreground shrink-0 group hover:bg-muted transition-colors">
            Browse freely
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </section>

        {/* ── BOTTOM CTA ────────────────────────────────────────────────── */}
        <SectionRule />
        <section className="max-w-5xl mx-auto px-6 md:px-12 py-12 md:py-16 space-y-6
                             opacity-0 intersect:opacity-100 transition duration-700">
          <div className="space-y-3 max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-light tracking-tight leading-[1.15] text-balance">
              You deserve to feel safe online.{''}
              <span className="gradient-text font-medium">Let&apos;s start right now.</span>
            </h2>
            <p className="text-base text-muted-foreground text-pretty">
              It&apos;s not your fault. You&apos;re not alone.
              And there are tools — and people — ready to help.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 pt-1">
            <button onClick={() => scrollToAuth('create')}
              className="inline-flex items-center gap-2 h-12 px-8 rounded-xl font-semibold text-sm text-primary-foreground bg-primary hover:opacity-90 transition-opacity">
              Create your safe space
              <ArrowRight className="h-4 w-4" />
            </button>
            <button onClick={() => navigate('/public/info')}
              className="h-12 px-6 rounded-xl border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors">
              Explore for free first
            </button>
          </div>
          <p className="text-sm text-muted-foreground pt-2">
            Looking for younger users?{''}
            <button onClick={() => navigate('/kids')}
              className="underline underline-offset-4 hover:text-primary transition-colors">
              Visit kidsGuard (ages 8–12)
            </button>
          </p>
        </section>

      </main>

      {/* ── FOOTER ──────────────────────────────────────────────────────── */}
      <footer className="bg-background border-t border-border mt-auto">
        <div className="max-w-5xl mx-auto px-6 md:px-12 py-5
                         flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="h-5 w-5 rounded flex items-center justify-center shrink-0"
              style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
              <Shield className="h-3 w-3 text-white" strokeWidth={2.5} />
            </div>
            <span className="text-sm font-medium text-muted-foreground">girlGuard</span>
          </div>
          <p className="text-xs text-muted-foreground text-center text-pretty">
            Educational &amp; documentation tool only · Not legal or medical advice · Data stored locally on your device
          </p>
          <button onClick={() => navigate('/public/sources')}
            className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-4 transition-colors shrink-0">
            Sources &amp; References
          </button>
        </div>
      </footer>

    </div>
  );
}
