import { useState } from 'react';
import { RefreshCw, CheckCircle, XCircle } from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';

// ─── DATA ─────────────────────────────────────────────────────────────────────

const allFeelings = [
  { emoji: '😢', label: 'Sad',         color: K.blue,   tips: ['It\'s okay to cry — tears help you feel better', 'Talk to someone you trust about how you feel', 'Write or draw about what made you sad'] },
  { emoji: '😨', label: 'Scared',      color: K.pink,   tips: ['Tell a grown-up if something online scared you', 'Breathe slowly — in for 4 counts, out for 4', 'Remember: grown-ups are there to protect you'] },
  { emoji: '😤', label: 'Angry',       color: '#E67E22', tips: ['Walk away from the screen for 5 minutes', 'Squeeze a pillow or jump around to let it out', 'Write down why you\'re angry without sending it'] },
  { emoji: '😕', label: 'Confused',    color: K.teal,   tips: ['It\'s okay to not understand something', 'Ask a parent or teacher to explain', 'Don\'t click anything confusing — ask first!'] },
  { emoji: '😔', label: 'Left Out',    color: '#9B59B6', tips: ['Being left out is really hard — your feelings are valid', 'Do something you love to feel better', 'Talk to a friend or grown-up about it'] },
  { emoji: '😳', label: 'Embarrassed', color: K.yellow, tips: ['Everyone feels embarrassed sometimes — it passes', 'Avoid sharing things online when you feel flustered', 'Talk to someone you trust if you feel humiliated'] },
  { emoji: '😊', label: 'Happy',       color: K.green,  tips: ['Share your happiness with people you care about!', 'When you feel good, it\'s a great time to help others', 'Write down what made you happy in a journal'] },
  { emoji: '🤩', label: 'Excited',     color: K.teal,   tips: ['Channel your excitement into something creative!', 'Share good news with trusted friends and family', 'Take a moment to appreciate what made you excited'] },
];

const copingCards = [
  { feeling: '😢 Feeling sad?',      strategy: '5-Minute Kindness',   desc: 'Write one nice thing about yourself — and one nice thing about someone you care about.',      color: K.blue   },
  { feeling: '😨 Feeling scared?',   strategy: 'Box Breathing',        desc: 'Breathe IN for 4 counts → HOLD for 4 → OUT for 4 → HOLD for 4. Repeat 3 times.',             color: K.pink   },
  { feeling: '😤 Feeling angry?',    strategy: 'Move It Out',          desc: 'Shake your hands really fast, jump 10 times, or run in place for 30 seconds!',                color: '#E67E22' },
  { feeling: '😔 Feeling left out?', strategy: 'Reach Out',            desc: 'Text or call ONE person you trust. Even a simple "Hey, thinking of you!" can help a lot.',     color: '#9B59B6' },
  { feeling: '😕 Feeling confused?', strategy: 'Ask a Question',       desc: 'Write down exactly what confused you — then show it to a parent or teacher. No question is silly!', color: K.teal  },
  { feeling: '😳 Embarrassed?',      strategy: 'Self-Compassion Reset', desc: 'Say out loud: "Everyone makes mistakes. I am still worthy of kindness." Three times!',       color: K.yellow },
];

const checkInMoods = [
  { emoji: '😁', label: 'Amazing!',     color: K.green  },
  { emoji: '😊', label: 'Pretty good',  color: K.teal   },
  { emoji: '😐', label: 'Okay',         color: K.yellow },
  { emoji: '😔', label: 'Not great',    color: '#9B59B6' },
  { emoji: '😢', label: 'Really down',  color: K.blue   },
  { emoji: '😤', label: 'Frustrated',   color: '#E67E22' },
];

// ─── COMPONENT: Feelings Wheel ────────────────────────────────────────────────

function FeelingsWheel() {
  const [active, setActive] = useState<number | null>(null);

  return (
    <div className="p-5 space-y-4">
      <p className="text-sm font-bold text-center" style={{ color: K.muted }}>Tap a feeling to get tips on how to handle it:</p>
      <div className="grid grid-cols-4 gap-2">
        {allFeelings.map((f, i) => {
          const on = active === i;
          return (
            <button key={f.label} onClick={() => setActive(on ? null : i)}
              className="flex flex-col items-center gap-1 rounded-2xl py-3 border transition-all hover:scale-105"
              style={{ backgroundColor: on ? f.color + '18' : K.quizBtn, borderColor: on ? f.color : K.quizBtnBorder }}>
              <span className="text-3xl">{f.emoji}</span>
              <span className="text-xs font-black" style={{ color: on ? f.color : K.muted }}>{f.label}</span>
            </button>
          );
        })}
      </div>
      {active !== null && (
        <div className="rounded-2xl border p-4 space-y-3 transition-all"
          style={{ borderColor: allFeelings[active].color, backgroundColor: allFeelings[active].color + '15' }}>
          <p className="font-black text-base" style={{ color: K.text }}>
            {allFeelings[active].emoji} Feeling {allFeelings[active].label.toLowerCase()}? Here are some tips:
          </p>
          {allFeelings[active].tips.map((tip, i) => (
            <div key={i} className="flex items-start gap-2 text-sm font-semibold" style={{ color: K.text }}>
              <span className="shrink-0">✨</span>{tip}
            </div>
          ))}
        </div>
      )}
      {active === null && (
        <div className="text-center py-4 text-sm font-bold" style={{ color: K.muted }}>
          👆 Tap any feeling above to see tips!
        </div>
      )}
    </div>
  );
}

// ─── COMPONENT: Coping Toolkit ────────────────────────────────────────────────

function CopingToolkit() {
  const [flipped, setFlipped] = useState<Set<number>>(new Set());

  const toggle = (i: number) => setFlipped(s => { const n = new Set(s); n.has(i) ? n.delete(i) : n.add(i); return n; });

  return (
    <div className="p-5 space-y-4">
      <p className="text-sm font-bold text-center" style={{ color: K.muted }}>Tap a card to reveal your coping strategy! 💡</p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {copingCards.map((c, i) => {
          const isFlipped = flipped.has(i);
          return (
            <button key={i} onClick={() => toggle(i)}
              className="rounded-2xl border overflow-hidden transition-all hover:scale-[1.02] w-full text-left"
              style={{ borderColor: c.color }}>
              {!isFlipped ? (
                <div className="p-4 flex flex-col items-center gap-2 min-h-[100px] justify-center"
                  style={{ backgroundColor: c.color + '18' }}>
                  <p className="font-black text-sm text-center" style={{ color: K.text }}>{c.feeling}</p>
                  <span className="text-xs font-bold rounded-full px-3 py-1"
                    style={{ backgroundColor: c.color + '33', color: K.muted }}>Tap to see strategy 👆</span>
                </div>
              ) : (
                <div className="p-4 space-y-2 min-h-[100px]" style={{ backgroundColor: c.color + '22' }}>
                  <p className="font-black text-sm" style={{ color: K.text }}>💡 {c.strategy}</p>
                  <p className="text-xs font-semibold" style={{ color: K.muted }}>{c.desc}</p>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── COMPONENT: Mood Check-In ─────────────────────────────────────────────────

function MoodCheckIn() {
  const [mood, setMood] = useState<number | null>(null);
  const [note, setNote] = useState('');
  const [saved, setSaved] = useState(false);

  if (saved) {
    const m = checkInMoods[mood!];
    return (
      <div className="text-center space-y-4 p-6">
        <div className="text-6xl">{m.emoji}</div>
        <p className="text-xl font-black" style={{ color: K.text }}>Check-in saved! Feeling {m.label.toLowerCase()} today.</p>
        {note && <div className="rounded-2xl p-4 text-sm font-semibold text-left" style={{ backgroundColor: m.color + '22', color: K.text }}>
          Your note: "{note}"
        </div>}
        <p className="text-sm font-bold" style={{ color: K.muted }}>
          {mood! <= 2 ? 'Keep it up — you are doing great! 🌟' : mood! === 3 ? 'Hope your day gets better! You\'ve got this 💪' : 'Remember you are not alone — talk to someone you trust 💚'}
        </p>
        <button onClick={() => { setMood(null); setNote(''); setSaved(false); }}
          className="inline-flex items-center gap-2 px-5 py-2 rounded-2xl font-black text-white hover:scale-105 transition-all"
          style={{ backgroundColor: m.color }}>
          <RefreshCw className="h-4 w-4" /> Check In Again
        </button>
      </div>
    );
  }

  return (
    <div className="p-5 space-y-4">
      <p className="font-black text-base text-center" style={{ color: K.text }}>🌤 How are you feeling right now?</p>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {checkInMoods.map((m, i) => (
          <button key={m.label} onClick={() => setMood(i)}
            className="flex flex-col items-center gap-1 py-3 rounded-2xl border transition-all hover:scale-105"
            style={{ backgroundColor: mood === i ? m.color + '18' : K.quizBtn, borderColor: mood === i ? m.color : K.quizBtnBorder }}>
            <span className="text-3xl">{m.emoji}</span>
            <span className="text-xs font-black" style={{ color: mood === i ? m.color : K.muted }}>{m.label}</span>
          </button>
        ))}
      </div>
      {mood !== null && (
        <div className="space-y-3">
          <textarea
            placeholder="Want to add a note about your day? (optional)"
            value={note}
            onChange={e => setNote(e.target.value)}
            rows={3}
            className="w-full rounded-2xl border p-3 text-sm font-semibold outline-none resize-none"
            style={{ borderColor: checkInMoods[mood].color + '88', color: K.text }}
          />
          <button onClick={() => setSaved(true)}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: checkInMoods[mood].color }}>
            Save My Check-In ✅
          </button>
        </div>
      )}
    </div>
  );
}

// ─── COMPONENT: Calm-Down Breathing ──────────────────────────────────────────

function CalmDownKit() {
  const [phase, setPhase] = useState<'idle' | 'in' | 'hold1' | 'out' | 'hold2'>('idle');
  const [count, setCount] = useState(4);
  const [rounds, setRounds] = useState(0);

  const start = () => { setPhase('in'); setCount(4); };
  const stop  = () => { setPhase('idle'); setCount(4); setRounds(0); };

  const phaseConfig: Record<string, { label: string; color: string; emoji: string; next: typeof phase; dur: number }> = {
    in:    { label: 'Breathe IN',  color: K.teal,   emoji: '🫁', next: 'hold1', dur: 4 },
    hold1: { label: 'HOLD',        color: K.blue,   emoji: '⏸️',  next: 'out',   dur: 4 },
    out:   { label: 'Breathe OUT', color: K.green,  emoji: '💨',  next: 'hold2', dur: 4 },
    hold2: { label: 'HOLD',        color: K.yellow, emoji: '⏸️',  next: 'in',   dur: 4 },
  };

  const handleNext = () => {
    const cfg = phaseConfig[phase];
    if (!cfg) return;
    if (cfg.next === 'in') setRounds(r => r + 1);
    setPhase(cfg.next);
    setCount(4);
  };

  const currentCfg = phase !== 'idle' ? phaseConfig[phase] : null;

  return (
    <div className="p-5 space-y-5">
      <p className="text-sm font-bold text-center" style={{ color: K.muted }}>
        Box breathing helps when you feel overwhelmed. Follow each step for 4 counts.
      </p>

      {phase === 'idle' ? (
        <div className="text-center space-y-4">
          <div className="text-6xl">🫧</div>
          <p className="font-black text-base" style={{ color: K.text }}>Ready to calm down?</p>
          <button onClick={start}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl font-black text-white hover:scale-105 transition-all"
            style={{ backgroundColor: K.teal }}>
            Start Breathing 🌬️
          </button>
        </div>
      ) : (
        <div className="text-center space-y-4">
          <div className="text-6xl">{currentCfg!.emoji}</div>
          <div className="rounded-2xl p-5 border space-y-3"
            style={{ borderColor: currentCfg!.color, backgroundColor: currentCfg!.color + '22' }}>
            <p className="text-2xl font-black" style={{ color: K.text }}>{currentCfg!.label}</p>
            <p className="text-5xl font-black" style={{ color: currentCfg!.color }}>{count}</p>
            <div className="h-4 rounded-full overflow-hidden" style={{ backgroundColor: K.border }}>
              <div className="h-full rounded-full transition-all"
                style={{ width: `${(count / 4) * 100}%`, backgroundColor: currentCfg!.color }} />
            </div>
          </div>
          <p className="font-bold text-sm" style={{ color: K.muted }}>Rounds completed: {rounds} 🌟</p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => setCount(c => Math.max(1, c - 1))}
              className="px-5 py-2.5 rounded-2xl font-black text-white transition-all hover:scale-105"
              style={{ backgroundColor: currentCfg!.color }}>
              Tick ({count - 1})
            </button>
            <button onClick={handleNext}
              className="px-5 py-2.5 rounded-2xl font-black transition-all hover:scale-105"
              style={{ backgroundColor: K.quizBtn, color: K.text, border: `1px solid ${K.quizBtnBorder}` }}>
              Skip step →
            </button>
          </div>
          <button onClick={stop} className="text-xs font-bold underline" style={{ color: K.muted }}>Stop</button>
        </div>
      )}

      <div className="grid grid-cols-4 gap-2 text-center">
        {[
          { ph: 'Breathe In',  color: K.teal   },
          { ph: 'Hold',        color: K.blue   },
          { ph: 'Breathe Out', color: K.green  },
          { ph: 'Hold',        color: K.yellow },
        ].map((s, i) => (
          <div key={i} className="rounded-xl p-2 text-xs font-black"
            style={{ backgroundColor: s.color + '22', color: K.muted }}>
            {s.ph}<br />4 counts
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

type Tab = 'wheel' | 'coping' | 'checkin' | 'breathe';

const tabs: { id: Tab; emoji: string; label: string; color: string }[] = [
  { id: 'wheel',   emoji: '🎡', label: 'Feelings Wheel',   color: K.teal   },
  { id: 'coping',  emoji: '🧰', label: 'Coping Toolkit',   color: K.green  },
  { id: 'checkin', emoji: '🌤', label: 'Mood Check-In',    color: K.blue   },
  { id: 'breathe', emoji: '🌬️', label: 'Calm Down Kit',    color: K.pink   },
];

export default function KidsFeelingsPage() {
  const [activeTab, setActiveTab] = useState<Tab>('wheel');
  const activeTabDef = tabs.find(t => t.id === activeTab)!;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Hero */}
      <div className="text-center space-y-3">
        <div className="text-6xl kids-bounce inline-block">💚</div>
        <h1 className="text-3xl md:text-5xl font-black text-balance" style={{ color: K.text }}>
          Feelings &amp; Emotions
        </h1>
        <p className="text-base md:text-lg font-semibold text-pretty max-w-2xl mx-auto" style={{ color: K.muted }}>
          All feelings are okay — even the big, hard ones. Explore, learn, and find ways to feel better!
        </p>
        <div className="rounded-full px-5 py-2 inline-block font-black text-sm"
          style={{ backgroundColor: K.green + '14', color: K.green, border: `1px solid ${K.green}55` }}>
          Whatever you feel is okay. Your feelings are real and they matter! 💚
        </div>
      </div>

      {/* Quick tip strip */}
      <div className="rounded-2xl px-5 py-3 flex flex-wrap gap-x-4 gap-y-2 justify-center"
        style={{ backgroundColor: K.green + '0C', border: `1px solid ${K.green}44` }}>
        <span className="text-sm font-bold" style={{ color: K.text }}>⚡ Quick reminders:</span>
        {['Feelings are not facts', 'You are not alone', 'It\'s okay to cry', 'Asking for help is brave'].map(t => (
          <span key={t} className="text-sm font-semibold" style={{ color: K.green }}>· {t}</span>
        ))}
      </div>

      {/* Activity Hub */}
      <div className="space-y-4">
        <h2 className="text-2xl font-black text-center" style={{ color: K.text }}>🎮 Activity Hub</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="px-3 py-3 rounded-2xl font-black text-sm transition-all hover:scale-105 flex flex-col items-center gap-1"
              style={{ backgroundColor: activeTab === tab.id ? tab.color : tab.color + '22', color: activeTab === tab.id ? (tab.color === '#F5D74E' ? K.text : K.surface) : K.text, border: `1px solid ${tab.color}55` }}>
              <span className="text-xl">{tab.emoji}</span>
              <span className="text-xs text-center leading-tight">{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: K.surface, borderColor: K.border }}>
          <div className="px-5 py-3 font-black text-sm flex items-center gap-2"
            style={{ backgroundColor: activeTabDef.color + '1A', color: activeTabDef.color, borderBottom: `1px solid ${activeTabDef.color}33` }}>
            {activeTabDef.emoji} {activeTabDef.label}
          </div>
          {activeTab === 'wheel'   && <FeelingsWheel />}
          {activeTab === 'coping'  && <CopingToolkit />}
          {activeTab === 'checkin' && <MoodCheckIn />}
          {activeTab === 'breathe' && <CalmDownKit />}
        </div>
      </div>

      {/* Signs to seek help */}
      <div className="rounded-2xl border p-5 space-y-4" style={{ borderColor: K.pink + '44', backgroundColor: K.pink + '08' }}>
        <h2 className="text-xl font-black text-center" style={{ color: K.text }}>🚨 When to Tell a Grown-Up</h2>
        <div className="grid md:grid-cols-2 gap-2">
          {[
            '😢 You feel really sad for more than a few days',
            '😰 You feel scared to go online or to school',
            '😤 Angry feelings are hard to control',
            '😔 You feel alone even when people are around',
            '😞 Nothing seems to make you happy',
            '😟 You\'re worried about keeping yourself safe',
          ].map(s => (
            <div key={s} className="rounded-xl p-3 text-sm font-bold" style={{ backgroundColor: K.surface, color: K.text }}>{s}</div>
          ))}
        </div>
        <div className="text-center rounded-xl py-3 font-black" style={{ backgroundColor: K.pink + '14', color: K.text, border: `1px solid ${K.pink}33` }}>
          💪 Telling a grown-up is always the right choice!
        </div>
      </div>

      {/* Reassurance */}
      <div className="rounded-2xl border p-6 text-center space-y-3" style={{ backgroundColor: K.teal + '08', borderColor: K.teal + '44' }}>
        <p className="text-3xl">💙</p>
        <h2 className="text-xl font-black" style={{ color: K.text }}>You Are Not Alone</h2>
        <div className="grid grid-cols-2 gap-2 text-sm font-bold">
          {['🌟 Lots of kids feel this way', '🌟 Things can always get better', '🌟 You are important', '🌟 People care about you'].map(t => (
            <div key={t} className="rounded-xl p-2 border" style={{ backgroundColor: K.surface, color: K.text, borderColor: K.border }}>{t}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const _unusedImport = CheckCircle;
void _unusedImport;
const _unusedImport2 = XCircle;
void _unusedImport2;

