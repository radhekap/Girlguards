import { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';

// ─── DATA ─────────────────────────────────────────────────────────────────────

const whoHelpsScenarios = [
  {
    situation: 'Someone at school keeps sending you mean messages.',
    options: [
      { text: '👩‍🏫 Your teacher or school counselor', correct: true  },
      { text: '🤳 Post about it on social media', correct: false },
      { text: '👨‍👩‍👧 A parent or trusted guardian', correct: true  },
      { text: '😒 Keep it to yourself', correct: false },
    ],
    note: 'Both a teacher AND a parent are great choices — getting two adults involved is even better!',
  },
  {
    situation: 'A stranger online is asking for your phone number.',
    options: [
      { text: '📵 Block them immediately and tell a parent', correct: true  },
      { text: '💬 Give them a fake number to be safe', correct: false },
      { text: '🔒 Tell a trusted adult right away', correct: true  },
      { text: '🤷 Ignore it — it\'s probably fine', correct: false },
    ],
    note: 'Block AND tell a grown-up right away. Never give out personal info — even fake!',
  },
  {
    situation: 'You saw something online that really scared or upset you.',
    options: [
      { text: '🙈 Close it and never tell anyone', correct: false },
      { text: '🗣️ Tell a parent or trusted adult what you saw', correct: true  },
      { text: '📱 Show your friends online', correct: false },
      { text: '🏫 Talk to your school counselor', correct: true  },
    ],
    note: 'Always tell a trusted adult. You will NOT get in trouble — they want to help you.',
  },
];

const braveWordsStarters = [
  '"I need to show you something that happened online."',
  '"Something made me feel scared/upset and I need help."',
  '"Someone online is being mean to me."',
  '"I saw something I didn\'t understand and it bothered me."',
  '"Can you look at this message with me?"',
  '"I\'m not sure if this is okay — can you check?"',
];

const whatHappensNextCards = [
  { icon: '🗣️', title: 'They will listen', text: 'A trusted adult will take you seriously and listen to everything you say without judging you.' },
  { icon: '📸', title: 'They may ask for proof', text: 'Screenshots help! Show them the messages, posts, or anything that upset you.' },
  { icon: '🛡️', title: 'They will help keep you safe', text: 'They might block the person, change your settings, or contact the school or app together.' },
  { icon: '🏫', title: 'They might contact the school', text: 'If it involves a classmate, they may talk to teachers or counselors to sort it out.' },
  { icon: '💚', title: 'They will support you', text: 'They\'ll check in on how you\'re feeling and make sure you feel better.' },
  { icon: '🚫', title: 'You won\'t get in trouble', text: 'Telling a grown-up is ALWAYS the right thing to do. You will never be punished for asking for help!' },
];

// ─── COMPONENT: Who Can Help? Quiz ───────────────────────────────────────────

function WhoHelpsQuiz() {
  const [idx, setIdx] = useState(0);
  const [chosen, setChosen] = useState<Set<number>>(new Set());
  const [revealed, setRevealed] = useState(false);
  const [done, setDone] = useState(false);

  const s = whoHelpsScenarios[idx];
  const correctCount = s.options.filter((_, i) => chosen.has(i) && s.options[i].correct).length;

  const toggle = (i: number) => { if (revealed) return; setChosen(c => { const n = new Set(c); n.has(i) ? n.delete(i) : n.add(i); return n; }); };

  const check = () => setRevealed(true);
  const next  = () => {
    if (idx + 1 >= whoHelpsScenarios.length) { setDone(true); return; }
    setIdx(i => i + 1); setChosen(new Set()); setRevealed(false);
  };

  if (done) return (
    <div className="text-center space-y-4 p-6">
      <div className="text-5xl">🌟</div>
      <p className="text-xl font-black" style={{ color: K.text }}>You know who to turn to — great job!</p>
      <p className="font-bold text-sm" style={{ color: K.muted }}>Remember: when in doubt, always tell a grown-up!</p>
      <button onClick={() => { setIdx(0); setChosen(new Set()); setRevealed(false); setDone(false); }}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
        style={{ backgroundColor: K.yellow }}>
        <RefreshCw className="h-4 w-4" /> Play Again
      </button>
    </div>
  );

  return (
    <div className="p-5 space-y-4">
      <div className="text-xs font-bold" style={{ color: K.muted }}>Scenario {idx + 1}/{whoHelpsScenarios.length}</div>
      <div className="rounded-2xl p-4 border" style={{ borderColor: K.yellow + '88', backgroundColor: K.yellow + '18' }}>
        <p className="font-bold text-base" style={{ color: K.text }}>💭 {s.situation}</p>
        <p className="text-xs font-semibold mt-2" style={{ color: K.muted }}>Select ALL the right answers:</p>
      </div>
      <div className="space-y-2">
        {s.options.map((opt, i) => {
          const isChosen = chosen.has(i);
          const bg = !revealed ? (isChosen ? K.teal + '18' : K.quizBtn) : opt.correct ? K.green + '22' : isChosen ? K.pink + '22' : K.quizBtn;
          const border = !revealed ? (isChosen ? K.teal : K.quizBtnBorder) : opt.correct ? K.green : isChosen ? K.pink : K.quizBtnBorder;
          return (
            <button key={i} onClick={() => toggle(i)} disabled={revealed}
              className="w-full text-left p-3 rounded-2xl border font-bold text-sm transition-all hover:scale-[1.01]"
              style={{ backgroundColor: bg, borderColor: border, color: K.text }}>
              {revealed ? (opt.correct ? '✅ ' : isChosen ? '❌ ' : '  ') : (isChosen ? '☑️ ' : '☐ ')}
              {opt.text}
            </button>
          );
        })}
      </div>
      {!revealed ? (
        <button disabled={chosen.size === 0} onClick={check}
          className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all disabled:opacity-40"
          style={{ backgroundColor: K.teal, color: K.surface }}>
          {chosen.size === 0 ? 'Select answers above!' : 'Check My Answers! 🔍'}
        </button>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl p-4 text-sm font-semibold" style={{ backgroundColor: K.yellow + '22', color: K.text }}>
            💡 {s.note}
          </div>
          <button onClick={next}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.teal }}>
            {idx + 1 < whoHelpsScenarios.length ? 'Next Scenario →' : 'Finish! 🌟'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── COMPONENT: Brave Words Builder ──────────────────────────────────────────

function BraveWordsBuilder() {
  const [selected, setSelected] = useState<number | null>(null);
  const [extra, setExtra] = useState('');
  const [built, setBuilt] = useState(false);

  if (built) return (
    <div className="text-center space-y-4 p-6">
      <div className="text-5xl">🦁</div>
      <p className="text-xl font-black" style={{ color: K.text }}>Your brave words are ready!</p>
      <div className="rounded-2xl p-5 text-left border space-y-2" style={{ borderColor: K.green, backgroundColor: K.green + '15' }}>
        <p className="font-black text-base" style={{ color: K.text }}>You could say:</p>
        <p className="font-bold text-base italic" style={{ color: K.text }}>{braveWordsStarters[selected!]}</p>
        {extra && <p className="font-semibold text-sm" style={{ color: K.muted }}>"...{extra}"</p>}
      </div>
      <p className="text-sm font-bold" style={{ color: K.muted }}>Practice saying this out loud — you are so brave! 💚</p>
      <button onClick={() => { setSelected(null); setExtra(''); setBuilt(false); }}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-black text-white hover:scale-105 transition-all"
        style={{ backgroundColor: K.green }}>
        <RefreshCw className="h-4 w-4" /> Build Another
      </button>
    </div>
  );

  return (
    <div className="p-5 space-y-4">
      <p className="text-sm font-bold text-center" style={{ color: K.muted }}>
        Pick a starter phrase for talking to a grown-up:
      </p>
      <div className="space-y-2">
        {braveWordsStarters.map((phrase, i) => (
          <button key={i} onClick={() => setSelected(i)}
            className="w-full text-left p-3 rounded-2xl border font-bold text-sm transition-all hover:scale-[1.01]"
            style={{ backgroundColor: selected === i ? K.green + '18' : K.quizBtn, borderColor: selected === i ? K.green : K.quizBtnBorder, color: K.text }}>
            {selected === i ? '✅ ' : '  '}{phrase}
          </button>
        ))}
      </div>
      {selected !== null && (
        <div className="space-y-3">
          <textarea
            rows={2}
            placeholder="Add more if you want... (optional)"
            value={extra}
            onChange={e => setExtra(e.target.value)}
            className="w-full rounded-2xl border p-3 text-sm font-semibold outline-none resize-none"
            style={{ borderColor: K.green + '88', color: K.text }}
          />
          <button onClick={() => setBuilt(true)}
            className="w-full py-3 rounded-2xl font-black text-white hover:scale-[1.02] transition-all"
            style={{ backgroundColor: K.green }}>
            I am ready to say this! 🦁
          </button>
        </div>
      )}
    </div>
  );
}

// ─── COMPONENT: What Happens Next? ───────────────────────────────────────────

function WhatHappensNext() {
  const [revealed, setRevealed] = useState<Set<number>>(new Set());

  const toggle = (i: number) => setRevealed(r => { const n = new Set(r); n.has(i) ? n.delete(i) : n.add(i); return n; });

  return (
    <div className="p-5 space-y-4">
      <p className="text-sm font-bold text-center" style={{ color: K.muted }}>
        Tap each card to find out what happens when you tell a grown-up! 💡
      </p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {whatHappensNextCards.map((c, i) => {
          const isFlipped = revealed.has(i);
          return (
            <button key={i} onClick={() => toggle(i)}
              className="rounded-2xl border overflow-hidden text-left transition-all hover:scale-[1.02] w-full"
              style={{ borderColor: K.blue }}>
              {!isFlipped ? (
                <div className="p-4 flex flex-col items-center gap-2 min-h-[90px] justify-center"
                  style={{ backgroundColor: K.blue + '15' }}>
                  <span className="text-3xl">{c.icon}</span>
                  <span className="text-xs font-black text-center" style={{ color: K.muted }}>Tap to reveal! 👆</span>
                </div>
              ) : (
                <div className="p-4 space-y-1 min-h-[90px]" style={{ backgroundColor: K.blue + '22' }}>
                  <p className="font-black text-sm" style={{ color: K.text }}>{c.icon} {c.title}</p>
                  <p className="text-xs font-semibold" style={{ color: K.muted }}>{c.text}</p>
                </div>
              )}
            </button>
          );
        })}
      </div>
      {revealed.size === whatHappensNextCards.length && (
        <div className="text-center rounded-2xl py-3 font-black" style={{ backgroundColor: K.green + '22', color: K.text }}>
          🎉 You revealed all cards — now you know exactly what to expect!
        </div>
      )}
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

type Tab = 'whohelps' | 'bravewords' | 'whatnext';

const tabs: { id: Tab; emoji: string; label: string; color: string }[] = [
  { id: 'whohelps',  emoji: '🤔', label: 'Who Can Help?',       color: K.yellow },
  { id: 'bravewords',emoji: '🦁', label: 'Brave Words Builder', color: K.green  },
  { id: 'whatnext',  emoji: '🔮', label: 'What Happens Next?',  color: K.blue   },
];

export default function KidsHelpPage() {
  const [activeTab, setActiveTab] = useState<Tab>('whohelps');
  const activeTabDef = tabs.find(t => t.id === activeTab)!;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Hero */}
      <div className="text-center space-y-3">
        <div className="text-6xl kids-bounce inline-block">⭐</div>
        <h1 className="text-3xl md:text-5xl font-black text-balance" style={{ color: K.text }}>
          Ask for Help
        </h1>
        <p className="text-sm md:text-base font-semibold text-pretty max-w-2xl mx-auto" style={{ color: K.muted }}>
          Asking for help is one of the bravest things you can do — here you can practice exactly how!
        </p>
        <div className="rounded-full px-5 py-2 inline-block font-black text-sm"
          style={{ backgroundColor: K.yellow + '18', color: K.text, border: `1px solid ${K.yellow}66` }}>
          🦁 Asking for help is brave, not weak!
        </div>
      </div>

      {/* Quick tip strip */}
      <div className="rounded-2xl px-5 py-3 flex flex-wrap gap-x-4 gap-y-2 justify-center"
        style={{ backgroundColor: K.yellow + '0C', border: `1px solid ${K.yellow}44` }}>
        <span className="text-sm font-bold" style={{ color: K.text }}>⚡ Remember:</span>
        {["You won't get in trouble", 'Grown-ups want to help', 'Show them screenshots', 'You are NOT alone'].map(t => (
          <span key={t} className="text-sm font-semibold" style={{ color: K.muted }}>· {t}</span>
        ))}
      </div>

      {/* Activity Hub */}
      <div className="space-y-4">
        <h2 className="text-xl font-black text-center" style={{ color: K.text }}>🎮 Activity Hub</h2>
        <div className="grid grid-cols-3 gap-2">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="px-3 py-3 rounded-xl font-black text-sm transition-all hover:scale-105 flex flex-col items-center gap-1"
              style={{ backgroundColor: activeTab === tab.id ? tab.color : tab.color + '14', color: activeTab === tab.id ? (tab.id === 'whohelps' ? K.text : K.surface) : K.text, border: `1px solid ${tab.color}55` }}>
              <span className="text-xl">{tab.emoji}</span>
              <span className="text-xs text-center leading-tight">{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: K.surface, borderColor: K.border }}>
          <div className="px-5 py-3 font-black text-sm flex items-center gap-2"
            style={{ backgroundColor: activeTabDef.color + '1A', color: activeTabDef.color, borderBottom: `1px solid ${activeTabDef.color}33` }}>
            {activeTabDef.emoji} {activeTabDef.label}
          </div>
          {activeTab === 'whohelps'   && <WhoHelpsQuiz />}
          {activeTab === 'bravewords' && <BraveWordsBuilder />}
          {activeTab === 'whatnext'   && <WhatHappensNext />}
        </div>
      </div>

      {/* When to ask */}
      <div className="rounded-2xl border p-5 space-y-4" style={{ borderColor: K.yellow + '44', backgroundColor: K.yellow + '08' }}>
        <h2 className="text-xl font-black" style={{ color: K.text }}>⚡ When Should You Ask for Help?</h2>
        <div className="grid md:grid-cols-2 gap-2">
          {[
            { emoji: '😰', text: 'Someone online makes you feel uncomfortable or scared' },
            { emoji: '🤫', text: 'Someone asks you to keep secrets from grown-ups' },
            { emoji: '😢', text: 'Someone is being mean to you online' },
            { emoji: '😕', text: 'You see something confusing or upsetting' },
            { emoji: '🤔', text: "You're not sure if something is okay — even if you're not sure!" },
            { emoji: '📍', text: 'Someone is asking for your location or personal info' },
          ].map(({ emoji, text }) => (
            <div key={text} className="flex items-center gap-3 p-3 rounded-xl border" style={{ backgroundColor: K.surface, borderColor: K.border }}>
              <span className="text-xl shrink-0">{emoji}</span>
              <p className="text-sm font-bold" style={{ color: K.text }}>{text}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Final encouragement */}
      <div className="rounded-2xl border p-6 text-center space-y-3" style={{ backgroundColor: K.pink + '08', borderColor: K.pink + '44' }}>
        <p className="text-3xl">🦁</p>
        <h2 className="text-xl font-black" style={{ color: K.text }}>You Are SO Brave!</h2>
        <div className="grid grid-cols-2 gap-2 text-sm font-bold">
          {["🌟 Won't get in trouble", '🌟 Telling is always right', '🌟 Things get better', '🌟 You are stronger than you think 💪'].map(r => (
            <div key={r} className="rounded-xl p-2 border" style={{ backgroundColor: K.surface, color: K.text, borderColor: K.border }}>{r}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

