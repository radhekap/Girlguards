import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield, Frown, HeartHandshake, Star, BookOpen, Gamepad2,
  ChevronDown, ChevronUp, Phone, Trophy, Lock, CheckCircle2,
  Zap, Globe, Users, Heart,
} from 'lucide-react';
import { K } from '@/components/layouts/KidsLayout';

// ─── CONFETTI BURST ──────────────────────────────────────────────────────────

const CONFETTI_COLORS = [K.pink, K.teal, K.blue, K.green, K.yellow, '#A78BFA', '#F97316'];

function Confetti({ active }: { active: boolean }) {
  if (!active) return null;
  const pieces = Array.from({ length: 28 }, (_, i) => ({
    id: i,
    color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
    left: `${5 + (i * 3.3) % 90}%`,
    delay: `${(i * 0.045).toFixed(2)}s`,
    size: i % 3 === 0 ? 12 : 8,
    borderRadius: i % 2 === 0 ? '50%' : '2px',
  }));
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden z-20">
      {pieces.map(p => (
        <div key={p.id} className="kids-confetti-piece"
          style={{
            left: p.left, top: '-16px', width: p.size, height: p.size,
            backgroundColor: p.color, borderRadius: p.borderRadius,
            animationDelay: p.delay,
          }} />
      ))}
    </div>
  );
}

// ─── DAILY MISSIONS (one per weekday, cycling) ───────────────────────────────

const MISSIONS = [
  { emoji: '🔐', title: 'Password Check', mission: "Check one of your passwords today — is it at least 8 characters long and different from your other passwords?", xp: 20 },
  { emoji: '🛡️', title: 'Privacy Review', mission: "Look at one app's privacy settings on your device with a grown-up. Make sure only the right people can see your stuff!", xp: 25 },
  { emoji: '🧠', title: 'Fact Check', mission: "Find one thing online today and check if it's true on a second website before believing it.", xp: 20 },
  { emoji: '💬', title: 'Kindness Mission', mission: 'Send one kind message to a friend or family member online today. Spread some good vibes!', xp: 15 },
  { emoji: '🕵️', title: 'Phishing Spotter', mission: "Can you spot a phishing sign? Look at an email today and check: is the sender address weird? Are there spelling mistakes?", xp: 25 },
  { emoji: '👁️', title: 'Screen Time Check', mission: "Keep track of how many minutes you spend on screens today. Try to take a 10-minute screen-free break!", xp: 20 },
  { emoji: '🌟', title: 'Teach a Friend', mission: "Teach one online safety tip to a friend, sibling, or grown-up today. Teaching is the best way to learn!", xp: 30 },
];

function DailyMissionCard({ onComplete }: { onComplete: () => void }) {
  const [done, setDone] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const day = new Date().getDay(); // 0=Sun
  const mission = MISSIONS[day];

  const complete = () => {
    setDone(true);
    setShowConfetti(true);
    onComplete();
    setTimeout(() => setShowConfetti(false), 1600);
  };

  return (
    <div className="relative rounded-2xl border overflow-hidden"
      style={{ borderColor: K.yellow, backgroundColor: done ? K.green + '14' : K.yellow + '14' }}>
      <Confetti active={showConfetti} />
      <div className="p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl">{mission.emoji}</span>
            <div>
              <p className="font-black text-xs uppercase tracking-wider" style={{ color: K.yellow }}>⚡ Daily Mission</p>
              <p className="font-black text-lg leading-tight" style={{ color: K.text }}>{mission.title}</p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-black border"
            style={{ borderColor: K.yellow, color: K.text, backgroundColor: K.yellow + '28' }}>
            +{mission.xp} XP
          </span>
        </div>

        <p className="font-semibold text-sm leading-relaxed" style={{ color: K.muted }}>{mission.mission}</p>

        {done ? (
          <div className="kids-mission-complete flex items-center gap-3 rounded-xl p-3"
            style={{ backgroundColor: K.green + '18', border: `1px solid ${K.green}` }}>
            <span className="text-2xl">🌟</span>
            <p className="font-black text-sm" style={{ color: K.text }}>Mission complete! You&apos;re a Safety Superstar! 🎉</p>
          </div>
        ) : (
          <button onClick={complete}
            className="w-full py-3 rounded-xl font-black text-base text-white transition-all hover:scale-[1.02] active:scale-[0.98]"
            style={{ backgroundColor: K.yellow, color: K.text }}>
            ✅ Mark Mission Complete!
          </button>
        )}
      </div>
    </div>
  );
}

// ─── DAILY TIPS ───────────────────────────────────────────────────────────────

const TIPS = [
  { emoji: '🔐', tip: 'Never share your password with ANYONE — not even your best friend!' },
  { emoji: '🛑', tip: 'If something online feels wrong, stop and tell a grown-up right away.' },
  { emoji: '📸', tip: "Always ask before you share someone else's photo." },
  { emoji: '🤫', tip: "Safe adults NEVER ask kids to keep secrets from their parents." },
  { emoji: '💪', tip: 'It is always okay to ask for help — asking is brave, not weak!' },
  { emoji: '🕵️', tip: 'Check before you believe — not everything you read online is true.' },
  { emoji: '💬', tip: 'Online bullying is never okay. Block, report, and tell a grown-up.' },
  { emoji: '🌟', tip: "You are in charge of your own online safety. You've got this!" },
  { emoji: '🧩', tip: "Games are fun, but strangers in games are still strangers in real life." },
  { emoji: '📍', tip: "Never share your home address, school name, or location online." },
];

function TipCarousel() {
  const [idx, setIdx] = useState(0);
  const [animKey, setAnimKey] = useState(0);
  const next = () => { setIdx(i => (i + 1) % TIPS.length); setAnimKey(k => k + 1); };
  const prev = () => { setIdx(i => (i - 1 + TIPS.length) % TIPS.length); setAnimKey(k => k + 1); };
  const tip = TIPS[idx];
  return (
    <div className="rounded-2xl border p-5 space-y-4" style={{ borderColor: K.teal, backgroundColor: K.teal + '0C' }}>
      <div className="flex items-center justify-between">
        <p className="font-black text-sm uppercase tracking-wider" style={{ color: K.teal }}>⚡ Safety Tips</p>
        <p className="text-xs font-bold" style={{ color: K.muted }}>{idx + 1} / {TIPS.length}</p>
      </div>
      <div key={animKey} className="kids-slide-up flex items-start gap-4 min-h-[56px]">
        <span className="text-4xl shrink-0 kids-float">{tip.emoji}</span>
        <p className="font-bold text-base leading-snug" style={{ color: K.text }}>{tip.tip}</p>
      </div>
      <div className="flex gap-2 items-center">
        <button onClick={prev} className="h-9 w-9 rounded-xl font-black border flex items-center justify-center hover:scale-110 transition-all"
          style={{ borderColor: K.teal, color: K.teal, backgroundColor: K.surface }}>‹</button>
        <div className="flex-1 flex gap-1 justify-center">
          {TIPS.map((_, i) => (
            <button key={i} onClick={() => { setIdx(i); setAnimKey(k => k + 1); }}
              className="rounded-full transition-all"
              style={{ width: i === idx ? 20 : 8, height: 8, backgroundColor: i === idx ? K.teal : K.teal + '44' }} />
          ))}
        </div>
        <button onClick={next} className="h-9 w-9 rounded-xl font-black border flex items-center justify-center hover:scale-110 transition-all"
          style={{ borderColor: K.teal, color: K.teal, backgroundColor: K.surface }}>›</button>
      </div>
    </div>
  );
}

// ─── EXPLORE SECTIONS GRID ────────────────────────────────────────────────────

const SECTIONS = [
  { icon: Shield,         label: 'Stay Safe Online',    path: '/kids/safe-online', color: K.teal,   emoji: '🛡️', blurb: 'Quizzes, scam detector, fake news games, avatar builder & badges!',   tag: '8 activities' },
  { icon: Frown,          label: 'Online Bullying',     path: '/kids/bullying',    color: K.pink,   emoji: '💬', blurb: 'Is it bullying? What would you do? Fun quiz + response builder!',     tag: '4 activities' },
  { icon: HeartHandshake, label: 'Feelings & Emotions', path: '/kids/feelings',    color: K.green,  emoji: '💚', blurb: 'Feelings wheel, coping toolkit, mood check-in & breathing exercise!', tag: '4 activities' },
  { icon: Star,           label: 'Ask for Help',        path: '/kids/help',        color: K.yellow, emoji: '⭐', blurb: "Who helps you? Brave words builder + what happens next explorer!",    tag: '3 activities' },
  { icon: BookOpen,       label: 'Resources',           path: '/kids/resources',   color: K.blue,   emoji: '📚', blurb: 'Hotlines, safe websites & a quiz to find the right help fast!',      tag: '3 activities' },
  { icon: Gamepad2,       label: 'Games Hub',           path: '/kids/games',       color: K.pink,   emoji: '🎮', blurb: '28 interactive cybersecurity, safety & digital literacy games!',     tag: '28 games 🏆' },
];

// ─── ACHIEVEMENT BADGES ───────────────────────────────────────────────────────

const ALL_BADGES = [
  { id: 'pledge',    emoji: '🤝', label: 'Safety Pledger',   desc: 'Complete the safety pledge',            color: K.yellow },
  { id: 'mission',   emoji: '⚡', label: 'Mission Star',     desc: 'Complete today\'s daily mission',       color: K.green  },
  { id: 'tip',       emoji: '💡', label: 'Tip Explorer',     desc: 'Read all 10 safety tips',               color: K.teal   },
  { id: 'games',     emoji: '🏆', label: 'Game Champion',    desc: 'Visit the Games Hub',                   color: K.blue   },
  { id: 'feelings',  emoji: '💚', label: 'Feeling Brave',    desc: 'Visit Feelings & Emotions',             color: K.green  },
  { id: 'help',      emoji: '🌟', label: 'Help Seeker',      desc: 'Visit Ask for Help',                    color: K.yellow },
  { id: 'allsec',    emoji: '🔒', label: 'Safety Explorer',  desc: 'Visit all 6 sections',                  color: K.pink   },
  { id: 'superstar', emoji: '🦸', label: 'Safety Superstar', desc: 'Earn all 7 other badges',               color: K.blue   },
];

function BadgesSection({ earned }: { earned: Set<string> }) {
  return (
    <div className="rounded-2xl border p-5 space-y-4" style={{ borderColor: K.blue, backgroundColor: K.blue + '08' }}>
      <div className="flex items-center gap-3">
        <Trophy style={{ width: 20, height: 20, color: K.blue }} />
        <div>
          <h2 className="font-black text-lg" style={{ color: K.text }}>Your Badges 🏅</h2>
          <p className="text-xs font-semibold" style={{ color: K.muted }}>{earned.size} / {ALL_BADGES.length} earned this session</p>
        </div>
      </div>
      <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
        {ALL_BADGES.map(b => {
          const isEarned = earned.has(b.id);
          return (
            <div key={b.id} title={isEarned ? b.desc : `🔒 ${b.desc}`}
              className="flex flex-col items-center gap-1 p-2 rounded-xl border text-center transition-all"
              style={{
                borderColor: isEarned ? b.color : K.border,
                backgroundColor: isEarned ? b.color + '14' : K.surface,
              }}>
              <span className={`text-2xl ${isEarned ? 'kids-badge-unlock' : 'grayscale opacity-40'}`}>{b.emoji}</span>
              <p className="text-[9px] font-black leading-tight" style={{ color: isEarned ? K.text : K.muted }}>{b.label}</p>
            </div>
          );
        })}
      </div>
      {earned.size === ALL_BADGES.length && (
        <div className="kids-star-pop rounded-xl p-4 text-center"
          style={{ backgroundColor: K.yellow + '28', border: `1px solid ${K.yellow}` }}>
          <p className="text-2xl">🦸✨🦸</p>
          <p className="font-black text-base mt-1" style={{ color: K.text }}>You earned ALL badges! You&apos;re a true Safety Superstar!</p>
        </div>
      )}
    </div>
  );
}

// ─── SAFETY PLEDGE ────────────────────────────────────────────────────────────

const PLEDGE_ITEMS = [
  { id: 'a', text: 'I will NEVER share my password with anyone online' },
  { id: 'b', text: 'I will tell a trusted adult if something feels wrong' },
  { id: 'c', text: 'I will be kind to others online' },
  { id: 'd', text: 'I will think before I post or share anything' },
  { id: 'e', text: 'I will ask for help whenever I need it' },
];

function SafetyPledge({ onPledge }: { onPledge: () => void }) {
  const [ticked, setTicked] = useState<Set<string>>(new Set());
  const [pledged, setPledged] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const toggle = (id: string) => setTicked(t => {
    const n = new Set(t); n.has(id) ? n.delete(id) : n.add(id); return n;
  });

  const doPlege = () => {
    setPledged(true);
    setShowConfetti(true);
    onPledge();
    setTimeout(() => setShowConfetti(false), 1600);
  };

  return (
    <div className="relative rounded-2xl border p-5 space-y-4 overflow-hidden"
      style={{ borderColor: K.yellow, backgroundColor: K.yellow + '12' }}>
      <Confetti active={showConfetti} />
      <div className="text-center">
        <p className="text-xl font-black" style={{ color: K.text }}>🤝 Take the Safety Pledge!</p>
        <p className="text-sm font-semibold mt-1" style={{ color: K.muted }}>Tick all five to become a kidsGuard Safety Star</p>
      </div>
      {pledged ? (
        <div className="kids-star-pop text-center space-y-2 py-4">
          <p className="text-5xl">🌟</p>
          <p className="text-xl font-black" style={{ color: K.text }}>You&apos;re a kidsGuard Safety Star!</p>
          <button onClick={() => { setTicked(new Set()); setPledged(false); }}
            className="text-sm font-bold underline" style={{ color: K.blue }}>Take it again</button>
        </div>
      ) : (
        <>
          <div className="space-y-2">
            {PLEDGE_ITEMS.map(({ id, text }) => {
              const on = ticked.has(id);
              return (
                <button key={id} onClick={() => toggle(id)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all hover:scale-[1.01]"
                  style={{ backgroundColor: on ? K.green + '18' : K.surface, borderColor: on ? K.green : K.border }}>
                  <span className="shrink-0 w-6 h-6 rounded-lg border flex items-center justify-center text-sm font-black"
                    style={{ borderColor: on ? K.green : K.quizBtnBorder, backgroundColor: on ? K.green : 'transparent', color: K.surface }}>
                    {on ? '✓' : ''}
                  </span>
                  <span className="font-bold text-sm" style={{ color: K.text }}>{text}</span>
                </button>
              );
            })}
          </div>
          <button disabled={ticked.size < PLEDGE_ITEMS.length} onClick={doPlege}
            className="w-full py-3 rounded-xl font-black text-base transition-all hover:scale-[1.02] disabled:opacity-40"
            style={{ backgroundColor: K.yellow, color: K.text }}>
            {ticked.size < PLEDGE_ITEMS.length ? `${PLEDGE_ITEMS.length - ticked.size} more to tick!` : '🌟 I Take the Pledge!'}
          </button>
        </>
      )}
    </div>
  );
}

// ─── PARENT CORNER ────────────────────────────────────────────────────────────

function ParentCorner() {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl border overflow-hidden" style={{ borderColor: K.border }}>
      <button onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-4 py-3.5 transition-colors"
        style={{ backgroundColor: open ? K.teal + '08' : K.surface }}>
        <div className="flex items-center gap-3">
          <span className="text-xl">👨‍👩‍👧</span>
          <div className="text-left">
            <p className="font-black text-sm" style={{ color: K.text }}>Parent & Guardian Corner</p>
            <p className="text-xs font-semibold" style={{ color: K.muted }}>Information for adults</p>
          </div>
        </div>
        {open ? <ChevronUp style={{ width: 16, height: 16, flexShrink: 0, color: K.muted }} />
               : <ChevronDown style={{ width: 16, height: 16, flexShrink: 0, color: K.muted }} />}
      </button>
      {open && (
        <div className="px-4 pb-4 pt-3 space-y-3" style={{ borderTop: `1px solid ${K.border}`, backgroundColor: K.teal + '06' }}>
          <p className="font-semibold text-sm leading-relaxed" style={{ color: K.text }}>
            <strong>kidsGuard</strong> is a free, private, no-login educational platform designed
            to help children aged 8–12 learn about online safety through interactive games and activities.
          </p>
          <div className="grid md:grid-cols-2 gap-2">
            {[
              { icon: Lock,   text: 'No login or account required', color: K.teal   },
              { icon: Globe,  text: 'No data collected or stored',  color: K.blue   },
              { icon: Users,  text: 'All content is age-appropriate',color: K.green  },
              { icon: Heart,  text: 'Trauma-informed, never scary', color: K.pink   },
            ].map(({ icon: Icon, text, color }) => (
              <div key={text} className="flex items-center gap-2 p-3 rounded-xl border"
                style={{ backgroundColor: K.surface, borderColor: K.border }}>
                <Icon style={{ width: 14, height: 14, flexShrink: 0, color }} strokeWidth={2} />
                <span className="text-xs font-bold" style={{ color: K.text }}>{text}</span>
              </div>
            ))}
          </div>
          <p className="text-xs font-semibold" style={{ color: K.muted }}>
            We encourage parents and carers to complete activities alongside their children.
            Conversation and co-learning are the most effective tools for digital safety education.
          </p>
        </div>
      )}
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

export default function KidsHomePage() {
  const navigate = useNavigate();
  const [earnedBadges, setEarnedBadges] = useState<Set<string>>(new Set());
  const [visitedSections, setVisitedSections] = useState<Set<string>>(new Set(['/kids']));
  const [tipsRead, setTipsRead] = useState(0);

  const earn = (id: string) => setEarnedBadges(prev => {
    const n = new Set(prev);
    n.add(id);
    if (n.size >= ALL_BADGES.length - 1) n.add('superstar');
    return n;
  });

  const handleMissionComplete = () => earn('mission');
  const handlePledge = () => earn('pledge');

  const goSection = (path: string) => {
    const next = new Set(visitedSections);
    next.add(path);
    setVisitedSections(next);
    if (next.size >= 6) earn('allsec');
    if (path === '/kids/games') earn('games');
    if (path === '/kids/feelings') earn('feelings');
    if (path === '/kids/help') earn('help');
    navigate(path);
  };

  // Award tip badge after reading all tips
  useEffect(() => {
    if (tipsRead >= TIPS.length) earn('tip');
  }, [tipsRead]);

  return (
    <div className="space-y-8 pb-8 max-w-3xl mx-auto">

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <div
        className="relative text-center space-y-5 py-10 md:py-14 overflow-hidden rounded-2xl"
        style={{
          background: `linear-gradient(135deg, ${K.teal}14 0%, ${K.blue}10 55%, ${K.green}0C 100%)`,
          border: `1px solid ${K.teal}55`,
        }}>
        {/* Floating background stars */}
        {(['★', '✦', '★', '✦', '●'] as const).map((s, i) => (
          <span
            key={i}
            aria-hidden="true"
            className="absolute kids-float pointer-events-none select-none font-black opacity-[0.10]"
            style={{
              top: `${10 + (i * 17) % 70}%`, left: `${5 + (i * 19) % 85}%`,
              fontSize: `${14 + (i % 3) * 8}px`,
              color: [K.teal, K.pink, K.blue, K.yellow, K.green][i],
              animationDelay: `${i * 0.6}s`,
            }}>{s}</span>
        ))}

        <div className="relative z-10 space-y-5 px-6 py-2">
          {/* Animated shield */}
          <div
            className="kids-bounce inline-flex items-center justify-center h-18 w-18 rounded-2xl mx-auto"
            style={{
              width: 72, height: 72,
              background: `linear-gradient(135deg, ${K.blue} 0%, ${K.teal} 100%)`,
            }}>
            <Shield style={{ width: 36, height: 36, color: K.surface }} strokeWidth={2.5} />
          </div>

          {/* Badge */}
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border font-black text-xs"
            style={{ borderColor: K.teal, color: K.teal, backgroundColor: K.surface }}>
            🛡️ For ages 8–12 · Free · No login
          </div>

          <h1
            className="text-3xl md:text-4xl font-black text-balance leading-tight"
            style={{ color: K.text }}>
            Welcome to{' '}
            <span style={{ color: K.teal }}>kidsGuard!</span>
          </h1>
          <p
            className="text-sm md:text-base font-semibold max-w-lg mx-auto text-pretty leading-relaxed"
            style={{ color: K.muted }}>
            Your safe, fun place to learn how to stay safe online —
            packed with games, quizzes, missions and activities.
          </p>

          {/* Feature pills */}
          <div className="flex flex-wrap justify-center gap-2">
            {[
              ['🎮', '28 games',       K.teal  ],
              ['🏅', 'Earn badges',    K.pink  ],
              ['⚡', 'Daily missions', K.yellow],
              ['🧠', 'Learn & play',   K.blue  ],
            ].map(([emoji, label, color]) => (
              <span
                key={label as string}
                className="px-3 py-1.5 rounded-full font-bold text-xs"
                style={{ backgroundColor: (color as string) + '14', color: K.text, border: `1px solid ${color}44` }}>
                {emoji} {label}
              </span>
            ))}
          </div>

          {/* CTA buttons */}
          <div className="flex flex-wrap justify-center gap-3 pt-1">
            <button
              onClick={() => goSection('/kids/games')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-black text-sm text-white transition-all hover:scale-[1.04] active:scale-[0.97]"
              style={{ backgroundColor: K.pink }}>
              <Gamepad2 style={{ width: 18, height: 18 }} /> Play Games!
            </button>
            <button
              onClick={() => document.getElementById('sections-grid')?.scrollIntoView({ behavior: 'smooth' })}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-black text-sm transition-all hover:scale-[1.04] active:scale-[0.97] border"
              style={{ borderColor: K.teal, color: K.teal, backgroundColor: K.surface }}>
              Explore Topics 🗺️
            </button>
          </div>
        </div>
      </div>

      {/* ── QUICK STATS ──────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { emoji: '🎮', value: '28',   label: 'Games & activities', color: K.teal   },
          { emoji: '🏅', value: '8',    label: 'Badges to earn',     color: K.pink   },
          { emoji: '⚡', value: '7',    label: 'Daily missions',     color: K.yellow },
          { emoji: '💯', value: 'Free', label: 'Always free',        color: K.green  },
        ].map(({ emoji, value, label, color }) => (
          <div
            key={label}
            className="rounded-xl p-4 text-center border"
            style={{
              backgroundColor: color + '0C',
              borderColor: color + '28',
            }}>
            <p className="text-2xl">{emoji}</p>
            <p className="font-black text-xl mt-1" style={{ color }}>{value}</p>
            <p className="text-xs font-semibold mt-0.5" style={{ color: K.muted }}>{label}</p>
          </div>
        ))}
      </div>

      {/* ── DAILY MISSION ────────────────────────────────────────────────── */}
      <DailyMissionCard onComplete={handleMissionComplete} />

      {/* ── SAFETY TIPS CAROUSEL ─────────────────────────────────────────── */}
      <div onClick={() => setTipsRead(t => Math.min(t + 1, TIPS.length))}>
        <TipCarousel />
      </div>

      {/* ── EXPLORE SECTIONS ─────────────────────────────────────────────── */}
      <div id="sections-grid" className="space-y-4">
        <div className="text-center space-y-1">
          <h2 className="text-xl md:text-2xl font-black text-balance" style={{ color: K.text }}>
            🗺️ What do you want to explore?
          </h2>
          <p className="text-sm font-semibold" style={{ color: K.muted }}>
            Choose a topic — each one is packed with games, quizzes and activities!
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {SECTIONS.map(({ icon: Icon, label, path, color, emoji, blurb, tag }) => (
            <button
              key={path}
              onClick={() => goSection(path)}
              className="group text-left w-full h-full rounded-xl border kids-card-hover"
              style={{
                background: K.surface,
                borderColor: K.border,
                borderLeft: `4px solid ${color}`,
                padding: 16,
                transition: 'box-shadow 0.18s, transform 0.18s',
              }}>
              {/* Top row */}
              <div className="flex items-center gap-3 mb-2.5">
                <div
                  className="h-9 w-9 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: color + '18' }}>
                  <Icon
                    style={{ width: 18, height: 18, color }}
                    strokeWidth={2.5}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-lg">{emoji}</span>
                    <span className="font-black text-sm truncate" style={{ color: K.text }}>{label}</span>
                  </div>
                  <span
                    className="inline-flex items-center text-xs font-bold px-2 py-0.5 rounded-full mt-0.5"
                    style={{ backgroundColor: color + '14', color }}>
                    {tag}
                  </span>
                </div>
                <Zap style={{ width: 14, height: 14, flexShrink: 0, color, opacity: 0 }} className="group-hover:opacity-100 transition-opacity" />
              </div>
              {/* Blurb */}
              <p className="text-xs font-semibold leading-relaxed" style={{ color: K.muted }}>{blurb}</p>
            </button>
          ))}
        </div>
      </div>

      {/* ── SAFETY PLEDGE ────────────────────────────────────────────────── */}
      <SafetyPledge onPledge={handlePledge} />

      {/* ── ACHIEVEMENT BADGES ───────────────────────────────────────────── */}
      <BadgesSection earned={earnedBadges} />

      {/* ── REASSURANCE ──────────────────────────────────────────────────── */}
      <div
        className="rounded-2xl p-6 text-center space-y-4 border"
        style={{
          background: `linear-gradient(135deg, ${K.green}10 0%, ${K.teal}08 100%)`,
          borderColor: K.green + '44',
        }}>
        <p className="text-4xl kids-bounce inline-block">💚</p>
        <div>
          <h2 className="text-xl font-black" style={{ color: K.text }}>You Are Never Alone</h2>
          <p className="text-sm font-semibold mt-1" style={{ color: K.muted }}>There are people who care and want to help.</p>
        </div>
        <div className="grid grid-cols-2 gap-2 text-sm font-bold max-w-lg mx-auto" style={{ color: K.text }}>
          {[
            '✅ Always okay to ask for help',
            '✅ Your feelings are real',
            '✅ Grown-ups are here for you',
            '✅ Things can always get better',
          ].map(t => (
            <div
              key={t}
              className="rounded-xl p-3 text-left border"
              style={{ backgroundColor: K.surface, borderColor: K.border }}>
              {t}
            </div>
          ))}
        </div>
        <div className="flex flex-wrap justify-center gap-3 pt-2">
          <button
            onClick={() => goSection('/kids/help')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-black text-xs text-white transition-all hover:scale-[1.03]"
            style={{ backgroundColor: K.green }}>
            <Star style={{ width: 14, height: 14 }} /> Ask for Help
          </button>
          <button
            onClick={() => navigate('/public/action')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-black text-xs text-white transition-all hover:scale-[1.03]"
            style={{ backgroundColor: K.pink }}>
            <Phone style={{ width: 14, height: 14 }} /> I Need Help Now
          </button>
        </div>
      </div>

      {/* ── PARENT CORNER ────────────────────────────────────────────────── */}
      <ParentCorner />

      {/* ── EMERGENCY HELP BUTTON ────────────────────────────────────────── */}
      <div
        className="rounded-xl p-5 flex flex-col md:flex-row items-center justify-between gap-4 border"
        style={{
          backgroundColor: K.pink + '0C',
          borderColor: K.pink + '33',
        }}>
        <div className="flex items-center gap-3">
          <div
            className="h-11 w-11 rounded-xl flex items-center justify-center shrink-0 text-xl"
            style={{ backgroundColor: K.pink + '18' }}>
            🆘
          </div>
          <div className="text-center md:text-left">
            <p className="font-black text-sm" style={{ color: K.text }}>Need help right now?</p>
            <p className="text-xs font-semibold" style={{ color: K.muted }}>
              If something is wrong online or you feel unsafe, there is always someone who can help.
            </p>
          </div>
        </div>
        <button
          onClick={() => navigate('/public/action')}
          className="shrink-0 inline-flex items-center gap-2 px-6 py-3 rounded-xl font-black text-sm text-white transition-all hover:scale-[1.04] active:scale-[0.97]"
          style={{ backgroundColor: K.pink }}>
          <CheckCircle2 style={{ width: 16, height: 16 }} /> Get Help Now →
        </button>
      </div>

    </div>
  );
}





