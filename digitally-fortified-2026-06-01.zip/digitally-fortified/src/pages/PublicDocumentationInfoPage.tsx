import PublicLayout from'@/components/layouts/PublicLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from'@/components/ui/card';
import { FileText, Lock, Camera, Clock, Heart, FileCheck, Check, Shield, Users } from'lucide-react';
import { useNavigate } from'react-router-dom';
import { Button } from'@/components/ui/button';

export default function PublicDocumentationInfoPage() {
  const navigate = useNavigate();

  const features = [
    {
      icon: Camera,
      title:'Evidence Collection',
      description:'Upload and store screenshots, messages, photos, and other evidence with cryptographic verification to prove authenticity',
    },
    {
      icon: Clock,
      title:'Timeline Builder',
      description:'Create a detailed chronological timeline of incidents to show patterns and escalation over time',
    },
    {
      icon: Heart,
      title:'Impact Documentation',
      description:'Record the emotional, social, and psychological effects to demonstrate the full scope of harm',
    },
    {
      icon: FileCheck,
      title:'Professional Reports',
      description:'Generate comprehensive, formatted reports suitable for law enforcement, schools, or legal proceedings',
    },
  ];

  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto space-y-12 animate-fade-in">
        <div className="space-y-4 text-center">
          <div className="flex justify-center mb-6">
            <div className="h-20 w-20 rounded-2xl flex items-center justify-center shadow-xl" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
              <FileText className="h-10 w-10 text-white" strokeWidth={2.5} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-light tracking-tight gradient-text">Documentation Tools</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            If you've experienced grooming, harassment, or other cybercrimes, here's what you might need to document
          </p>
        </div>

        <Card className="border-2 border-primary/30 shadow-xl bg-gradient-to-br from-card to-secondary/10">
          <CardContent className="p-8 space-y-6">
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 rounded-xl flex items-center justify-center shrink-0 shadow-md" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                <Lock className="h-6 w-6 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <h3 className="text-xl font-medium mb-2">Account Required for Full Features</h3>
                <p className="text-muted-foreground">
                  To use the complete documentation system with timeline, evidence storage, impact tracking, and report generation, 
                  you'll need to create a free account. All your data is stored securely and privately on your device.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <h2 className="text-3xl font-light text-center gradient-text">What You Can Document</h2>
          <div className="grid gap-6 md:grid-cols-2">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="border-2 hover:border-primary/50 transition-colors shadow-lg">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className="h-14 w-14 rounded-xl flex items-center justify-center shrink-0 shadow-lg" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                        <Icon className="h-7 w-7 text-white" strokeWidth={2.5} />
                      </div>
                      <CardTitle className="text-xl font-light">{feature.title}</CardTitle>
                    </div>
                    <CardDescription className="mt-3 leading-relaxed">
                      {feature.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </div>
        </div>

        <Card className="border-2 border-primary/20 shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-light gradient-text">Why Documentation Matters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              If you've experienced online grooming, harassment, sextortion, or other cybercrimes, having organized documentation can be crucial for:
            </p>
            <div className="grid gap-3">
              {[
'Reporting to law enforcement with clear evidence',
'School or workplace investigations',
'Restraining orders or legal protection',
'Understanding patterns and escalation',
'Demonstrating the full impact of the abuse',
'Supporting your case with timestamped, verified evidence',
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="h-6 w-6 rounded-full flex items-center justify-center shrink-0 shadow-sm" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                    <Check className="h-4 w-4 text-white" strokeWidth={2.5} />
                  </div>
                  <span className="text-sm text-muted-foreground leading-relaxed">{item}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20 shadow-xl bg-gradient-to-br from-card to-secondary/10">
          <CardHeader>
            <CardTitle className="text-2xl font-light gradient-text">What to Document (Even Without Our Service)</CardTitle>
            <CardDescription className="text-base">
              You can document evidence using any method - here's what's most important to save
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 shadow-md" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                  <Camera className="h-5 w-5 text-white" strokeWidth={2.5} />
                </div>
                <div className="space-y-2">
                  <h3 className="font-medium">Screenshots & Messages</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Capture full screenshots showing usernames, dates, times, and full conversations. 
                    Don't crop - include all context. Save original images if sent to you.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 shadow-md" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                  <Clock className="h-5 w-5 text-white" strokeWidth={2.5} />
                </div>
                <div className="space-y-2">
                  <h3 className="font-medium">Dates & Times</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Write down when each incident happened. Include time zones if communicating across regions. 
                    Note patterns - does it happen at certain times or after certain events?
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 shadow-md" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                  <Users className="h-5 w-5 text-white" strokeWidth={2.5} />
                </div>
                <div className="space-y-2">
                  <h3 className="font-medium">Account Information</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Save usernames, profile URLs, email addresses, phone numbers, and any identifying information. 
                    Screenshot profiles before they can be deleted or changed.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 shadow-md" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                  <Heart className="h-5 w-5 text-white" strokeWidth={2.5} />
                </div>
                <div className="space-y-2">
                  <h3 className="font-medium">Impact on Your Life</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Keep a journal of how this affects you - sleep problems, anxiety, school performance, 
                    friendships. This shows the real harm caused and strengthens your case.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0 shadow-md" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
                  <Shield className="h-5 w-5 text-white" strokeWidth={2.5} />
                </div>
                <div className="space-y-2">
                  <h3 className="font-medium">Who You've Told</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Document who you've reported to (parents, teachers, platform moderators) and when. 
                    Save any responses or case numbers you receive.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
              <p className="text-sm font-medium mb-2"> Storage Tips:</p>
              <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                <li>Store copies in multiple places (phone, computer, cloud, USB drive)</li>
                <li>Don't delete original messages - keep them as proof</li>
                <li>Organize by date in folders so you can find things easily</li>
                <li>Back up regularly in case your device is lost or damaged</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-xl text-center" style={{ background:'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)' }}>
          <CardContent className="p-8 space-y-4">
            <h2 className="text-2xl font-light text-white">Ready to Start Documenting?</h2>
            <p className="text-white/90 max-w-2xl mx-auto">
              Create a free account to access the full documentation system with timeline, evidence storage, impact tracking, and professional report generation.
            </p>
            <Button 
              onClick={() => navigate('/')} 
              variant="outline"
              className="bg-white text-primary hover:bg-white/90 shadow-lg font-medium border-primary"
              size="lg"
            >
              Create Free Account →
            </Button>
          </CardContent>
        </Card>
      </div>
    </PublicLayout>
  );
}
