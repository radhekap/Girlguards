import { useState, useEffect } from 'react';
import AppLayout from '@/components/layouts/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { storage } from '@/lib/storage';
import { generateFileHash, fileToBase64 } from '@/lib/crypto';
import type { IdentityInfo, EvidenceFile } from '@/types/types';
import { Upload, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useDebounce } from '@/hooks/use-debounce';

export default function EvidencePage() {
  const [identity, setIdentity] = useState<IdentityInfo>(() => storage.getIdentity());
  const [evidence, setEvidence] = useState<EvidenceFile[]>(() => storage.getEvidence());
  const [uploading, setUploading] = useState(false);

  const debouncedIdentity = useDebounce(identity, 500);

  useEffect(() => {
    storage.setIdentity(debouncedIdentity);
  }, [debouncedIdentity]);

  const handleIdentityChange = (field: keyof IdentityInfo, value: string) => {
    setIdentity(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    try {
      const newEvidence: EvidenceFile[] = [];

      for (const file of Array.from(files)) {
        if (!file.type.startsWith('image/')) {
          toast.error(`${file.name} is not an image file`);
          continue;
        }

        if (file.size > 5 * 1024 * 1024) {
          toast.error(`${file.name} exceeds 5MB limit`);
          continue;
        }

        const hash = await generateFileHash(file);
        const fileData = await fileToBase64(file);

        newEvidence.push({
          id: crypto.randomUUID(),
          fileName: file.name,
          fileData,
          hash,
          uploadedAt: new Date().toISOString(),
        });
      }

      const updatedEvidence = [...evidence, ...newEvidence];
      setEvidence(updatedEvidence);
      storage.setEvidence(updatedEvidence);
      toast.success(`${newEvidence.length} file(s) uploaded successfully`);
    } catch (error) {
      toast.error('Failed to upload files');
      console.error(error);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDeleteEvidence = (id: string) => {
    const updatedEvidence = evidence.filter(e => e.id !== id);
    setEvidence(updatedEvidence);
    storage.setEvidence(updatedEvidence);
    toast.success('Evidence deleted');
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-light tracking-tight">Evidence</h1>
          <p className="text-lg text-muted-foreground">
            Document identity information and store evidence with cryptographic verification.
          </p>
        </div>

        {/* Identity Tracker */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-light">Identity Tracker</CardTitle>
            <CardDescription>
              Record information about the person involved. This data auto-saves as you type.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="usernames">Usernames / Handles</Label>
              <Input
                id="usernames"
                placeholder="e.g., @username, display names"
                value={identity.usernames}
                onChange={(e) => handleIdentityChange('usernames', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="realName">Real Name (if known)</Label>
              <Input
                id="realName"
                placeholder="Enter real name if known"
                value={identity.realName}
                onChange={(e) => handleIdentityChange('realName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="otherDetails">Other Details</Label>
              <Textarea
                id="otherDetails"
                placeholder="Any other identifying information (location, age, school, etc.)"
                value={identity.otherDetails}
                onChange={(e) => handleIdentityChange('otherDetails', e.target.value)}
                rows={4}
              />
            </div>
          </CardContent>
        </Card>

        {/* Evidence Vault */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-light">Evidence Vault</CardTitle>
            <CardDescription>
              Upload screenshots and images. Each file generates a SHA-256 hash to prove it hasn't been altered.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <input
                type="file"
                id="fileUpload"
                multiple
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
                disabled={uploading}
              />
              <label htmlFor="fileUpload" className="cursor-pointer">
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-2">
                  {uploading ? 'Uploading...' : 'Click to upload screenshots'}
                </p>
                <p className="text-xs text-muted-foreground">
                  Accepts multiple images (PNG, JPG, GIF) up to 5MB each
                </p>
              </label>
            </div>

            {evidence.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Uploaded Evidence</h3>
                <div className="space-y-4">
                  {evidence.map((file) => (
                    <Card key={file.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <img
                            src={file.fileData}
                            alt={file.fileName}
                            className="w-24 h-24 object-cover rounded border"
                          />
                          <div className="flex-1 min-w-0 space-y-2">
                            <p className="text-sm font-medium truncate">{file.fileName}</p>
                            <p className="text-xs text-muted-foreground">
                              Uploaded: {new Date(file.uploadedAt).toLocaleString()}
                            </p>
                            <div className="space-y-1">
                              <p className="text-xs font-medium">SHA-256 Hash:</p>
                              <p className="text-xs font-mono break-all text-muted-foreground bg-muted p-2 rounded">
                                {file.hash}
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteEvidence(file.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
