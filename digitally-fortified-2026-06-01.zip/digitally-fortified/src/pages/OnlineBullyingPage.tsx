import { useState, useEffect, useRef } from'react';
import { AlertTriangle, MessageSquare, Eye, Shield, Heart, Phone, Lock, UserX, Flag, ChevronRight, CheckSquare, Square } from'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from'@/components/ui/accordion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from'@/components/ui/select';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
  grad: 'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

const bullyingTypes: Record<string, { label: string; definition: string; examples: string[]; firstSteps: string[]; note: string }> = {
  harassment: {
    label: 'Harassment & Threats',
    definition: "Sending repeated offensive, threatening, or abusive messages to someone directly through DMs, comments, or texts.",
    examples: [
      'Threatening messages ("I know where you live," "You\'ll regret this")',
      'Sending hundreds of hostile messages in a short time',
      'Calling someone offensive names repeatedly across multiple platforms',
    ],
    firstSteps: [
      "Do NOT respond. Any response — even asking them to stop — encourages more messages.",
      "Screenshot every message with timestamps visible before blocking.",
      "Block the sender on every platform they've used.",
      "If any message contains a physical threat, report to police immediately — this is a crime.",
    ],
    note: "Harassment that includes threats of physical harm is a criminal offence in most jurisdictions, not just a social media violation.",
  },
  exclusion: {
    label: 'Social Exclusion',
    definition: "Deliberately leaving someone out of online groups, chats, or activities to isolate or humiliate them.",
    examples: [
      'Being removed from a group chat without explanation',
      'Being excluded from online game sessions everyone else is included in',
      'Being left out of plans that are discussed publicly online while you are deliberately not invited',
    ],
    firstSteps: [
      "Recognise this as a valid form of bullying — it causes real harm even without any words being said.",
      "Document instances where you were explicitly removed or excluded.",
      "Talk to a trusted friend or adult — isolation is more harmful when kept secret.",
      "Report the group to the platform if it was created specifically to exclude or mock you.",
    ],
    note: "Social exclusion is one of the most psychologically damaging forms of bullying because victims often question whether it's 'really bullying.'",
  },
  impersonation: {
    label: 'Impersonation & Fake Profiles',
    definition: "Creating fake accounts using someone's identity, photos, or personal information to damage their reputation or deceive others.",
    examples: [
      'Creating a fake Instagram account with your photos and name',
      'Sending messages to your contacts pretending to be you',
      'Using your photos to create profiles on dating or adult sites',
    ],
    firstSteps: [
      "Report the fake account to the platform immediately — most have a specific 'impersonation' report category.",
      "Alert your friends and followers directly so they know the account is fake.",
      "Screenshot the fake profile and all its content before reporting (platforms often remove quickly).",
      "File a police report — creating fake profiles to harm someone is identity fraud in many countries.",
    ],
    note: "Using someone's photos on adult sites is a specific crime in many jurisdictions. Law enforcement takes this seriously.",
  },
  rumors: {
    label: 'Rumours & False Information',
    definition: "Spreading false or misleading information, edited images, or private details about someone to damage their reputation.",
    examples: [
      'Sharing edited or out-of-context screenshots to make someone look bad',
      'Starting false rumours in group chats or on social media',
      'Sharing someone\'s private information (address, family details, relationship status) without consent',
    ],
    firstSteps: [
      "Don't try to publicly argue or correct every post — it often amplifies the rumour.",
      "Document all posts, accounts, and screenshots spreading the false information.",
      "Report each post/account to the platform for harassment, defamation, or false information.",
      "If the false information is affecting your school or work life, report it to a responsible adult there as well.",
    ],
    note: "Publishing false statements that damage someone's reputation is defamation — it's legally actionable. Keep all evidence.",
  },
  imagebased: {
    label: 'Image-Based Abuse',
    definition: "Sharing, threatening to share, or demanding intimate images of someone without their consent — also called 'revenge porn' or sextortion.",
    examples: [
      'Sharing intimate images sent in a private relationship without consent',
      'Threatening to share images unless demands are met (sextortion)',
      'Sharing embarrassing or edited images to humiliate someone',
    ],
    firstSteps: [
      "Do NOT pay or comply with demands. Paying sextortion demands almost never makes them stop.",
      "Report to the FBI's Internet Crime Complaint Center (IC3) or local police — this is a serious crime.",
      "Contact the platform immediately using their specific image removal tools. Most major platforms have priority processes for this.",
      "Contact StopNCII.org — they can help prevent images spreading further across platforms.",
    ],
    note: "Image-based abuse is a crime in every U.S. state and most countries. You are a victim. You have done nothing wrong.",
  },
};


function StatBar({ value, label }: { value: number; label: string }) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setTimeout(() => setWidth(value), 120); observer.disconnect(); } },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);

  return (
    <div className="space-y-1.5" ref={ref}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs text-muted-foreground text-pretty">{label}</span>
        <span className="text-xl font-light text-primary shrink-0">{value}%</span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
        <div className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${width}%`, background: G.grad }} />
      </div>
    </div>
  );
}

export default function OnlineBullyingPage() {
  const [checkedWarnings, setCheckedWarnings] = useState<Set<number>>(new Set());
  const [bullyingType, setBullyingType] = useState<string>('');

  const toggleWarning = (i: number) =>
    setCheckedWarnings(prev => { const n = new Set(prev); n.has(i) ? n.delete(i) : n.add(i); return n; });
  const types = [
    { icon: MessageSquare, title: 'Harassment & Name-Calling', desc: 'Repeated offensive messages, insults, or threats sent directly or posted publicly' },
    { icon: Eye, title: 'Spreading Rumors & False Information', desc: "Sharing lies, embarrassing information, or manipulated images to damage someone's reputation" },
    { icon: UserX, title: 'Exclusion & Social Isolation', desc: 'Deliberately excluding someone from online groups, chats, or activities to make them feel isolated' },
    { icon: AlertTriangle, title: 'Doxxing & Privacy Violations', desc: "Sharing someone's private information (address, phone number, photos) without consent" },
    { icon: Heart, title: 'Impersonation & Catfishing', desc: 'Creating fake accounts pretending to be someone else to embarrass or harm them' },
  ];

  const preventionGroups = [
    {
      icon: Lock,
      title: 'Protect Your Privacy',
      items: [
        'Use strong privacy settings on all social media accounts',
        "Don't share personal information (address, phone number, school name) publicly",
        'Be selective about who you accept as friends or followers',
      ],
    },
    {
      icon: Eye,
      title: 'Think Before You Post',
      items: [
        'Remember that anything you post can be screenshot and shared',
        "Avoid posting when you're emotional or upset",
        "Don't share photos or information you wouldn't want everyone to see",
      ],
    },
    {
      icon: Shield,
      title: 'Set Boundaries',
      items: [
        'Block or mute people who make you uncomfortable',
        "You don't owe anyone a response or explanation",
        'Take breaks from social media when you need to',
      ],
    },
  ];

  const steps = [
    {
      num: 1, icon: Shield,
      title: "Don't Respond (Even If You Want To)",
      body: "Bullies want a reaction. Responding — even to defend yourself — usually makes it worse. They'll screenshot it and use it against you. Just don't engage.",
      note: "What to do instead: Walk away from your phone. Text a friend. Do something that makes you feel good.",
    },
    {
      num: 2, icon: Eye,
      title: 'Save Everything (Screenshots Are Your Friend)',
      body: 'Screenshot every message, post, comment, or DM. Make sure the date, time, and username are visible. Save them to a folder or email them to yourself. This is your evidence.',
      note: "Why this matters: If you need to report this to school, parents, or police later, you'll have proof of what happened.",
    },
    {
      num: 3, icon: UserX,
      title: 'Block Them Immediately',
      body: "Every platform has a block button. Use it. You don't owe anyone access to you. Block on Instagram, TikTok, Snapchat, Discord — everywhere they can reach you.",
      note: 'How to block: Tap their profile → three dots (⋯) → Block. It takes 5 seconds and you\'ll feel better instantly.',
    },
    {
      num: 4, icon: Flag,
      title: 'Report to the Platform',
      body: "Instagram, TikTok, Snapchat, and other platforms have report buttons. Use them. They actually do remove content that violates their rules (threats, harassment, sharing private info).",
      note: 'Where to find it: Usually next to the block button. Select "Harassment" or "Bullying" as the reason.',
    },
    {
      num: 5, icon: Heart,
      title: 'Tell Someone (Yes, Really)',
      body: "Tell a parent, older sibling, teacher, school counselor, or trusted adult. If you're worried they'll overreact, say \"I need help with something, but I need you to listen first before taking action.\" Most adults want to help, not make it worse.",
      note: "Can't tell an adult? Tell a friend. Text a crisis line (Crisis Text Line: text HOME to 741741). Just don't keep it to yourself.",
    },
    {
      num: 6, icon: AlertTriangle,
      title: "If It's Serious, Report to School or Police",
      body: "If someone is threatening you, sharing private photos, or doxxing you (posting your address/phone number), this is illegal. Schools have policies against cyberbullying. Police can get involved for threats, blackmail, or sharing intimate images.",
      note: "What counts as serious: Threats of violence, sexual harassment, sharing nude photos, stalking, or anything that makes you fear for your safety.",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">
      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Online Safety</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">Online Bullying & Harassment</h1>
        <p className="text-base text-muted-foreground text-pretty">
          Understanding, recognizing, and responding to online bullying and harassment
        </p>
      </div>

      {/* Bullying type selector */}
      <section className="space-y-4 animate-fade-in">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Flag className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">What's happening to you?</h2>
            <p className="text-sm text-muted-foreground">Select the type of bullying for specific information and first steps</p>
          </div>
        </div>
        <Select value={bullyingType} onValueChange={setBullyingType}>
          <SelectTrigger className="w-full max-w-sm h-11 text-sm">
            <SelectValue placeholder="Select a type…" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(bullyingTypes).map(([key, val]) => (
              <SelectItem key={key} value={key}>{val.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {bullyingType && bullyingTypes[bullyingType] && (() => {
          const type = bullyingTypes[bullyingType];
          return (
            <div className="rounded-xl border border-border p-5 space-y-4 animate-fade-in">
              <div className="space-y-1.5">
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">What it is</p>
                <p className="text-sm text-muted-foreground text-pretty">{type.definition}</p>
              </div>
              <div className="space-y-2 border-t pt-4">
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Examples</p>
                {type.examples.map((ex, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary shrink-0 mt-1.5" />
                    <p className="text-sm text-muted-foreground text-pretty">{ex}</p>
                  </div>
                ))}
              </div>
              <div className="space-y-2 border-t pt-4">
                <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Your first steps</p>
                {type.firstSteps.map((step, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0 mt-0.5"
                      style={{ background: G.grad }}>{i + 1}</div>
                    <p className="text-sm text-muted-foreground text-pretty">{step}</p>
                  </div>
                ))}
              </div>
              <div className="flex items-start gap-2.5 rounded-lg border border-primary/25 bg-primary/5 px-4 py-3">
                <Shield className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.75} />
                <p className="text-sm text-muted-foreground text-pretty">{type.note}</p>
              </div>
            </div>
          );
        })()}
      </section>

      {/* Statistics with bars */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <AlertTriangle className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">The Reality of Online Bullying</h2>
            <p className="text-sm text-muted-foreground">Online harassment is widespread and can have serious consequences</p>
          </div>
        </div>
        <div className="rounded-xl border border-border p-5 space-y-5">
          <StatBar value={59} label="of U.S. teens have experienced some form of cyberbullying" />
          <StatBar value={42} label="of teens say they've been called offensive names online" />
          <StatBar value={32} label="have had false rumors spread about them online" />
        </div>
      </section>

      {/* Types of bullying — icon cards */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <MessageSquare className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Types of Online Harassment</h2>
            <p className="text-sm text-muted-foreground">Recognizing different forms of cyberbullying</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {types.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl border border-border p-4 flex items-start gap-3 h-full">
              <div className="shrink-0 mt-0.5 h-8 w-8 rounded-lg flex items-center justify-center" style={{ background: G.gradSoft }}>
                <Icon className="h-4 w-4 text-primary" strokeWidth={1.75} />
              </div>
              <div className="space-y-0.5 min-w-0">
                <p className="text-sm font-medium text-foreground">{title}</p>
                <p className="text-xs text-muted-foreground leading-relaxed text-pretty">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Warning signs — checkable */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Eye className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Warning Signs You're Being Targeted</h2>
            <p className="text-sm text-muted-foreground">Tap any you've experienced — this is just for your own awareness, nothing is saved</p>
          </div>
        </div>
        <ul className="space-y-2">
          {[
            'You receive repeated mean, threatening, or embarrassing messages',
            'People are sharing embarrassing photos, videos, or information about you',
            "You're being excluded from group chats or online activities on purpose",
            'Someone created a fake account pretending to be you',
            'You feel anxious, upset, or afraid when you check your phone or social media',
          ].map((item, i) => {
            const checked = checkedWarnings.has(i);
            return (
              <li key={item}>
                <button onClick={() => toggleWarning(i)}
                  className={[
                    'w-full text-left flex items-start gap-3 p-3 rounded-xl border transition-all duration-200',
                    checked ? 'border-primary/30 bg-primary/5' : 'border-border hover:border-primary/20',
                  ].join(' ')}>
                  {checked
                    ? <CheckSquare className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.75} />
                    : <Square className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" strokeWidth={1.5} />}
                  <span className={['text-sm transition-colors', checked ? 'text-foreground' : 'text-muted-foreground'].join(' ')}>{item}</span>
                </button>
              </li>
            );
          })}
        </ul>
        {checkedWarnings.size > 0 && (
          <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3 animate-fade-in">
            <Heart className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
            <p className="text-sm text-muted-foreground text-pretty">
              You've identified {checkedWarnings.size} warning sign{checkedWarnings.size > 1 ? 's' : ''}. Please scroll down to the action steps below and consider telling a trusted adult.
            </p>
          </div>
        )}
      </section>

      {/* Prevention — icon groups */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Shield className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">Prevention & Protection Strategies</h2>
            <p className="text-sm text-muted-foreground">Steps you can take to protect yourself</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {preventionGroups.map(({ icon: Icon, title, items }) => (
            <div key={title} className="rounded-xl border border-border p-4 space-y-3 h-full flex flex-col">
              <div className="flex items-center gap-2">
                <div className="h-7 w-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                  <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
                </div>
                <p className="text-sm font-medium text-foreground">{title}</p>
              </div>
              <ul className="space-y-2 flex-1">
                {items.map(it => (
                  <li key={it} className="flex items-start gap-2 text-xs text-muted-foreground">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary shrink-0 mt-1.5" />
                    <span className="text-pretty">{it}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* If bullied now — numbered steps */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
            <Phone className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-light tracking-tight">If You're Being Bullied Right Now</h2>
            <p className="text-sm text-muted-foreground">Immediate, practical steps anyone can take</p>
          </div>
        </div>

        <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3">
          <Heart className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
          <div>
            <p className="text-sm font-medium text-foreground mb-1">First: Take Care of Yourself</p>
            <p className="text-sm text-muted-foreground text-pretty">
              Close the app. Put your phone down. Take three deep breaths. You don't have to deal with this alone or right this second. Your mental health comes first.
            </p>
          </div>
        </div>

        <Accordion type="single" collapsible className="space-y-2">
          {steps.map(({ num, icon: Icon, title, body, note }) => (
            <AccordionItem key={num} value={`step-${num}`}
              className="rounded-xl border border-border overflow-hidden px-0">
              <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="h-7 w-7 rounded-full flex items-center justify-center font-semibold text-sm text-white shrink-0"
                    style={{ background: G.grad }}>{num}</div>
                  <div className="h-7 w-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                    <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
                  </div>
                  <span className="text-sm font-medium text-foreground text-left">{title}</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-4 pt-0 pl-[calc(1rem+1.75rem+1.75rem+1.5rem)]">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground text-pretty">{body}</p>
                  <p className="text-xs italic text-muted-foreground text-pretty">{note}</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="rounded-xl border border-border p-5 space-y-3">
          <p className="text-sm font-medium text-foreground">What If I Can't Do All of This?</p>
          <p className="text-sm text-muted-foreground text-pretty">
            That's okay. Do what you can. Even just blocking them and telling one person is a huge step. You don't have to be perfect — you just have to take care of yourself.
          </p>
        </div>

        <div className="rounded-xl border border-primary/20 p-4">
          <p className="text-sm text-muted-foreground text-pretty">
            <strong className="text-foreground">Remember:</strong> This is not your fault. You didn't ask for this. You don't deserve this. And you're not weak for being affected by it. Online bullying is real, it hurts, and you have every right to protect yourself and get help.
          </p>
        </div>
      </section>
    </div>
  );
}


