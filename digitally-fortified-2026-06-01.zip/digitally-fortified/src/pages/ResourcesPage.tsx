import { ExternalLink, BookOpen, FileText, Newspaper, GraduationCap, Phone, Scale } from'lucide-react';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
};

function SectionHeading({ icon: Icon, title, sub }: { icon: React.ElementType; title: string; sub: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
        <Icon className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
      </div>
      <div>
        <h2 className="text-xl font-light tracking-tight">{title}</h2>
        <p className="text-sm text-muted-foreground mt-0.5">{sub}</p>
      </div>
    </div>
  );
}

function ResourceRow({ title, desc, badge, url }: { title: string; desc: string; badge?: string; url: string }) {
  return (
    <a href={url} target="_blank" rel="noopener noreferrer"
      className="flex items-start justify-between gap-3 p-3 rounded-xl border border-border hover:border-primary/30 transition-colors group">
      <div className="space-y-0.5 min-w-0 flex-1">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-sm font-medium text-foreground group-hover:underline">{title}</p>
          {badge && <span className="text-xs px-2 py-0.5 rounded-full border border-primary/20 text-primary shrink-0">{badge}</span>}
        </div>
        <p className="text-xs text-muted-foreground text-pretty">{desc}</p>
      </div>
      <ExternalLink className="h-3.5 w-3.5 text-primary shrink-0 mt-1" strokeWidth={1.5} />
    </a>
  );
}

export default function ResourcesPage() {
  const organizations = [
    { name:'Cyber Civil Rights Initiative', description:'Leading organization combating online abuse and image-based sexual abuse', url:'https://cybercivilrights.org' },
    { name:'National Center for Missing & Exploited Children', description:'CyberTipline for reporting online exploitation', url:'https://www.missingkids.org' },
    { name:'RAINN (Rape, Abuse & Incest National Network)', description:'National Sexual Assault Hotline and online resources', url:'https://www.rainn.org' },
    { name:'Thorn', description:'Building technology to defend children from sexual abuse', url:'https://www.thorn.org' },
    { name:'National Suicide Prevention Lifeline', description:'24/7 crisis support — Call 988 or chat online', url:'https://988lifeline.org' },
    { name:'Crisis Text Line', description:'Text HOME to 741741 for free 24/7 crisis support', url:'https://www.crisistextline.org' },
  ];
  const research = [
    { title:'Cyberbullying Research Center', description:'Comprehensive research and statistics on cyberbullying', url:'https://cyberbullying.org', type:'Research Database' },
    { title:'Pew Research: Teens, Social Media & Technology', description:'Data and insights on how teens use social media', url:'https://www.pewresearch.org/internet/topics/teens-and-tech/', type:'Research Report' },
    { title:'Common Sense Media Research', description:"Studies on media use and its impact on children and teens", url:'https://www.commonsensemedia.org/research', type:'Research Database' },
    { title:"The Social Dilemma (Documentary)", description:"Documentary exploring social media's impact on mental health", url:'https://www.thesocialdilemma.com', type:'Video' },
  ];
  const guides = [
    { title:'Instagram Safety & Privacy Guide', description:'Official guide to privacy settings and safety features', url:'https://help.instagram.com/369001149843369', platform:'Instagram' },
    { title:'TikTok Safety Center', description:'Resources for staying safe on TikTok', url:'https://www.tiktok.com/safety', platform:'TikTok' },
    { title:'Snapchat Safety & Privacy', description:'How to control your privacy on Snapchat', url:'https://values.snap.com/privacy/privacy-center', platform:'Snapchat' },
    { title:'Discord Safety Center', description:'Staying safe in Discord communities', url:'https://discord.com/safety', platform:'Discord' },
  ];
  const articles = [
    { title:'How to Document Online Harassment', description:'Step-by-step guide from the Cyber Civil Rights Initiative', url:'https://cybercivilrights.org/online-removal/', source:'CCRI' },
    { title:'Understanding Digital Consent', description:'What consent means in the digital age', url:'https://www.rainn.org/articles/what-is-consent', source:'RAINN' },
    { title:'Social Media and Mental Health', description:"Research-backed insights on social media's effects", url:'https://www.helpguide.org/articles/mental-health/social-media-and-mental-health.htm', source:'HelpGuide' },
    { title:'Protecting Your Digital Privacy', description:'Practical tips for online privacy', url:'https://www.eff.org/issues/privacy', source:'EFF' },
  ];
  const legal = [
    { title:'Know Your Rights: Online Harassment', description:'Legal information about online harassment and your rights', url:'https://www.aclu.org/know-your-rights/free-speech', source:'ACLU' },
    { title:'State Laws on Cyberbullying', description:'Database of cyberbullying laws by state', url:'https://cyberbullying.org/bullying-laws', source:'Cyberbullying Research Center' },
    { title:'Revenge Porn Laws by State', description:'Legal protections against non-consensual intimate images', url:'https://cybercivilrights.org/ccri-state-law-resource-list/', source:'CCRI' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 p-4 md:p-8">

      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Trusted Links</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">External Resources</h1>
        <p className="text-base text-muted-foreground text-pretty">
          A curated collection of trusted organizations, research, guides, and articles to support your safety and wellbeing online
        </p>
      </div>

      {/* Crisis Organizations */}
      <section className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Phone} title="Crisis Support Organizations" sub="Immediate help when you need it most" />
        <div className="grid gap-3 md:grid-cols-2">
          {organizations.map(org => (
            <a key={org.name} href={org.url} target="_blank" rel="noopener noreferrer"
              className="rounded-xl border border-primary/20 p-4 flex items-start gap-3 hover:border-primary/40 transition-colors group h-full">
              <div className="min-w-0 flex-1 space-y-0.5">
                <p className="text-sm font-medium text-foreground group-hover:underline">{org.name}</p>
                <p className="text-xs text-muted-foreground text-pretty">{org.description}</p>
              </div>
              <ExternalLink className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
            </a>
          ))}
        </div>
      </section>

      {/* Research */}
      <section className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={GraduationCap} title="Research & Studies" sub="Evidence-based insights and data" />
        <div className="space-y-2">
          {research.map(item => <ResourceRow key={item.title} title={item.title} desc={item.description} badge={item.type} url={item.url} />)}
        </div>
      </section>

      {/* Platform guides */}
      <section className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={FileText} title="Platform Safety Guides" sub="Official privacy and safety resources" />
        <div className="grid gap-3 md:grid-cols-2">
          {guides.map(guide => (
            <a key={guide.title} href={guide.url} target="_blank" rel="noopener noreferrer"
              className="rounded-xl border border-border p-4 flex items-start gap-3 hover:border-primary/30 transition-colors group h-full">
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-medium text-foreground group-hover:underline">{guide.title}</p>
                  <span className="text-xs px-2 py-0.5 rounded-full border border-border text-muted-foreground shrink-0">{guide.platform}</span>
                </div>
                <p className="text-xs text-muted-foreground text-pretty">{guide.description}</p>
              </div>
              <ExternalLink className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
            </a>
          ))}
        </div>
      </section>

      {/* Articles */}
      <section className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Newspaper} title="Articles & Educational Content" sub="In-depth guides and information" />
        <div className="space-y-2">
          {articles.map(a => <ResourceRow key={a.title} title={a.title} desc={a.description} badge={a.source} url={a.url} />)}
        </div>
      </section>

      {/* Legal */}
      <section className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Scale} title="Legal Information & Rights" sub="Understanding your legal protections" />
        <div className="space-y-2">
          {legal.map(l => <ResourceRow key={l.title} title={l.title} desc={l.description} badge={l.source} url={l.url} />)}
        </div>
      </section>

      {/* Disclaimer */}
      <div className="rounded-xl border border-border p-4">
        <p className="text-xs text-muted-foreground text-pretty">
          <strong className="text-foreground">Note:</strong> These are external resources provided for informational purposes. girlGuard is not affiliated with these organizations, and we cannot guarantee the availability or accuracy of external content. If you're in immediate danger, please call 911 or your local emergency services.
        </p>
      </div>

    </div>
  );
}


