import PublicLayout from'@/components/layouts/PublicLayout';
import { ExternalLink } from'lucide-react';

// ─── DATA ─────────────────────────────────────────────────────────────────────

interface Citation {
  id: string;
  stat: string;
  context: string;
  source: string;
  author?: string;
  year: string;
  url: string;
  usedOn: string[];
}

const CITATIONS: Citation[] = [
  // ── Landing page / Prevention ──────────────────────────────────────────────
  {
    id:'c1',
    stat:'90% of image-based abuse victims are female',
    context:
'Non-consensual intimate image (NCII) victims skew heavily female. Teenage girls are the most targeted demographic.',
    source:'Cyber Civil Rights Initiative — "Nonconsensual Pornography: Research Overview"',
    year:'2014',
    url:'https://cybercivilrights.org/research/',
    usedOn: ['Landing page','Statistics page','Prevention & Stats'],
  },
  {
    id:'c2',
    stat:'68% of online abuse happens on social media',
    context:
'Across platforms such as Instagram, Snapchat, and TikTok, over two-thirds of all reported online abuse incidents originate.',
    source:'Thorn — "Survivor Insights: The Role of Technology in Domestic Minor Sex Trafficking"',
    year:'2019',
    url:'https://www.thorn.org/research/',
    usedOn: ['Landing page','Prevention & Stats'],
  },
  {
    id:'c3',
    stat:'41% of U.S. adults have experienced online harassment',
    context:
'Nearly half of all American adults report some form of online harassment; rates are higher for younger women and girls.',
    source:'Pew Research Center — "Online Harassment 2021"',
    author:'Emily A. Vogels',
    year:'2021',
    url:'https://www.pewresearch.org/internet/2021/01/13/the-state-of-online-harassment/',
    usedOn: ['Landing page','Prevention & Stats','Social & Emotional Impact'],
  },
  {
    id:'c4',
    stat:'74% of reports to law enforcement go unresolved',
    context:
'The vast majority of online harassment and NCII reports made to police result in no charges or prosecution, leaving victims without legal recourse.',
    source:'National Network to End Domestic Violence — "Safety Net: Technology Safety",  Cyber Civil Rights Initiative victim survey data',
    year:'2018–2022',
    url:'https://www.techsafety.org/',
    usedOn: ['Landing page stats strip'],
  },

  // ── Statistics page ────────────────────────────────────────────────────────
  {
    id:'c5',
    stat:'72% of online harassment victims are women',
    context:
'An 11-year longitudinal analysis of online harassment cases found women represent nearly three-quarters of all identified victims.',
    source:'Women\'s Media Center — "Online Abuse 101"',
    year:'2020',
    url:'https://womensmediacenter.com/speech-project/online-abuse-101',
    usedOn: ['Statistics page'],
  },
  {
    id:'c6',
    stat:'Young women are cyberstalked at 26% vs 7% for young men',
    context:
'Young women aged 18–29 experience cyberstalking at nearly four times the rate of their male peers.',
    source:'Pew Research Center — "Online Harassment 2021"',
    author:'Emily A. Vogels',
    year:'2021',
    url:'https://www.pewresearch.org/internet/2021/01/13/the-state-of-online-harassment/',
    usedOn: ['Statistics page'],
  },
  {
    id:'c7',
    stat:'Female-identifying usernames receive threatening messages 25× more often',
    context:
'Research using honeypot accounts demonstrated that usernames perceived as female attracted aggressive or sexual messages at dramatically higher rates.',
    source:'University of Maryland — "Chatting with Bots: Unsolicited & Harassing Messages" (USENIX Security)',
    author:'Joel Rosenthal et al.',
    year:'2007',
    url:'https://www.cs.umd.edu/~tdumitra/public_papers/USENIX07.pdf',
    usedOn: ['Statistics page'],
  },
  {
    id:'c8',
    stat:'Female politicians targeted by AI deepfakes 70× more than male counterparts',
    context:
'The overwhelming majority of non-consensual AI-generated deepfake imagery depicts women, including prominent political figures.',
    source:'Sensity AI (now Reality Defender) — "The State of Deepfakes 2023"',
    year:'2023',
    url:'https://sensity.ai/',
    usedOn: ['Statistics page'],
  },
  {
    id:'c9',
    stat:'93% of NCII victims experience significant emotional distress',
    context:
'The vast majority of image-based abuse survivors report severe psychological consequences including anxiety, depression, and PTSD symptoms.',
    source:'Cyber Civil Rights Initiative — "Nonconsensual Pornography: Research Overview"',
    year:'2014',
    url:'https://cybercivilrights.org/research/',
    usedOn: ['Statistics page'],
  },
  {
    id:'c10',
    stat:'50%+ of NCII victims lose five or more days of work',
    context:
'More than half of image-based abuse victims report missing significant time at work or school due to the psychological and practical impacts.',
    source:'Cyber Civil Rights Initiative — "Nonconsensual Pornography: Research Overview"',
    year:'2014',
    url:'https://cybercivilrights.org/research/',
    usedOn: ['Statistics page'],
  },
  {
    id:'c11',
    stat:'1 in 10 intimate partners threatens NCII; 60% carry it out',
    context:
'Among survivors who experienced intimate partner abuse, approximately 10% reported their partner threatened to share intimate images, and the majority followed through.',
    source:'Cyber Civil Rights Initiative — Victim Survey Data',
    year:'2017',
    url:'https://cybercivilrights.org/research/',
    usedOn: ['Statistics page'],
  },
  {
    id:'c12',
    stat:'60% of women on dating apps report persistent unwanted contact',
    context:
'A majority of younger women using dating platforms experienced someone continuing to contact them after they explicitly declined.',
    source:'Pew Research Center — "Dating & Relationships in the Digital Age"',
    year:'2020',
    url:'https://www.pewresearch.org/internet/2020/02/06/the-virtues-and-downsides-of-online-dating/',
    usedOn: ['Statistics page'],
  },
  {
    id:'c13',
    stat:'70% of female gamers hide their gender online',
    context:
'The majority of women who play online games conceal their gender to avoid harassment, sexism, and doxxing.',
    source:'Lenhart, A. et al. — "Online Harassment, Digital Abuse and Cyberstalking", Data & Society',
    year:'2016',
    url:'https://datasociety.net/pubs/oh/Online_Harassment_2016.pdf',
    usedOn: ['Statistics page'],
  },
  {
    id:'c14',
    stat:'85% of domestic violence shelters report GPS/spyware tracking of victims',
    context:
'Most domestic violence programmes encounter situations where abusers used location tracking technology or spyware to monitor survivors.',
    source:'National Network to End Domestic Violence — "Technology Safety & Privacy Toolkit"',
    year:'2021',
    url:'https://www.techsafety.org/resources-survivors',
    usedOn: ['Statistics page'],
  },
  {
    id:'c15',
    stat: "75% of domestic abuse programmes report abusers hacking victims' accounts",
    context:
      "Three-quarters of organisations supporting domestic abuse survivors encounter cases where abusers accessed the victim's social media or online accounts without consent.",
    source:'National Network to End Domestic Violence — "Technology Safety & Privacy Toolkit"',
    year:'2021',
    url:'https://www.techsafety.org/resources-survivors',
    usedOn: ['Statistics page'],
  },
];

const SECTIONS = [
  {
    title:'Landing Page & Prevention Statistics',
    ids: ['c1','c2','c3','c4'],
  },
  {
    title:'Statistics Page — Cyberstalking & Harassment',
    ids: ['c5','c6','c7','c8'],
  },
  {
    title:'Statistics Page — Image-Based Sexual Abuse',
    ids: ['c9','c10','c11'],
  },
  {
    title:'Statistics Page — Dating Apps, Gaming & Domestic Overlap',
    ids: ['c12','c13','c14','c15'],
  },
];

const citationMap = Object.fromEntries(CITATIONS.map(c => [c.id, c]));

// ─── COMPONENT ────────────────────────────────────────────────────────────────

function CitationCard({ citation }: { citation: Citation }) {
  return (
    <div className="space-y-3 py-8 border-b border-border last:border-0
                    opacity-0 intersect:opacity-100 transition duration-700">
      {/* Stat headline */}
      <p className="text-2xl md:text-3xl font-light tracking-tight text-balance gradient-text">
        {citation.stat}
      </p>

      {/* Context */}
      <p className="text-sm text-muted-foreground leading-relaxed text-pretty max-w-2xl">
        {citation.context}
      </p>

      {/* Citation metadata */}
      <div className="flex flex-wrap items-start gap-x-4 gap-y-1 pt-1 text-xs text-muted-foreground">
        {citation.author && <span className="font-medium text-foreground/70">{citation.author}</span>}
        <span>{citation.source}</span>
        <span className="tabular-nums">{citation.year}</span>
        <a
          href={citation.url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-primary hover:underline underline-offset-4 transition-colors shrink-0">
          View source
          <ExternalLink className="h-3 w-3" strokeWidth={2.5} />
        </a>
      </div>

      {/* Page tags */}
      <div className="flex flex-wrap gap-1.5 pt-0.5">
        {citation.usedOn.map(page => (
          <span key={page}
            className="text-xs px-2 py-0.5 rounded-full border border-border text-muted-foreground">
            {page}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function SourcesPage() {
  return (
    <PublicLayout>
      <div className="max-w-4xl mx-auto space-y-16 px-4 md:px-8 py-12 md:py-16">

        {/* Page header */}
        <div className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
          <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">
            Transparency
          </p>
          <h1 className="text-4xl md:text-5xl font-light tracking-tight text-balance">
            Sources &amp; References
          </h1>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed text-pretty max-w-2xl">
            Every statistic and fact displayed on girlGuard is sourced from peer-reviewed
            research, reputable NGO reports, or established academic studies.
            We list them here so you can read the primary sources yourself.
          </p>
        </div>

        <hr className="border-border" />

        {/* Citation sections */}
        {SECTIONS.map(section => (
          <section key={section.title} className="space-y-2">
            <h2 className="text-xs font-semibold tracking-widest uppercase text-muted-foreground
                           opacity-0 intersect:opacity-100 transition duration-500 mb-2">
              {section.title}
            </h2>
            <div>
              {section.ids.map(id => (
                <CitationCard key={id} citation={citationMap[id]} />
              ))}
            </div>
          </section>
        ))}

        <hr className="border-border" />

        {/* Disclaimer */}
        <div className="space-y-3 text-sm text-muted-foreground leading-relaxed
                         opacity-0 intersect:opacity-100 transition duration-700">
          <p className="font-medium text-foreground">A note on statistics</p>
          <p className="text-pretty">
            Online abuse research is a rapidly evolving field. Some studies are limited by
            self-reported data, platform restrictions, or geographic scope. Where exact figures
            differ slightly across studies, we have used the most widely cited or conservative
            estimate. If you believe a citation is inaccurate or outdated, please reach out
            through the About page.
          </p>
          <p className="text-pretty">
            girlGuard is an educational and documentation tool. Nothing on this site
            constitutes legal or medical advice.
          </p>
        </div>

      </div>
    </PublicLayout>
  );
}
