import PublicLayout from'@/components/layouts/PublicLayout';
import { AlertTriangle, Users, Shield, Heart, TrendingUp } from'lucide-react';

// Visual stat bar component
function StatBar({ value, max = 100, label, sublabel }: { value: number; max?: number; label: string; sublabel: string }) {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-sm text-foreground font-medium text-pretty">{sublabel}</span>
        <span className="text-2xl font-light text-primary shrink-0">{label}</span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700"
          style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #FF6B9D 0%, #B794F6 100%)' }} />
      </div>
    </div>
  );
}

// Comparison bar: two groups side by side
function CompareBar({ labelA, valueA, labelB, valueB, title, sub }: { labelA: string; valueA: number; labelB: string; valueB: number; title: string; sub: string }) {
  const total = valueA + valueB;
  const pctA = Math.round((valueA / total) * 100);
  return (
    <div className="space-y-2 p-4 rounded-xl border border-border">
      <p className="text-sm font-medium text-foreground">{title}</p>
      <p className="text-xs text-muted-foreground text-pretty">{sub}</p>
      <div className="flex items-center gap-2 mt-3">
        <span className="text-xs w-16 text-right text-muted-foreground shrink-0">{labelA}</span>
        <div className="flex-1 h-5 rounded-full bg-border overflow-hidden flex">
          <div className="h-full rounded-l-full"
            style={{ width: `${pctA}%`, background: 'linear-gradient(90deg, #FF6B9D 0%, #B794F6 100%)' }} />
        </div>
        <span className="text-xs w-16 text-muted-foreground shrink-0">{labelB}</span>
      </div>
      <div className="flex gap-4 text-xs text-muted-foreground mt-1 pl-20">
        <span className="font-semibold text-primary">{valueA}%</span>
        <span className="text-border">vs</span>
        <span>{valueB}%</span>
      </div>
    </div>
  );
}

function SectionHeading({ icon: Icon, title, sub }: { icon: React.ElementType; title: string; sub: string }) {
  return (
    <div className="flex items-start gap-4 pb-2 border-b border-border">
      <div className="h-10 w-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
        style={{ background: 'linear-gradient(135deg, rgba(255,107,157,0.15) 0%, rgba(183,148,246,0.15) 100%)' }}>
        <Icon className="h-5 w-5 text-primary" strokeWidth={1.75} />
      </div>
      <div>
        <h2 className="text-xl md:text-2xl font-light tracking-tight">{title}</h2>
        <p className="text-sm text-muted-foreground mt-0.5">{sub}</p>
      </div>
    </div>
  );
}

export default function StatisticsPage() {
  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto space-y-14 p-4 md:p-8">

        {/* Hero */}
        <div className="space-y-4">
          <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Data & Research</p>
          <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">
            The Reality: Cybercrimes Against Women & Girls
          </h1>
          <p className="text-base md:text-lg text-muted-foreground max-w-3xl text-pretty">
            While financial cybercrimes affect everyone, stalking, harassment, and sexual exploitation disproportionately target women and girls. These statistics reveal the urgent need for awareness and action.
          </p>
        </div>

        {/* Cyberstalking and Harassment */}
        <section className="space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <SectionHeading icon={AlertTriangle} title="Cyberstalking & Severe Harassment" sub="Women face disproportionate targeting online" />

          <div className="grid gap-4 md:grid-cols-2">
            {/* Big stat callouts */}
            <div className="rounded-xl border border-border p-5 space-y-1 h-full">
              <p className="text-5xl font-light text-primary">72%</p>
              <p className="text-sm text-muted-foreground text-pretty">of online harassment victims are women, according to an 11-year analysis of cases</p>
              <div className="pt-3">
                <div className="h-2 w-full rounded-full bg-border overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: '72%', background: 'linear-gradient(90deg,#FF6B9D,#B794F6)' }} />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Women (72%)</span><span>Others (28%)</span>
                </div>
              </div>
            </div>

            <div className="space-y-3 h-full">
              <CompareBar
                labelA="Women" valueA={26} labelB="Men" valueB={7}
                title="Cyberstalking rate by gender"
                sub="Young women report being cyberstalked at nearly 4× the rate of young men" />
              <div className="rounded-xl border border-border p-4 flex items-start gap-3">
                <div className="shrink-0 mt-1 h-8 w-8 rounded-lg flex items-center justify-center bg-primary/8">
                  <TrendingUp className="h-4 w-4 text-primary" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">25× more threatening messages</p>
                  <p className="text-xs text-muted-foreground text-pretty mt-0.5">Female-identifying usernames receive threatening or sexually explicit messages 25 times more often than male usernames</p>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-border p-5 space-y-1">
            <p className="text-5xl font-light text-primary">70×</p>
            <p className="text-sm text-muted-foreground text-pretty">Female politicians are targeted by malicious AI deepfakes 70 times more often than male counterparts</p>
            <div className="pt-3 flex items-center gap-3">
              <div className="text-xs text-muted-foreground w-16 shrink-0">Women</div>
              <div className="flex-1 h-4 rounded-full bg-border overflow-hidden">
                <div className="h-full rounded-l-full" style={{ width: '97%', background: 'linear-gradient(90deg,#FF6B9D,#B794F6)' }} />
              </div>
              <div className="text-xs text-muted-foreground w-16 shrink-0">Men</div>
            </div>
          </div>
        </section>

        {/* Image-Based Sexual Abuse */}
        <section className="space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <SectionHeading icon={Shield} title="Image-Based Sexual Abuse" sub="Non-consensual sharing of intimate images" />

          <div className="grid gap-4 md:grid-cols-3">
            {[
              { stat: '90%', pct: 90, label: 'of image-based abuse targets are women' },
              { stat: '93%', pct: 93, label: 'of victims experience significant emotional distress' },
              { stat: '50%+', pct: 50, label: 'of victims lose five or more days of work as a result' },
            ].map(({ stat, pct, label }) => (
              <div key={stat} className="rounded-xl border border-border p-5 space-y-3 h-full flex flex-col">
                <p className="text-4xl font-light text-primary">{stat}</p>
                <p className="text-sm text-muted-foreground text-pretty flex-1">{label}</p>
                <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'linear-gradient(90deg,#FF6B9D,#B794F6)' }} />
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-border p-5 flex items-start gap-4">
            <div className="shrink-0 mt-0.5 h-9 w-9 rounded-xl flex items-center justify-center bg-primary/8">
              <TrendingUp className="h-4.5 w-4.5 text-primary" strokeWidth={1.5} />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-foreground">Intimate Partner Threats</p>
              <p className="text-sm text-muted-foreground text-pretty">
                Roughly 1 in 10 intimate partners threaten an ex with non-consensual sharing of sexual images, and <strong>60% of those who make the threat carry it out</strong>.
              </p>
            </div>
          </div>
        </section>

        {/* Dating Apps and Gaming */}
        <section className="space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <SectionHeading icon={Users} title="Dating Apps & Online Gaming" sub="Harassment in digital social spaces" />

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-xl border border-border p-5 space-y-3 h-full">
              <p className="text-4xl font-light text-primary">60%</p>
              <p className="text-sm text-muted-foreground text-pretty">of women under 35 on dating platforms report someone continued contacting them after they explicitly said they were not interested</p>
              <StatBar value={60} label="60%" sublabel="Persistent unwanted contact" />
            </div>
            <div className="rounded-xl border border-border p-5 space-y-3 h-full">
              <p className="text-4xl font-light text-primary">70%</p>
              <p className="text-sm text-muted-foreground text-pretty">of female gamers actively hide their gender online to avoid harassment, doxxing, and cyberbullying</p>
              <StatBar value={70} label="70%" sublabel="Hide gender to stay safe" />
            </div>
          </div>
        </section>

        {/* Overlap with Domestic Violence */}
        <section className="space-y-6 opacity-0 intersect:opacity-100 transition duration-700">
          <SectionHeading icon={Heart} title="The Overlap with Offline Domestic Violence" sub="Cybercrime as a tool for control and abuse" />

          <div className="rounded-xl border border-border p-5 space-y-1">
            <p className="text-sm text-muted-foreground text-pretty mb-4">
              Cybercrime against women is heavily intertwined with physical, real-world abuse. It is frequently used as a tool for abusers to maintain control.
            </p>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <StatBar value={85} label="85%" sublabel="Digital Spying — domestic violence shelters reporting GPS/spyware tracking" />
              </div>
              <div className="space-y-2">
                <StatBar value={75} label="75%" sublabel="Account Takeovers — abusers hacking or monitoring victim's accounts" />
              </div>
            </div>
          </div>
        </section>

        {/* Why girlGuard Exists */}
        <section className="space-y-4 opacity-0 intersect:opacity-100 transition duration-700">
          <div className="rounded-xl border border-primary/30 p-6 space-y-3">
            <h2 className="text-xl font-light tracking-tight text-balance">Why girlGuard Exists</h2>
            <p className="text-sm text-muted-foreground text-pretty">
              This website is an initiative for keeping girls of all ages cyber-safe when other resources are failing. We provide education, documentation tools, and support to help protect against these disproportionate threats.
            </p>
            <p className="text-xs text-muted-foreground text-pretty">
              <strong>Data Sources:</strong> Pew Research Center, United Nations Office on Drugs and Crime (UNODC), Women's Media Center, and various academic studies on online harassment and cybercrime.
            </p>
            <p className="text-xs text-muted-foreground text-pretty">
              girlGuard is ready to be recognized in school, city, state, and national newspapers as a vital resource for helping girls stay safe online.
            </p>
          </div>
        </section>

      </div>
    </PublicLayout>
  );
}

