import { useState, useEffect, useRef } from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  ShieldAlert, CreditCard, Bug, Lock, Eye, Wifi, Mail,
  AlertTriangle, CheckCircle, RotateCcw, ChevronRight, Phone,
} from 'lucide-react';

const G = {
  gradSoft: 'linear-gradient(135deg, rgba(255,107,157,0.12) 0%, rgba(183,148,246,0.12) 100%)',
  grad: 'linear-gradient(135deg, #FF6B9D 0%, #B794F6 100%)',
};

/* ── Animated stat bar ───────────────────────────────────────── */
function StatBar({ value, label }: { value: number; label: string }) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setTimeout(() => setWidth(value), 100); observer.disconnect(); } },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);
  return (
    <div className="space-y-1.5" ref={ref}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs text-muted-foreground text-pretty">{label}</span>
        <span className="text-xl font-light text-primary shrink-0">{value}%</span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
        <div className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${width}%`, background: G.grad }} />
      </div>
    </div>
  );
}

/* ── Threat data ──────────────────────────────────────────────── */
interface Threat {
  id: string;
  label: string;
  icon: React.ElementType;
  subtitle: string;
  what: string;
  howItTargetsGirls: string;
  warningSign: string[];
  prevent: string[];
  react: string[];
  reportTo: string;
}

const threats: Threat[] = [
  {
    id: 'identity',
    label: 'Identity Theft',
    icon: CreditCard,
    subtitle: 'Someone steals your personal information to impersonate you or open accounts in your name.',
    what: "Identity theft is when someone takes your name, date of birth, Social Security Number, or other personal details and uses them to open bank accounts, apply for credit cards, file tax returns, or commit crimes — all as you. Victims often don't discover it until months later when a debt collector calls or a credit check fails.",
    howItTargetsGirls: "Girls are frequently targeted through romantic scams, fake job/modelling offers requiring \"ID verification,\" scholarship application phishing, and social media quizzes that harvest answers to security questions (e.g. \"What street did you grow up on?\"). Young people with no credit history are especially valuable targets because their clean record goes undetected longer.",
    warningSign: [
      'Bills or credit card statements arriving for accounts you never opened',
      'Being denied credit for the first time with no explanation',
      'Unfamiliar charges on your bank statement, however small',
      'IRS notice saying someone already filed a tax return in your name',
      'Debt collectors calling about debts you don\'t recognise',
    ],
    prevent: [
      'Never give your Social Security Number, date of birth, or ID photos unless you\'re 100% certain of the recipient\'s legitimacy',
      'Freeze your credit with all three bureaus (Equifax, Experian, TransUnion) — it\'s free and prevents new accounts being opened',
      'Use unique, strong passwords and a password manager so a breach on one site doesn\'t expose others',
      'Enable two-factor authentication on every financial and email account',
      'Shred physical mail containing personal info before discarding',
      'Never complete social media quizzes that ask your pet\'s name, hometown, or mother\'s maiden name — these are security question answers',
      'Check your credit report for free at AnnualCreditReport.com — look for accounts you didn\'t open',
    ],
    react: [
      'File an identity theft report at IdentityTheft.gov (FTC) immediately — they generate a personalised recovery plan',
      'Call your bank and all affected financial institutions to freeze and dispute fraudulent transactions',
      'File a police report — many creditors require this as evidence',
      'Place a fraud alert or credit freeze at all three credit bureaus',
      'Document every fraudulent account, charge, and communication',
      'Contact the IRS at 1-800-908-4490 if your tax identity was stolen',
    ],
    reportTo: 'FTC: IdentityTheft.gov | IRS: 1-800-908-4490 | Your bank\'s fraud line | Local police',
  },
  {
    id: 'phishing',
    label: 'Phishing & Smishing',
    icon: Mail,
    subtitle: 'Fake messages designed to steal your passwords, banking details, or personal information.',
    what: "Phishing is when attackers send emails, texts (\"smishing\"), or social media DMs that look exactly like messages from trusted sources — your bank, PayPal, Amazon, school, or a popular brand. The goal is to get you to click a link and enter your credentials or financial information on a fake copy of the real site.",
    howItTargetsGirls: "Common lures include fake \"you've won a gift card\" messages, fake brand collaborations for influencers, fake scholarship or job notifications, \"your package couldn't be delivered\" texts, and fake \"friend in trouble\" messages on social media. Teen girls are heavily targeted through Instagram and TikTok DMs posing as brand managers.",
    warningSign: [
      'Unexpected message asking you to verify account details or \"confirm\" a transaction',
      'Urgency: \"Act within 24 hours or your account will be closed\"',
      'Link URL doesn\'t match the real company domain (e.g. paypa1.com instead of paypal.com)',
      'Generic greeting: \"Dear Customer\" instead of your actual name',
      'Request for passwords, credit card numbers, or SSN via email or text — legitimate companies never do this',
    ],
    prevent: [
      'Never click links in unsolicited emails or texts — go directly to the company website by typing the URL',
      'Hover over links before clicking to see the real destination URL',
      'Enable spam filters on your email',
      'Install a browser extension that warns about known phishing sites (e.g. Google Safe Browsing)',
      'When in doubt, call the company directly using the number on their official website',
      'Never enter passwords or financial details on a page you reached through an email link',
    ],
    react: [
      'Do NOT click any link or provide any information — close the message',
      'If you already clicked: change your password immediately on the real site, then check for unauthorised activity',
      'Report phishing emails to reportphishing@apwg.org and to the company being impersonated',
      'Forward phishing texts to 7726 (SPAM) — this reports it to your carrier',
      'File a complaint at the FTC\'s ReportFraud.ftc.gov',
      'If financial information was entered, contact your bank immediately to freeze the card',
    ],
    reportTo: 'FTC: ReportFraud.ftc.gov | Forward texts to 7726 | reportphishing@apwg.org',
  },
  {
    id: 'malware',
    label: 'Malware & Spyware',
    icon: Bug,
    subtitle: 'Malicious software that hides on your device to steal data, spy on you, or damage your system.',
    what: "Malware is any software designed to harm your device or steal data without your knowledge. This includes viruses (spread through files), trojans (disguised as legitimate apps), spyware (silently records your activity, keystrokes, or location), adware (floods you with unwanted ads), and stalkerware (a form of spyware installed by abusive partners to monitor your every move).",
    howItTargetsGirls: "Girls are targeted through fake free app downloads, cracked versions of paid apps, links in social media DMs, fake \"antivirus\" alerts that install the actual virus, and — critically — stalkerware installed by controlling partners or ex-partners without consent. Stalkerware reads texts, tracks GPS location, and records calls silently.",
    warningSign: [
      'Device runs significantly slower than normal',
      'Battery draining much faster than usual',
      'Data usage unexpectedly high — spyware sends data to attackers in the background',
      'Apps crashing frequently or unfamiliar apps appearing',
      'Ads appearing even when no browser is open',
      'Phone feels warm even when not in active use',
      'A controlling partner who \"always knows\" where you are or what you\'ve texted',
    ],
    prevent: [
      'Only install apps from official stores (App Store or Google Play) — avoid sideloading',
      'Never click pop-ups saying \"Your device is infected\" — these are scams',
      'Keep your operating system and apps updated — security patches close known vulnerabilities',
      'Don\'t connect to unfamiliar Wi-Fi networks without a VPN',
      'Read app permissions before installing — a flashlight app has no reason to access your contacts or microphone',
      'If a partner demands access to your device or says they need to "install something to keep you safe," this is a red flag',
    ],
    react: [
      'Run a reputable anti-malware scan immediately (Malwarebytes is free and effective)',
      'Disconnect from Wi-Fi and mobile data while scanning to prevent further data transmission',
      'If stalkerware is suspected from an abusive partner, contact a domestic violence hotline first (1-800-799-7233) before removing it — removal can sometimes trigger retaliation',
      'Factory reset your device as a last resort — back up photos first, but don\'t back up apps',
      'Change all passwords from a different, clean device after removing malware',
      'Contact your bank if financial apps were open during infection',
    ],
    reportTo: 'FTC: ReportFraud.ftc.gov | Domestic violence + stalkerware: 1-800-799-7233 | IC3: ic3.gov',
  },
  {
    id: 'ransomware',
    label: 'Ransomware',
    icon: Lock,
    subtitle: 'Malware that encrypts your files and demands payment to restore access.',
    what: "Ransomware locks you out of your own files — photos, documents, schoolwork — by encrypting them. The attacker then demands payment (usually cryptocurrency) for the decryption key. Even after paying, there\'s no guarantee files are restored. Backups are your only reliable defence.",
    howItTargetsGirls: "Ransomware often arrives through email attachments disguised as school documents, free download sites for music or assignments, pirated software, or malicious ads. A particularly cruel variant specifically targets photo libraries — knowing that personal photos are irreplaceable.",
    warningSign: [
      'Files suddenly have unfamiliar extensions (.locked, .encrypted, .crypt)',
      'A ransom note appears on screen or in affected folders',
      'You can\'t open files that were previously working',
      'Antivirus alerts about encryption activity',
    ],
    prevent: [
      'Back up files regularly to an external drive that is disconnected when not in use, or to cloud storage — ransomware can\'t encrypt files it can\'t reach',
      'Never open email attachments you weren\'t expecting, even from known contacts',
      'Keep all software updated — most ransomware exploits known, patched vulnerabilities',
      'Use an ad blocker — malicious ads are a common delivery method',
      'Disable macros in Microsoft Office documents by default',
    ],
    react: [
      'Disconnect from the internet and all networks immediately to contain the spread',
      'Do NOT pay the ransom — payment doesn\'t guarantee recovery and funds criminal operations',
      'Report to the FBI\'s Internet Crime Complaint Center at ic3.gov',
      'Check NoMoreRansom.org — free decryption tools exist for many ransomware variants',
      'Restore from your last clean backup if available',
      'Contact your school or workplace IT department if any shared drives were affected',
    ],
    reportTo: 'FBI IC3: ic3.gov | CISA: cisa.gov/ransomware | NoMoreRansom.org (free decryption tools)',
  },
  {
    id: 'creditcard',
    label: 'Credit Card & Financial Fraud',
    icon: CreditCard,
    subtitle: 'Unauthorized use of your payment information for purchases or account takeover.',
    what: "Financial fraud covers unauthorised use of your debit/credit card details, bank account takeovers, peer-to-peer payment scams (Venmo, Cash App, Zelle), and fake invoices. Unlike identity theft (which creates new accounts), financial fraud typically attacks existing accounts.",
    howItTargetsGirls: "Common methods include card skimmers on ATMs or gas pumps, fake online shops that collect payment but never deliver, romance scammers who ask for gift cards or money transfers, \"job offers\" requiring you to receive and forward payments (money mule scams), and fake emergency texts from \"friends\" asking for urgent Venmo transfers.",
    warningSign: [
      'Small unexplained charges (fraudsters often test with $1 micro-transactions before larger ones)',
      'Notifications for purchases you didn\'t make',
      'Being locked out of your bank account unexpectedly',
      'Friends or family saying they received payment requests from your account',
      'Card declined despite having funds',
    ],
    prevent: [
      'Check your bank statements weekly — set up instant purchase notifications via text/app',
      'Use virtual card numbers for online shopping (many banks offer this — the virtual number can\'t be used elsewhere)',
      'Cover the PIN pad at ATMs and petrol stations; check for skimmer devices on card slots',
      'Never pay for anything with gift cards — legitimate businesses and government agencies never ask for gift card payment',
      'Never forward money "on behalf of" someone who contacts you online — this is a money mule scam',
      'Use PayPal Goods & Services (not Friends & Family) for purchases from strangers — it has buyer protection',
    ],
    react: [
      'Call the fraud number on the back of your card immediately and dispute every unauthorised charge',
      'Request a new card number — your old number is compromised',
      'Change your online banking password and enable 2FA from a secure device',
      'File a complaint at ReportFraud.ftc.gov',
      'If a large sum was transferred, ask your bank about a recall — speed matters for wire transfers',
      'For P2P scams (Venmo, Cash App): contact the platform immediately as they may be able to reverse the transfer',
    ],
    reportTo: 'Your bank\'s fraud line (back of card) | FTC: ReportFraud.ftc.gov | IC3: ic3.gov for large-scale fraud',
  },
  {
    id: 'publicwifi',
    label: 'Public Wi-Fi & Network Attacks',
    icon: Wifi,
    subtitle: 'Attacks that intercept your data when you use unsecured wireless networks.',
    what: "On unsecured public Wi-Fi (cafés, malls, schools), an attacker on the same network can intercept unencrypted data you send and receive — passwords, messages, photos. \"Evil twin\" attacks involve setting up a fake hotspot with a legitimate-sounding name (\"Starbucks_Free\") to lure victims onto an attacker-controlled network.",
    howItTargetsGirls: "Public places frequented by young people — coffee shops, malls, libraries, school campuses — are prime hunting grounds. Attackers can also use public Wi-Fi to deliver malware through fake update prompts.",
    warningSign: [
      'Connection drops repeatedly then reconnects on its own',
      'Websites loading insecurely (HTTP instead of HTTPS, missing padlock)',
      'Unexpected certificate warnings on normally trusted sites',
      'Two Wi-Fi networks with very similar names at the same location',
    ],
    prevent: [
      'Use a VPN (Virtual Private Network) on any public Wi-Fi — it encrypts all traffic between your device and the internet',
      'Look for HTTPS (padlock icon) on every site before entering any information',
      'Avoid accessing banking or sensitive accounts on public networks',
      'Forget public networks after use so your device doesn\'t auto-reconnect',
      'Use your phone\'s mobile hotspot instead of public Wi-Fi when handling sensitive tasks',
      'Disable Wi-Fi and Bluetooth when not in use — they can be used to track your location',
    ],
    react: [
      'Disconnect from the network immediately if you suspect something is wrong',
      'Change passwords for any accounts accessed on the compromised network — from a secure connection',
      'Run a malware scan if you accepted any software update prompts while on the network',
      'Enable 2FA on any accounts you accessed',
      'Contact your bank if you conducted any financial transactions',
    ],
    reportTo: 'Report fake hotspots to the venue. File at FTC: ReportFraud.ftc.gov for targeted attacks.',
  },
  {
    id: 'stalking',
    label: 'Online Stalking & Doxxing',
    icon: Eye,
    subtitle: 'Tracking your real-world location and identity using publicly available online information.',
    what: "Doxxing is when someone researches and publicly publishes your private information — home address, school, workplace, phone number, family members\' details — with the intent to expose, harass, or enable physical harm. Online stalking involves someone obsessively monitoring your online activity, often combining information from multiple platforms to build a picture of your daily life and location.",
    howItTargetsGirls: "Girls who post content online — especially gamers, streamers, or social media creators — are disproportionately targeted. Metadata in photos can contain GPS coordinates; background details in photos/videos can reveal your location; usernames shared across platforms link your activities. Angry ex-partners and online harassment campaigns are the most common sources.",
    warningSign: [
      'Someone you don\'t know personally references specific details about your daily routine',
      'Showing up at places you only mentioned online',
      'Receiving deliveries you didn\'t order to your home address',
      'Strangers knowing your real name, school, or address',
      'Being tagged in posts that share your location or personal details without consent',
    ],
    prevent: [
      'Strip metadata from photos before posting — use a free metadata removal tool or check your phone\'s share settings',
      'Never show identifiable landmarks, school uniforms, or your street in photos',
      'Use different usernames across platforms to prevent cross-platform linking of your identity',
      'Set all social media profiles to private; review who can see your posts and location',
      'Disable location tagging on social media posts and stories',
      'Do a periodic "Google yourself" audit — search your full name, username, and phone number',
      'Opt out of data broker sites (Spokeo, WhitePages, BeenVerified) — they aggregate your address and family info',
    ],
    react: [
      'Document all instances with screenshots, dates, and usernames',
      'Report to the platform and request takedown of doxxing posts',
      'File a police report — online stalking is a crime in all 50 states',
      'Contact a cyberstalking legal clinic if harassment is ongoing (CyberCivilRights.org)',
      'Temporarily increase your privacy settings on all platforms',
      'If you believe you\'re in physical danger, call 911. If you need safety planning, call 1-800-799-7233',
    ],
    reportTo: 'Platform report tools | Local police | CyberCivilRights.org | 1-800-799-7233 if physical safety is at risk',
  },
];

/* ── Scenario-based quick guide ───────────────────────────────── */
const scenarios: Record<string, { label: string; threatId: string; context: string }> = {
  unknowncharge: {
    label: 'I see a charge on my card I didn\'t make',
    threatId: 'creditcard',
    context: 'Dispute the charge immediately — call the number on the back of your card. Do not wait to see if it reverses itself. Ask for a new card number. Then go to ReportFraud.ftc.gov.',
  },
  lockedfiles: {
    label: 'My files are encrypted and there\'s a ransom note',
    threatId: 'ransomware',
    context: 'Disconnect from Wi-Fi immediately. Do not pay. Check NoMoreRansom.org for a free decryption tool. Report to ic3.gov. Restore from backup if you have one.',
  },
  slowphone: {
    label: 'My phone is suddenly very slow and hot',
    threatId: 'malware',
    context: 'Install Malwarebytes (free) and run a full scan. Check app permissions for anything suspicious. If a controlling partner has had access to your device, call 1-800-799-7233 before removing anything.',
  },
  suspicioustext: {
    label: 'I got a text saying my package couldn\'t be delivered and to click a link',
    threatId: 'phishing',
    context: 'This is almost certainly a smishing attack. Do not click the link. Forward the text to 7726. If you already clicked and entered information, change your passwords immediately from a different device.',
  },
  addressleaked: {
    label: 'Someone online posted my home address',
    threatId: 'stalking',
    context: 'Report the post to the platform immediately using "shares private information." Screenshot it first. File a police report — in most states this constitutes criminal stalking/harassment. If you feel unsafe, call 911.',
  },
  jobscam: {
    label: 'A "modelling agency" asked for photos of my ID',
    threatId: 'identity',
    context: 'Stop immediately. Legitimate agencies do not request government ID photos via social media. This is a common identity theft setup. Do not send any documents. Report the account to the platform.',
  },
};

/* ── Section heading ──────────────────────────────────────────── */
function SectionHeading({ icon: Icon, title, sub }: { icon: React.ElementType; title: string; sub?: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
        <Icon className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
      </div>
      <div>
        <h2 className="text-xl font-light tracking-tight text-balance">{title}</h2>
        {sub && <p className="text-sm text-muted-foreground mt-0.5 text-pretty">{sub}</p>}
      </div>
    </div>
  );
}

/* ── Main page ────────────────────────────────────────────────── */
export default function DigitalThreatsPage() {
  const [scenario, setScenario] = useState('');
  const [activeThreat, setActiveThreat] = useState<string | null>(null);

  const selectedScenario = scenario ? scenarios[scenario] : null;
  const focusedThreat = activeThreat ? threats.find(t => t.id === activeThreat) : null;

  return (
    <div className="max-w-4xl mx-auto space-y-14 p-4 md:p-8">

      {/* Hero */}
      <div className="space-y-3">
        <p className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Digital Security</p>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight text-balance">
          Digital Threats & How to Fight Back
        </h1>
        <p className="text-base text-muted-foreground text-pretty">
          Identity theft, malware, ransomware, phishing, financial fraud, and stalking — what they are,
          how they specifically target girls, and exactly what to do before and after.
        </p>
      </div>

      {/* Disclaimer */}
      <div className="rounded-xl border border-primary/25 p-4 flex items-start gap-3">
        <AlertTriangle className="h-4 w-4 text-primary shrink-0 mt-0.5" strokeWidth={1.5} />
        <div className="space-y-0.5">
          <p className="text-sm font-medium text-foreground">Educational Information Only</p>
          <p className="text-sm text-muted-foreground text-pretty">
            This page provides general cybersecurity guidance for educational purposes. It does not
            constitute legal, financial, or professional advice. If you are in immediate danger or
            experiencing active financial fraud, contact your bank or emergency services without delay.
          </p>
        </div>
      </div>

      {/* Stats */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={ShieldAlert} title="The Scale of Digital Threats"
          sub="Young women are disproportionately affected by online financial and security crimes" />
        <div className="rounded-xl border border-border p-5 space-y-5">
          <StatBar value={43} label="of identity theft victims in the U.S. are under age 30" />
          <StatBar value={70} label="of teenagers who received phishing messages clicked the link (Stanford study)" />
          <StatBar value={54} label="of people who paid ransomware demands did not get their files back" />
          <StatBar value={66} label="of stalkerware victims identified their abuser as a current or former intimate partner" />
          <StatBar value={31} label="of young adults experienced financial fraud in the past year (FTC)" />
        </div>
      </section>

      {/* Quick scenario guide */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={AlertTriangle} title="What's Happening Right Now?"
          sub="Select your situation for immediate, specific steps" />
        <Select value={scenario} onValueChange={setScenario}>
          <SelectTrigger className="w-full max-w-md h-11 text-sm">
            <SelectValue placeholder="Select what's happening…" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(scenarios).map(([key, val]) => (
              <SelectItem key={key} value={key}>{val.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedScenario && (
          <div className="rounded-xl border border-destructive/25 bg-destructive/5 p-5 space-y-3 animate-fade-in">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-destructive shrink-0" />
              <p className="text-sm font-semibold text-foreground">{selectedScenario.label}</p>
            </div>
            <p className="text-sm text-muted-foreground text-pretty leading-relaxed">{selectedScenario.context}</p>
            <button
              onClick={() => setActiveThreat(selectedScenario.threatId)}
              className="flex items-center gap-1.5 text-xs text-primary hover:underline underline-offset-4 transition-colors">
              <ChevronRight className="h-3.5 w-3.5" strokeWidth={2} />
              Read the full guide for this threat
            </button>
          </div>
        )}
      </section>

      {/* Deep-dive: individual threat explorer */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={ShieldAlert} title="Threat Guides"
          sub="Tap any threat to learn what it is, how it targets you, and what to do" />

        {/* Threat selector buttons */}
        <div className="flex flex-wrap gap-2">
          {threats.map(({ id, label, icon: Icon }) => (
            <button key={id}
              onClick={() => setActiveThreat(prev => prev === id ? null : id)}
              className={[
                'flex items-center gap-2 px-3 py-2 rounded-lg text-sm border transition-all duration-200',
                activeThreat === id
                  ? 'border-primary/40 bg-primary/8 text-primary font-medium'
                  : 'border-border text-muted-foreground hover:text-foreground hover:border-border/80',
              ].join(' ')}>
              <Icon className="h-3.5 w-3.5 shrink-0" strokeWidth={activeThreat === id ? 2 : 1.75} />
              {label}
            </button>
          ))}
        </div>

        {/* Expanded detail panel */}
        {focusedThreat && (
          <div className="rounded-xl border border-border p-5 md:p-6 space-y-6 animate-fade-in">
            {/* Header */}
            <div className="flex items-start gap-3">
              <div className="h-9 w-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: G.gradSoft }}>
                <focusedThreat.icon className="h-4.5 w-4.5 text-primary" strokeWidth={1.75} />
              </div>
              <div>
                <h3 className="text-lg font-medium text-foreground">{focusedThreat.label}</h3>
                <p className="text-sm text-muted-foreground text-pretty mt-0.5">{focusedThreat.subtitle}</p>
              </div>
              <button onClick={() => setActiveThreat(null)}
                className="ml-auto shrink-0 p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                <RotateCcw className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            </div>

            <Accordion type="multiple" className="space-y-2" defaultValue={['what', 'prevent', 'react']}>

              {/* What it is */}
              <AccordionItem value="what" className="rounded-xl border border-border overflow-hidden px-0">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors text-sm font-medium">
                  What is it?
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0">
                  <p className="text-sm text-muted-foreground text-pretty leading-relaxed">{focusedThreat.what}</p>
                </AccordionContent>
              </AccordionItem>

              {/* How it targets girls */}
              <AccordionItem value="targets" className="rounded-xl border border-amber-500/25 overflow-hidden px-0">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors text-sm font-medium">
                  How it specifically targets girls
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0">
                  <p className="text-sm text-muted-foreground text-pretty leading-relaxed">{focusedThreat.howItTargetsGirls}</p>
                </AccordionContent>
              </AccordionItem>

              {/* Warning signs */}
              <AccordionItem value="signs" className="rounded-xl border border-border overflow-hidden px-0">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors text-sm font-medium">
                  Warning signs
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0">
                  <div className="space-y-2">
                    {focusedThreat.warningSign.map((sign, i) => (
                      <div key={i} className="flex items-start gap-2.5">
                        <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" strokeWidth={1.75} />
                        <p className="text-sm text-muted-foreground text-pretty">{sign}</p>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Prevention */}
              <AccordionItem value="prevent" className="rounded-xl border border-green-500/25 overflow-hidden px-0">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors text-sm font-medium text-left">
                  <span>Preventive measures <span className="text-green-600 dark:text-green-400 font-normal text-xs ml-1.5">(do these now, before anything happens)</span></span>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0">
                  <div className="space-y-2">
                    {focusedThreat.prevent.map((step, i) => (
                      <div key={i} className="flex items-start gap-3">
                        <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0 mt-0.5"
                          style={{ background: G.grad }}>{i + 1}</div>
                        <p className="text-sm text-muted-foreground text-pretty">{step}</p>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Reactive measures */}
              <AccordionItem value="react" className="rounded-xl border border-destructive/25 overflow-hidden px-0">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors text-sm font-medium text-left">
                  <span>Reactive measures <span className="text-destructive font-normal text-xs ml-1.5">(if it's already happened)</span></span>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0">
                  <div className="space-y-2">
                    {focusedThreat.react.map((step, i) => (
                      <div key={i} className="flex items-start gap-3">
                        <div className="h-5 w-5 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0 mt-0.5"
                          style={{ background: 'hsl(var(--destructive))' }}>{i + 1}</div>
                        <p className="text-sm text-muted-foreground text-pretty">{step}</p>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Report to */}
              <AccordionItem value="report" className="rounded-xl border border-primary/25 overflow-hidden px-0">
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/40 transition-colors text-sm font-medium">
                  Who to report to
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0">
                  <div className="flex items-start gap-2.5">
                    <Phone className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" strokeWidth={1.75} />
                    <p className="text-sm text-muted-foreground text-pretty">{focusedThreat.reportTo}</p>
                  </div>
                </AccordionContent>
              </AccordionItem>

            </Accordion>
          </div>
        )}
      </section>

      {/* Universal prevention checklist */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={CheckCircle} title="Your Digital Security Baseline"
          sub="The 10 habits that prevent the majority of digital threats" />
        <div className="rounded-xl border border-border p-5 space-y-3">
          {[
            { num: 1,  tip: 'Use a password manager and unique passwords for every account — a single reused password is a master key.' },
            { num: 2,  tip: 'Enable two-factor authentication (2FA) on your email, bank, and social media — this blocks ~99.9% of automated account attacks.' },
            { num: 3,  tip: 'Freeze your credit at all three bureaus now — it\'s free and prevents new accounts being opened in your name without your knowledge.' },
            { num: 4,  tip: 'Back up your phone and laptop weekly to an external drive that stays disconnected — your only protection against ransomware.' },
            { num: 5,  tip: 'Never click links in unsolicited texts or emails — always go directly to the company\'s website by typing the address.' },
            { num: 6,  tip: 'Keep your operating system and apps updated — most successful attacks exploit vulnerabilities that were patched months ago.' },
            { num: 7,  tip: 'Use a VPN on any public Wi-Fi — coffee shops, malls, and school networks are hunting grounds for attackers.' },
            { num: 8,  tip: 'Strip photo metadata before posting location-sensitive images — your camera encodes GPS coordinates in every photo.' },
            { num: 9,  tip: 'Set a 7-digit PIN on your SIM card through your carrier — prevents SIM-swap attacks that bypass 2FA entirely.' },
            { num: 10, tip: 'Google your name, phone number, and username periodically — opt out of data broker results that surface your address.' },
          ].map(({ num, tip }) => (
            <div key={num} className="flex items-start gap-3">
              <div className="h-6 w-6 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0 mt-0.5"
                style={{ background: G.grad }}>{num}</div>
              <p className="text-sm text-muted-foreground text-pretty">{tip}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Key contacts */}
      <section className="space-y-5 opacity-0 intersect:opacity-100 transition duration-700">
        <SectionHeading icon={Phone} title="Key Reporting Contacts"
          sub="Bookmark these — speed matters when fraud or a breach occurs" />
        <div className="grid gap-3 md:grid-cols-2">
          {[
            { title: 'FTC Identity Theft / Fraud', contact: 'IdentityTheft.gov | ReportFraud.ftc.gov', detail: 'Generates a personalised recovery plan for identity theft; accepts all fraud reports' },
            { title: 'FBI Internet Crime Complaint Center', contact: 'ic3.gov', detail: 'For ransomware, financial fraud, sextortion, and serious cybercrimes crossing state lines' },
            { title: 'CISA (Cybersecurity & Infrastructure Security Agency)', contact: 'cisa.gov/report', detail: 'Reports of ransomware and major cybersecurity incidents' },
            { title: 'National Domestic Violence Hotline', contact: '1-800-799-7233', detail: 'For stalkerware, digital surveillance by partners, and technology-facilitated abuse' },
            { title: 'Cyber Civil Rights Initiative', contact: 'cybercivilrights.org', detail: 'Doxxing, image-based abuse, online stalking — free legal referrals' },
            { title: 'NoMoreRansom.org', contact: 'nomoreransom.org', detail: 'Free decryption tools for many ransomware variants — check here before despairing' },
          ].map(({ title, contact, detail }) => (
            <div key={title} className="rounded-xl border border-border p-4 space-y-1.5 h-full">
              <p className="text-sm font-medium text-foreground">{title}</p>
              <p className="text-xs font-mono text-primary">{contact}</p>
              <p className="text-xs text-muted-foreground text-pretty">{detail}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
