import AppLayout from'@/components/layouts/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from'@/components/ui/card';
import { BarChart3, FolderOpen, Heart, LifeBuoy, Scale, BookOpen } from'lucide-react';

export default function GuidePage() {
  const sections = [
    {
      icon: BarChart3,
      title:'Prevention & Stats',
      description:'Learn what online abuse looks like and how to recognize warning signs',
      items: [
'Real statistics about online abuse targeting teen girls',
'Recognize grooming, manipulation, and red flags',
'Understand healthy vs unhealthy online relationships',
'Learn about your legal rights and protections',
      ],
    },
    {
      icon: FolderOpen,
      title:'Documentation',
      description:'Collect evidence, track incidents, and generate reports',
      items: [
'Evidence: Upload screenshots with cryptographic verification',
'Timeline: Log every incident with dates, times, and platforms',
'Impact: Record emotional and social effects',
'Report: Generate professional summaries for authorities',
      ],
    },
    {
      icon: Heart,
      title:'Social & Emotional Impact',
      description:'Understand and heal from the emotional toll',
      items: [
'Learn about normal emotional responses to abuse',
'Access coping strategies and self-care practices',
'Find crisis hotlines and mental health resources',
'Understand when to seek professional help',
      ],
    },
    {
      icon: LifeBuoy,
      title:'Action & Healing',
      description:'Get practical steps and resources for moving forward',
      items: [
'Learn what to do right now to stay safe',
'Find crisis hotlines and support services',
'Understand your options for reporting',
'Access resources for healing and recovery',
      ],
    },
    {
      icon: Scale,
      title:'Cybersecurity Laws',
      description:'Find laws in your area and understand your legal rights',
      items: [
'Search for federal and state cybersecurity laws',
'Learn about laws protecting you from online abuse',
'Understand your rights as a victim',
'Access official legal resources and links',
'Find legal aid organizations that help teens',
      ],
    },
  ];

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="space-y-4 animate-slide-up">
          <h1 className="text-4xl md:text-5xl font-light tracking-tight gradient-text text-center">How to Use girlGuard</h1>
          <p className="text-lg text-muted-foreground text-center max-w-3xl mx-auto">
            This tool was created specifically for teenage girls to help you understand, document, and respond to online abuse. 
            Everything is explained in clear language, and you don't need any technical skills.
          </p>
        </div>

        <Card className="bg-gradient-accent border-none shadow-xl animate-scale-in">
          <CardContent className="p-8 space-y-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-white/80 flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-primary" />
              </div>
              <p className="text-base font-medium text-foreground">Why Documentation Matters:</p>
            </div>
            <ul className="text-sm text-foreground/80 space-y-3 pl-4">
              {[
'Screenshots alone can be dismissed as "edited" or "fake"',
'A clear timeline shows patterns that single incidents might not reveal',
'Authorities and schools take documented evidence more seriously',
'You might forget details over time - writing them down preserves accuracy',
'Having everything organized reduces stress when you need to report',
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-white/80 flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-primary">{index + 1}</span>
                  </div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <h2 className="text-3xl font-light text-center gradient-text">Your Toolkit</h2>
          <div className="space-y-6">
            {sections.map((section, index) => {
              const Icon = section.icon;
              return (
                <Card key={index} className="card-hover border-2 hover:border-primary/50 animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
                  <CardHeader>
                    <div className="flex items-start gap-4">
                      <div className="h-14 w-14 rounded-xl bg-gradient-primary flex items-center justify-center shrink-0 shadow-lg">
                        <Icon className="h-7 w-7 text-white" />
                      </div>
                      <div className="space-y-2 flex-1">
                        <CardTitle className="text-2xl font-light">{section.title}</CardTitle>
                        <CardDescription className="text-base">{section.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {section.items.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3">
                          <div className="h-6 w-6 rounded-full bg-gradient-accent flex items-center justify-center shrink-0 mt-0.5">
                            <span className="text-xs font-medium text-foreground">{itemIndex + 1}</span>
                          </div>
                          <span className="text-sm text-muted-foreground leading-relaxed">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        <Card className="bg-gradient-primary text-white border-none shadow-xl animate-scale-in">
          <CardContent className="p-8 text-center space-y-4">
            <h2 className="text-2xl font-light">Your Privacy is Protected</h2>
            <div className="grid md:grid-cols-2 gap-4 text-left">
              {[
'All your documentation is stored locally on your device only',
'Nothing is uploaded to external servers',
'Only you can access your information with your passcode',
'You control who sees your documentation and when',
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-white/20 flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-white">{index + 1}</span>
                  </div>
                  <span className="text-sm text-white/90">{item}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
