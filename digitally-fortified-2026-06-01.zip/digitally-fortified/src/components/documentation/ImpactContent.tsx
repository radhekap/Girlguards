import { useState, useEffect } from'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from'@/components/ui/card';
import { Label } from'@/components/ui/label';
import { Textarea } from'@/components/ui/textarea';
import { storage } from'@/lib/storage';
import type { ImpactData } from'@/types/types';
import { useDebounce } from'@/hooks/use-debounce';

export default function ImpactContent() {
  const [impact, setImpact] = useState<ImpactData>(() => storage.getImpact());
  const debouncedImpact = useDebounce(impact, 500);

  useEffect(() => {
    storage.setImpact(debouncedImpact);
  }, [debouncedImpact]);

  const handleChange = (field: keyof ImpactData, value: string) => {
    setImpact(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-2xl font-light">Impact Journal</h2>
        <p className="text-muted-foreground">
          Document how this has affected your emotional well-being and daily life.
        </p>
      </div>

      <Card className="card-hover">
        <CardHeader>
          <CardTitle className="text-xl font-light">Reports Filed</CardTitle>
          <CardDescription>
            Log any reports you've made to platforms, authorities, or schools
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="reportsFiled">Reports & Reference Numbers</Label>
            <Textarea
              id="reportsFiled"
              placeholder="e.g., Reported to Instagram on 1/15/2024, ticket #12345..."
              value={impact.reportsFiled}
              onChange={(e) => handleChange('reportsFiled', e.target.value)}
              rows={6}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Auto-saves as you type. Include dates, platform names, and any reference numbers.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="card-hover">
        <CardHeader>
          <CardTitle className="text-xl font-light">Emotional & Social Impact</CardTitle>
          <CardDescription>
            Record how this has affected your feelings, relationships, school, and daily life
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="impactJournal">Impact Journal</Label>
            <Textarea
              id="impactJournal"
              placeholder="Describe how this has affected you emotionally, socially, at school, sleep patterns, anxiety levels, relationships with friends/family..."
              value={impact.impactJournal}
              onChange={(e) => handleChange('impactJournal', e.target.value)}
              rows={12}
            />
            <p className="text-xs text-muted-foreground">
              Auto-saves as you type. Be as detailed as possible - this is important evidence.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
