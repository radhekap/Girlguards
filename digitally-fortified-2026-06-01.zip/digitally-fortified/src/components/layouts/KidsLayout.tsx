import { ReactNode, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Home, Shield, Frown, HeartHandshake, BookOpen,
  ArrowLeft, Star, Gamepad2, Menu, X,
  ChevronLeft, ChevronRight,
} from 'lucide-react';

interface KidsLayoutProps {
  children: ReactNode;
}

// Brand palette + design tokens — single source of truth for all kidsGuard pages
export const K = {
  // Brand colours
  teal:         '#5BC8C4',
  blue:         '#4A7FC1',
  green:        '#5BCB8A',
  yellow:       '#F5D74E',
  pink:         '#E8416E',
  // Page & layout
  bg:           '#F6FDFC',
  text:         '#1E3A4A',
  muted:        '#5A7A8A',
  // Component tokens (replaces all hardcoded whites / grays)
  surface:      '#FFFFFF',        // card / panel interior background
  panel:        '#F0FAFA',        // subtle tinted section background
  border:       '#DCF0EE',        // default border
  inputBg:      '#F8FFFE',        // input / textarea background
  quizBtn:      '#F2FAFA',        // unselected quiz / option button background
  quizBtnBorder:'#C8E8E6',        // unselected quiz / option button border
};

const navItems = [
  { path: '/kids',             label: 'Home',          icon: Home,           color: K.yellow },
  { path: '/kids/safe-online', label: 'Stay Safe',     icon: Shield,         color: K.teal   },
  { path: '/kids/bullying',    label: 'Bullying',      icon: Frown,          color: K.pink   },
  { path: '/kids/feelings',    label: 'Feelings',      icon: HeartHandshake, color: K.green  },
  { path: '/kids/help',        label: 'Ask for Help',  icon: Star,           color: K.yellow },
  { path: '/kids/resources',   label: 'Resources',     icon: BookOpen,       color: K.blue   },
  { path: '/kids/games',       label: 'Games',         icon: Gamepad2,       color: K.pink   },
];

/* ── Shared values ───────────────────────────────────────────────────────── */
const SIDEBAR_EXPANDED = 232;
const SIDEBAR_COLLAPSED = 64;

export default function KidsLayout({ children }: KidsLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const isActive = (path: string) =>
    path === '/kids' ? location.pathname === '/kids' : location.pathname.startsWith(path);

  const go = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        .kids-font { font-family: 'Nunito', system-ui, sans-serif; }
        .kids-btn-bounce:hover  { transform: scale(1.04) translateY(-1px); }
        .kids-btn-bounce:active { transform: scale(0.97); }
        .kids-nav-item { transition: background 0.15s, color 0.15s, transform 0.12s; }
        .kids-nav-item:hover { transform: translateX(2px); }
        .kids-sidebar-transition { transition: width 0.22s cubic-bezier(0.4,0,0.2,1); overflow: hidden; }
      `}</style>

      <div
        className="kids-font min-h-screen flex flex-col md:flex-row"
        style={{ background: `linear-gradient(160deg, #EBF9F8 0%, #EEF5FF 55%, #F2FFF6 100%)` }}>

        {/* ══ DESKTOP SIDEBAR ══════════════════════════════════════════════ */}
        <aside
          className="kids-sidebar-transition hidden md:flex flex-col shrink-0 sticky top-0 h-screen"
          style={{
            width: sidebarCollapsed ? SIDEBAR_COLLAPSED : SIDEBAR_EXPANDED,
            background: K.surface,
            borderRight: `1px solid ${K.border}`,
          }}>

          {/* Brand header */}
          <div
            className="flex items-center shrink-0 px-3"
            style={{
              height: 60,
              borderBottom: `1px solid ${K.border}`,
              justifyContent: sidebarCollapsed ? 'center' : 'space-between',
            }}>
            <button
              onClick={() => go('/kids')}
              className="flex items-center gap-2.5 kids-btn-bounce shrink-0 min-w-0">
              <div
                className="h-8 w-8 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: `linear-gradient(135deg, ${K.blue} 0%, ${K.teal} 100%)` }}>
                <Shield style={{ width: 16, height: 16, color: K.surface }} strokeWidth={2.5} />
              </div>
              {!sidebarCollapsed && (
                <span className="font-black text-sm truncate" style={{ color: K.teal }}>kidsGuard</span>
              )}
            </button>
            {!sidebarCollapsed && (
              <button
                onClick={() => setSidebarCollapsed(true)}
                aria-label="Collapse sidebar"
                style={{ color: K.muted }}
                className="p-1 rounded-lg hover:bg-gray-100 transition-colors shrink-0">
                <ChevronLeft style={{ width: 16, height: 16 }} />
              </button>
            )}
          </div>

          {/* Nav links */}
          <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-0.5">
            {navItems.map(({ path, label, icon: Icon, color }) => {
              const active = isActive(path);
              return (
                <button
                  key={path}
                  onClick={() => go(path)}
                  title={sidebarCollapsed ? label : undefined}
                  className="kids-nav-item w-full flex items-center rounded-xl text-sm text-left relative"
                  style={{
                    gap: sidebarCollapsed ? 0 : 10,
                    padding: sidebarCollapsed ? '10px 0' : '9px 10px',
                    justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
                    backgroundColor: active ? color + '18' : 'transparent',
                    color: active ? K.text : K.muted,
                    fontWeight: active ? 800 : 600,
                    borderLeft: active && !sidebarCollapsed ? `3px solid ${color}` : '3px solid transparent',
                  }}>
                  <div
                    className="shrink-0 h-7 w-7 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: active ? color : color + '16' }}>
                    <Icon
                      style={{
                        width: 15, height: 15,
                        color: active ? (color === K.yellow ? K.text : K.surface) : color,
                      }}
                      strokeWidth={2.5}
                    />
                  </div>
                  {!sidebarCollapsed && <span className="truncate">{label}</span>}
                </button>
              );
            })}
          </nav>

          {/* Footer: back to girlGuard + expand when collapsed */}
          <div
            className="shrink-0 px-2 pb-4 pt-2 space-y-1.5"
            style={{ borderTop: `1px solid ${K.border}` }}>
            {sidebarCollapsed ? (
              <>
                <button
                  onClick={() => navigate('/public/info')}
                  title="Back to girlGuard"
                  className="kids-nav-item w-full flex items-center justify-center py-2 rounded-xl"
                  style={{ color: K.blue, backgroundColor: K.blue + '12' }}>
                  <ArrowLeft style={{ width: 15, height: 15 }} />
                </button>
                <button
                  onClick={() => setSidebarCollapsed(false)}
                  aria-label="Expand sidebar"
                  className="w-full flex items-center justify-center py-2 rounded-xl"
                  style={{ color: K.muted, backgroundColor: K.teal + '12' }}>
                  <ChevronRight style={{ width: 15, height: 15 }} />
                </button>
              </>
            ) : (
              <button
                onClick={() => navigate('/public/info')}
                className="kids-nav-item w-full flex items-center gap-2 px-3 py-2 rounded-xl font-bold text-xs"
                style={{ color: K.blue, backgroundColor: K.blue + '10', border: `1px solid ${K.blue}22` }}>
                <ArrowLeft style={{ width: 13, height: 13, flexShrink: 0 }} />
                <span className="truncate">Back to girlGuard</span>
              </button>
            )}
          </div>
        </aside>

        {/* ══ RIGHT COLUMN ════════════════════════════════════════════════ */}
        <div className="flex flex-col flex-1 min-w-0">

          {/* ── MOBILE HEADER ─────────────────────────────────────────── */}
          <header
            className="md:hidden sticky top-0 z-40"
            style={{
              backgroundColor: K.surface,
              borderBottom: `2px solid ${K.teal}`,
            }}>
            <div className="px-4 h-14 flex items-center justify-between gap-3">
              <button onClick={() => go('/kids')} className="flex items-center gap-2 kids-btn-bounce shrink-0">
                <div
                  className="h-8 w-8 rounded-xl flex items-center justify-center"
                  style={{ background: `linear-gradient(135deg, ${K.blue} 0%, ${K.teal} 100%)` }}>
                  <Shield style={{ width: 15, height: 15, color: K.surface }} strokeWidth={2.5} />
                </div>
                <span className="font-black text-sm" style={{ color: K.teal }}>kidsGuard</span>
              </button>

              <div className="flex items-center gap-2 ml-auto">
                <button
                  onClick={() => navigate('/public/info')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-black text-xs kids-btn-bounce"
                  style={{ color: K.blue, backgroundColor: K.blue + '12', border: `1px solid ${K.blue}22` }}>
                  <ArrowLeft style={{ width: 12, height: 12 }} />
                  <span className="hidden sm:inline">girlGuard</span>
                </button>
                <button
                  onClick={() => setMobileMenuOpen(o => !o)}
                  className="h-9 w-9 flex items-center justify-center rounded-xl"
                  style={{ backgroundColor: mobileMenuOpen ? K.teal + '18' : 'transparent' }}
                  aria-label="Toggle navigation">
                  {mobileMenuOpen
                    ? <X style={{ width: 18, height: 18, color: K.teal }} />
                    : <Menu style={{ width: 18, height: 18, color: K.muted }} />}
                </button>
              </div>
            </div>

            {/* Mobile slide-down nav */}
            {mobileMenuOpen && (
              <div style={{ borderTop: `1px solid ${K.border}`, backgroundColor: K.panel }}>
                <div className="px-4 py-3 grid grid-cols-2 gap-2">
                  {navItems.map(({ path, label, icon: Icon, color }) => {
                    const active = isActive(path);
                    return (
                      <button
                        key={path}
                        onClick={() => go(path)}
                        className="flex items-center gap-2.5 px-3 py-3 rounded-2xl font-black text-sm text-left kids-btn-bounce"
                        style={{
                          backgroundColor: active ? color : color + '14',
                          color: active ? (color === K.yellow ? K.text : K.surface) : K.text,
                          border: `1px solid ${active ? color : color + '33'}`,
                        }}>
                        <Icon
                          style={{ width: 15, height: 15, flexShrink: 0, color: active ? (color === K.yellow ? K.text : K.surface) : color }}
                          strokeWidth={2.5}
                        />
                        <span>{label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </header>

          {/* ── DESKTOP HEADER BAR ────────────────────────────────────── */}
          <header
            className="hidden md:flex items-center px-6 h-12 shrink-0"
            style={{
              backgroundColor: K.surface,
              borderBottom: `1px solid ${K.border}`,
            }}>
            {(() => {
              const cur = navItems.find(n => isActive(n.path));
              return cur ? (
                <div
                  className="flex items-center gap-2 px-2.5 py-1 rounded-lg font-bold text-xs"
                  style={{ backgroundColor: cur.color + '14', color: K.text }}>
                  <cur.icon style={{ width: 13, height: 13, color: cur.color }} strokeWidth={2.5} />
                  {cur.label}
                </div>
              ) : null;
            })()}
            <div className="ml-auto text-xs font-semibold" style={{ color: K.muted }}>
              Stay safe · Be brave · Have fun 💛
            </div>
          </header>

          {/* ── MAIN ──────────────────────────────────────────────────── */}
          <main className="flex-1 w-full px-4 md:px-6 lg:px-8 py-8 md:py-10">
            {children}
          </main>

          {/* ── FOOTER ────────────────────────────────────────────────── */}
          <footer
            className="py-5 text-center"
            style={{ color: K.muted, backgroundColor: K.surface, borderTop: `1px solid ${K.border}` }}>
            <div className="flex items-center justify-center gap-2 mb-1">
              <div
                className="h-5 w-5 rounded-lg flex items-center justify-center"
                style={{ background: `linear-gradient(135deg, ${K.blue} 0%, ${K.teal} 100%)` }}>
                <Shield style={{ width: 11, height: 11, color: K.surface }} strokeWidth={2.5} />
              </div>
              <p className="font-black text-sm" style={{ color: K.teal }}>kidsGuard</p>
            </div>
            <p className="text-xs font-semibold">A safe, friendly space — stay safe, be brave, have fun 💛</p>
            <p className="text-xs mt-0.5" style={{ color: K.muted + '99' }}>Part of the girlGuard educational platform · Free · Private · No login needed</p>
          </footer>
        </div>
      </div>
    </>
  );
}
