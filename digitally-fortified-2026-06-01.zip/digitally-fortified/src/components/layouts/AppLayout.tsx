import { ReactNode, useState } from'react';
import { useNavigate, useLocation } from'react-router-dom';
import { useAuth } from'@/contexts/AuthContext';
import { Button } from'@/components/ui/button';
import { Alert, AlertDescription } from'@/components/ui/alert';
import ThemeSwitcher from'@/components/common/ThemeSwitcher';
import AccessibilitySettings from'@/components/AccessibilitySettings';
import { Lock, BookOpen, Shield, FolderOpen, Heart, LifeBuoy, Scale, AlertTriangle, TrendingDown, ShieldAlert, Download, Loader2 } from'lucide-react';
import { downloadAllCode } from'@/lib/downloadCode';
import { toast } from'sonner';

interface AppLayoutProps {
  children: ReactNode;
}

const navItems = [
  { path:'/guide', label:'Guide', icon: BookOpen },
  { path:'/prevention', label:'Prevention & Stats', icon: Shield },
  { path:'/bullying', label:'Online Bullying', icon: AlertTriangle },
  { path:'/digital-threats', label:'Digital Threats', icon: ShieldAlert },
  { path:'/comparison', label:'Social Comparison', icon: TrendingDown },
  { path:'/documentation', label:'Documentation', icon: FolderOpen },
  { path:'/social-emotional', label:'Social & Emotional', icon: Heart },
  { path:'/action', label:'Action & Healing', icon: LifeBuoy },
  { path:'/laws', label:'Laws', icon: Scale },
];

export default function AppLayout({ children }: AppLayoutProps) {
  const { userName, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [downloading, setDownloading] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadAllCode();
      toast.success('Source code downloaded — ready for GitHub!');
    } catch (err) {
      console.error('Download failed:', err);
      toast.error('Download failed. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col bg-background transition-theme">
      {/* Warning Banner */}
      <Alert className="rounded-none border-x-0 border-t-0 text-primary-foreground border-none bg-primary">
        <AlertDescription className="text-center text-sm font-medium">
          <strong>Important:</strong> This tool is for documentation and education, NOT legal or medical advice. 
          Please talk to trusted adults, professionals, or authorities for guidance.
        </AlertDescription>
      </Alert>

      {/* Top Bar */}
      <div className="border-b border-border bg-card transition-theme">
        <div className="container mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg flex items-center justify-center bg-primary shrink-0">
              <Shield className="h-5 w-5 text-primary-foreground" strokeWidth={2} />
            </div>
            <div>
              <span className="font-semibold gradient-text">girlGuard</span>
              <p className="text-xs text-muted-foreground">{userName}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <AccessibilitySettings />
            <ThemeSwitcher />
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
              disabled={downloading}
              className="gap-2 border-border hover:bg-muted hover:text-foreground"
              title="Download all source code as ZIP"
            >
              {downloading
                ? <Loader2 className="h-4 w-4 animate-spin" />
                : <Download className="h-4 w-4" />}
              <span className="hidden md:inline">{downloading ? 'Packing…' : 'Download Code'}</span>
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout} className="gap-2 border-border hover:bg-muted hover:text-foreground">
              <Lock className="h-4 w-4" />
              <span className="hidden md:inline">Lock</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="border-b border-border bg-card overflow-x-auto transition-theme">
        <div className="container mx-auto px-4 md:px-8">
          <nav className="flex gap-1 min-w-max py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Button
                  key={item.path}
                  variant={isActive ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => navigate(item.path)}
                  className={`gap-2 whitespace-nowrap h-9 transition-colors ${
                    isActive
                      ? 'bg-muted text-foreground font-medium'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'
                  }`}
                >
                  <Icon className={['h-4 w-4', isActive ? 'text-primary' : ''].join(' ')} />
                  <span className="hidden md:inline">{item.label}</span>
                  <span className="md:hidden">{item.label.split('')[0]}</span>
                </Button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="container mx-auto px-4 md:px-8 py-8 md:py-12 animate-fade-in">
          {children}
        </div>
        {/* Footer */}
        <footer className="border-t border-border">
          <div className="container mx-auto px-4 md:px-8 py-4 space-y-2">
            <p className="text-xs text-muted-foreground text-pretty leading-relaxed">
              <strong className="text-foreground/70">Educational &amp; documentation tool only.</strong>{' '}
              Nothing on girlGuard constitutes legal, medical, or professional advice.
            </p>
            <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
              <p className="text-[11px] text-muted-foreground/70">
                © {new Date().getFullYear()} girlGuard — independent student project
              </p>
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                {[
                  { label: 'Terms of Use', path: '/terms' },
                  { label: 'Privacy Policy', path: '/privacy' },
                  { label: 'Sources', path: '/public/sources' },
                ].map(({ label, path }) => (
                  <button key={path} onClick={() => navigate(path)}
                    className="text-[11px] text-muted-foreground hover:text-foreground underline underline-offset-4 transition-colors">
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
