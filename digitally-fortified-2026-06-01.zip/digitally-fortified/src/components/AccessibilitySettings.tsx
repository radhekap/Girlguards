import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Settings, Type, Contrast, Zap } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

interface AccessibilityPreferences {
  fontSize: 'small' | 'medium' | 'large';
  highContrast: boolean;
  reduceMotion: boolean;
}

const defaultPreferences: AccessibilityPreferences = {
  fontSize: 'medium',
  highContrast: false,
  reduceMotion: false,
};

export default function AccessibilitySettings() {
  const [preferences, setPreferences] = useState<AccessibilityPreferences>(defaultPreferences);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('accessibility-preferences');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setPreferences(parsed);
          applyPreferences(parsed);
        } catch (e) {
          console.error('Failed to parse accessibility preferences', e);
        }
      }
    }
  }, []);

  const applyPreferences = (prefs: AccessibilityPreferences) => {
    if (typeof window === 'undefined') return;
    
    const root = document.documentElement;
    
    // Font size
    root.classList.remove('text-small', 'text-medium', 'text-large');
    root.classList.add(`text-${prefs.fontSize}`);
    
    // High contrast
    if (prefs.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
    
    // Reduce motion
    if (prefs.reduceMotion) {
      root.classList.add('reduce-motion');
    } else {
      root.classList.remove('reduce-motion');
    }
  };

  const updatePreference = <K extends keyof AccessibilityPreferences>(
    key: K,
    value: AccessibilityPreferences[K]
  ) => {
    const newPreferences = { ...preferences, [key]: value };
    setPreferences(newPreferences);
    if (typeof window !== 'undefined') {
      localStorage.setItem('accessibility-preferences', JSON.stringify(newPreferences));
    }
    applyPreferences(newPreferences);
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="shrink-0">
          <Settings className="h-5 w-5" />
          <span className="sr-only">Accessibility Settings</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full max-w-[calc(100%-2rem)] md:max-w-md bg-card">
        <SheetHeader>
          <SheetTitle className="text-2xl font-light">Accessibility Settings</SheetTitle>
          <SheetDescription>
            Customize your experience to make the site more comfortable to use
          </SheetDescription>
        </SheetHeader>
        
        <div className="mt-8 space-y-6">
          {/* Font Size */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Type className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg font-medium">Text Size</CardTitle>
                  <CardDescription className="text-sm">Adjust the size of text throughout the site</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                {(['small', 'medium', 'large'] as const).map((size) => (
                  <Button
                    key={size}
                    variant={preferences.fontSize === size ? 'default' : 'outline'}
                    onClick={() => updatePreference('fontSize', size)}
                    className="capitalize"
                  >
                    {size}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* High Contrast */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Contrast className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg font-medium">High Contrast</CardTitle>
                  <CardDescription className="text-sm">Increase contrast for better readability</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Label htmlFor="high-contrast" className="text-sm font-normal cursor-pointer">
                  Enable high contrast mode
                </Label>
                <Switch
                  id="high-contrast"
                  checked={preferences.highContrast}
                  onCheckedChange={(checked) => updatePreference('highContrast', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Reduce Motion */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Zap className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg font-medium">Reduce Motion</CardTitle>
                  <CardDescription className="text-sm">Minimize animations and transitions</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Label htmlFor="reduce-motion" className="text-sm font-normal cursor-pointer">
                  Reduce animations
                </Label>
                <Switch
                  id="reduce-motion"
                  checked={preferences.reduceMotion}
                  onCheckedChange={(checked) => updatePreference('reduceMotion', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Reset Button */}
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              setPreferences(defaultPreferences);
              if (typeof window !== 'undefined') {
                localStorage.removeItem('accessibility-preferences');
              }
              applyPreferences(defaultPreferences);
            }}
          >
            Reset to Defaults
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
