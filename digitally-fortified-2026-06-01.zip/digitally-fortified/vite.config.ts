import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import svgr from "vite-plugin-svgr";
import path from "path";
import { srcBundlePlugin } from "./src-bundle-plugin";

// https://vite.dev/config/
export default defineConfig(({ command }) => {
  // miaodaDevPlugin is a platform-only dev-server plugin — skip it on Netlify/CI.
  const devPlugins: ReturnType<typeof react>[] = [];
  if (command === "serve") {
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const { miaodaDevPlugin } = require("miaoda-sc-plugin");
      devPlugins.push(miaodaDevPlugin());
    } catch {
      // not available outside the miaoda platform — safe to skip
    }
  }

  return {
    // VITE_BASE_PATH is set by the GitHub Actions deploy workflow to
    // "/<repo-name>" so assets resolve correctly on GitHub Pages project sites.
    // Leave unset (or set to "/") for Netlify / Vercel / root deployments.
    base: process.env.VITE_BASE_PATH || '/',
    plugins: [
      // Generates src/lib/srcBundle.generated.ts before any module loads
      srcBundlePlugin(),
      react(),
      ...devPlugins,
      svgr({
        svgrOptions: {
          icon: true,
          exportType: "named",
          namedExport: "ReactComponent",
        },
      }),
    ],
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
  };
});
