# Digitally Fortified

A full-stack parental-control & kids-safety web platform built with
React 18 · TypeScript · Vite · Tailwind CSS · shadcn/ui · Supabase.

---

## Quick start (local dev)

```bash
# 1. Install dependencies
npm install

# 2. Copy environment variables
cp .env.example .env
# → fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY

# 3. Start the dev server
npm run dev
```

---

## Deploy to GitHub Pages (automatic)

The repository ships with a GitHub Actions workflow that builds and
deploys automatically on every push to **main** or **master**.

### One-time setup

1. **Push** this folder to a new GitHub repository.

2. **Add secrets** (Settings → Secrets and variables → Actions):
   | Secret name | Value |
   |---|---|
   | `VITE_SUPABASE_URL` | your Supabase project URL |
   | `VITE_SUPABASE_ANON_KEY` | your Supabase anon key |

3. **Enable Pages** (Settings → Pages):
   - Source: **GitHub Actions**

4. Push any commit — the workflow runs automatically and your site
   will be live at `https://<username>.github.io/<repo-name>/`.

### How routing works on GitHub Pages

GitHub Pages returns a `404.html` for unknown paths.  The included
`public/404.html` encodes the path into a query string and redirects
to `index.html`, which restores it so React Router sees the correct URL.
This means every deep link (e.g. `/dashboard`, `/safety`) works on
direct access and on page refresh.

---

## Deploy to Netlify / Vercel

Both hosts support React SPA routing natively.

- **Netlify**: `netlify.toml` is already configured.  Connect the repo
  in the Netlify dashboard — no further config needed.
- **Vercel**: Import the repo; Vercel auto-detects Vite.  Add the two
  environment variables in the project settings.

---

## Project structure

```
src/
  components/   shadcn/ui + custom components
  pages/        One file per route
  contexts/     Auth & Theme providers
  hooks/        Reusable React hooks
  lib/          Utilities (Supabase client, helpers)
  services/     API / data-access layer
  types/        Shared TypeScript types
supabase/
  functions/    Edge Functions
  migrations/   Database migrations
```

---

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript, Vite |
| Styling | Tailwind CSS, shadcn/ui |
| Backend | Supabase (Postgres + Auth + Storage + Edge Functions) |
| Deploy | GitHub Pages / Netlify / Vercel |
